<?php
# Strings in pb_config.php
$db_connection_failed = "Datenbank-Verbindung fehlgeschlagen";
$db_tableselect_failed = "Auswaehlen der Datenbank fehlgeschlagen";

# Strings in lastseen.php
$no_username_specified = "Fehler: Kein Benutzername angegeben";
$getting_userdata_failed = "Fehler beim Auslesen der Benutzerdaten";
$user_does_not_exist = "Fehler: Dieser Benutzer existiert nicht";
$lastseen_formatstring = "Benutzer \002%s\002 wurde das letzte Mal am \002%s\002 gesehen, \002%s\002 beteiligte sich das letzte Mal am \002%s\002 am Forum.";

# Strings in latest.php
$no_boardids_specified = "Fehler: Keine Board-IDs angegeben";
$getting_data_failed = "Fehler beim Auslesen der Daten";

# Strings in postbot_activate.php
$protect_this_via_htaccess = "Bitte schuetzen Sie diesen Bereich via htaccess!";
$no_userids_specified = "Fehler: Keine User-ID angegeben";
$already_activated = "Benutzer <b>%s</b> ist schon aktiviert";
$activating = "Benutzer <b>%s</b> wird aktiviert...<br>";
$success = "Erfolgreich";
$failure = "Fehlgeschlagen";

# Strings in search.php
$no_searchstring = "Fehler: Kein Suchbegriff festgelegt";

# Strings in topuser.php
$topuser_formatstring = "Platz %d: \002%s\002 mit \002%d\002 Post%s";

# Strings in postbot_install.php
$creating_table_postbot = "1) Tabelle 'postbot' wird erstellt...";
$table_exists = "Tabelle %s existiert bereits, dieser Schritt wird uebersprungen...";
$error_creating_table = "Fehler beim Erstellen von %s: %s";
$table_created = "Tabelle erfolgreich erstellt";
$creating_table_postbotu = "2) Tabelle 'postbotu' wird erstellt";
$adding_to_newthread = "3) Postbotzusatz wird zu newthread.php hinzugefuegt...";
$adding_to_addreply = "4) Postbotzusatz wird zu addreply.php hinzugefuegt...";
$adding_to_register = "5) Postbotzusatz wird zu register.php hinzugefuegt...";
$wbb_folder_not_found = "WBB-Verzeichnis (%s) nicht gueltig/nicht gefunden";
$file_not_found = "%s kann nicht im WBB-Verzeichnis (%s) gefunden werden";
$error_opening = "Fehler beim Oeffnen von %s";
$line_found = "Zeile gefunden!";
$already_added = "Postbotzusatz wurde schon hinzugefuegt, dieser Schritt wird uebersprungen...";
$adding_hack = "Fuege Postbotzusatz hinzu...";
$done = "FERTIG";
?>
