<?php
# Strings in pb_config.php
$db_connection_failed = "Connecting to database failed";
$db_tableselect_failed = "Selecting table failed";

# Strings in lastseen.php
$no_username_specified = "Error: No username specified";
$getting_userdata_failed = "Error getting userdata";
$user_does_not_exist = "Error: This user does not exist";
$lastseen_formatstring = "User \002%s\002 was seen last at \002%s\002, \002%s\002 participated the last time at \002%s\002";

# Strings in latest.php
$no_boardids_specified = "Error: No board-IDs specified";
$getting_data_failed = "Error getting data";

# Strings in postbot_activate.php
$protect_this_via_htaccess = "Please protect this area via htaccess!";
$no_userids_specified = "Error: No user-IDs specified";
$already_activated = "User <b>%s</b> is already activated";
$activating = "Activating user <b>%s</b>...<br>";
$success = "Successful";
$failure = "Failed";

# Strings in search.php
$no_searchstring = "Error: No searchstring specified";

# Strings in topuser.php
$topuser_formatstring = "Position %d: \002%s\002 with \002%d\002 post%s";

# Strings in postbot_install.php
$creating_table_postbot = "1) Creating table 'postbot'...";
$table_exists = "Table %s exists, skipping this step";
$error_creating_table = "Error creating table %s: %s";
$table_created = "Table successfully created";
$creating_table_postbotu = "2) Creating table 'postbotu'...";
$adding_to_newthread = "3) Adding postbot-hack to newthread.php...";
$adding_to_addreply = "4) Addinig postbot-hack to addreply.php...";
$adding_to_register = "5) Adding postbot-hack to register.php...";
$wbb_folder_not_found = "WBB-folder (%s) not valid/not found";
$file_not_found = "%s can't be found in the WBB-folder (%s)";
$error_opening = "Error opening %s";
$line_found = "Line found!";
$already_added = "Postbot-hack has already been added, skipping this step";
$adding_hack = "Adding hack...";
$done = "DONE";

?>
