<?php
##################################################
## POSTBOT 3.6 SERVER-TEIL 4 #####################
##################################################

require("pb_config.php");

$result = mysql_query("SELECT * FROM `$bot_table`");
if (!$result)
        die("ERROR, query failed: ".(isset($debug) && $debug?mysql_error():"")."\n");

echo "OK,".mysql_num_rows($result)."\n";
if (mysql_num_rows($result) > 0) {
        while ($res = mysql_fetch_row($result)) {
                // we just need to modify the dateformat
                $res[5] = date($datefmt,$res[5]);

                foreach ($res as $field)
                        echo $field."\n";
        }
        mysql_query("TRUNCATE TABLE `".$bot_table."`");
}

mysql_close($db);

?>
