<?php
##################################################
## POSTBOT 3.6 SERVER-TEIL 4 #####################
##################################################
# SYNTAX:
# getuser.php            - zeigt entweder 0 oder die userdaten an
# getuser.php <num>      - zeigt die lezten <num> user an

require("pb_config.php");

$num = (isset($_GET['num'])?$_GET['num']:(isset($_SERVER['argc']) && $_SERVER['argc'] > 1?$_SERVER['argv'][1]:""));

if (!strlen($num))
 $num = -1;

if ($num == -1) {
        $result = mysql_query("SELECT * FROM `$bot_tableu`");
        if (!$result)
                die("ERROR getting result: ".(isset($debug) && $debug?mysql_error():"")."\n");
        echo "OK,".mysql_num_rows($result)."\n";

        while ($res = mysql_fetch_row($result)) {
                $res[2] = date($datefmt,$res[2]);
                foreach ($res as $e)
                        echo $e."\n";
        }
        mysql_query("TRUNCATE TABLE `".$bot_tableu."`");
} else {
	$result = mysql_query("SELECT `username`,`email`,`regdate`,`usertext`,`icq`,`aim`,`yim`,`msn`,`homepage`,`birthday`,`userid`,`activation` FROM `".$board_num."_users` ORDER BY `regdate` DESC LIMIT 0,$num");
        if (!$result)
                die("ERROR getting result: ".(isset($debug) && $debug?mysql_error():"")."\n");

        while ($res = mysql_fetch_row($result)) {
                $res[10] = $activate_url.$res[10];
                $res[2] = date($datefmt,$res[2]);
                if ($res[11] == "1")
                        $res[10] = "";
                foreach ($res as $e)
                        echo $e."\n";
        }
        mysql_free_result($result);
}

mysql_close($db);

?>
