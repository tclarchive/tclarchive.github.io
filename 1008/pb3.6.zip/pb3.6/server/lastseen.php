<?php
##################################################
## POSTBOT 3.6 BOARDSEEN #########################
##################################################


require("pb_config.php");

$user = (isset($_GET['user'])?$_GET['user']:(isset($_SERVER['argc']) && $_SERVER['argc'] >  1?$_SERVER['argv'][1]:""));

if (!isset($user))
        Die($no_username_specified."\n");

$result = mysql_query("SELECT `username`,`lastvisit`,`lastactivity` FROM `".$board_num."_users` WHERE `username` = '".mysql_escape_string($user)."'");
if (!$result)
        Die($getting_userdata_failed.(isset($debug) && $debug?" (".mysql_error().")":"")."\n");

if (mysql_num_rows($result) == 0)
        echo $user_does_not_exist."\n";
else {
        $user = mysql_fetch_row($result);
	echo sprintf($lastseen_formatstring."\n", $user[0], date($datefmt_seen, $user[1]), $user[0], date($datefmt_seen, $user[2]));
}

mysql_close($db);
?>
