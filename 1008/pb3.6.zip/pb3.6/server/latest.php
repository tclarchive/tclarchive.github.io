<?php
##################################################
## POSTBOT 3.6 SERVER TEIL 3 #####################
##################################################

require("pb_config.php");

$bids = (isset($_GET['bids'])?$_GET['bids']:(isset($_SERVER['argc']) && $_SERVER['argc'] > 1?$_SERVER['argv'][1]:""));

if (!strlen($bids))
	Die($no_boardids_specified."\n");

$cond = "";
if ($bids != "all") {
	$_bids = explode(",",$bids);
	foreach ($_bids as $b) {
		$pos = strpos($b,"-");
		if ($pos === false)
			$cond .= (strlen($cond)?" OR":"WHERE")."t2.`boardid` = '".$b."'";
		else {
			$begin = substr($b,0,$pos-1);
			$end = substr($b,$pos+1,strlen($b)-$pos-1);
			for ($beginn++; $beginn <= $end; $beginn++)
				$cond .= (strlen($cond)?" OR":"WHERE")."t2.`boardid` = '".$beginn."'";
		}
	}
}

$result = mysql_query("SELECT t1.`username`,t1.`threadid`,t1.`postid`,t1.`posttopic`,t1.`posttime` FROM `".$board_num."_posts` t1 LEFT JOIN `".$board_num."_threads` t2 ON t1.`threadid` = t2.`threadid` $cond ORDER BY t1.`posttime` DESC LIMIT 0,".$max_latest);
if (!$result)
	Die($getting_data_failed.(isset($debug) && $debug?" (".mysql_error().")":"")."\n");

require("latest_output.inc");
mysql_free_result($result);

mysql_close($db);

?>
