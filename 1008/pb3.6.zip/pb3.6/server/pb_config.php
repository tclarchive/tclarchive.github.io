<?php
##################################################
## POSTBOT 3.6 KONFiGURATiON #####################
##################################################

$sql_server   = "localhost";
$sql_user     = "kunde13";
$sql_pw       = "geheim";

$board_db     = "wbb";
$board_num    = "bb1";

$bot_db       = "wbb";

$bot_table    = "bb1_postbot";
$bot_tableu   = "bb1_postbotu";

$max_latest   = "5";
$activate_url = "http://forum.twice-irc.de/acp/postbot_activate.php?user_id=";

$datefmt      = "d.m.y H:i:s";
$datefmt_seen = "d.m.y\002 u\m \002H:i:s";
$debug        = false;

# Language files:

require("de_lang.php"); // Entferne das #-Zeichen am Anfang dieser Zeile um die deutsche Sprachdatei zu nutzen
#require("en_lang.php"); // Remove the # at the beginning of this line to use the english languagefile


##################################################
# Ende der Konfiguration / End of configuration ##
##################################################


$db = mysql_connect($sql_server, $sql_user, $sql_pw) OR die($db_connection_failed."\n");
mysql_select_db($bot_db) OR die($db_tableselect_failed."\n");
?>
