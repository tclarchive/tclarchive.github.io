<?php
###########################################
## POSTBOT 3.6 USER-AKTiViERUNG ###########
###########################################

if (!strlen($_SERVER['PHP_AUTH_USER']))
	Die($protect_this_via_htaccess."\n");

require("pb_config.php");
$user_id = (isset($_GET['id'])?$_GET['id']:die($no_userids_specified."\n");

$result = mysql_query("SELECT `username`,`activation` FROM `".$board_num."_users` WHERE `userid` =
'$user_id'");
if (!$result)
	Die($getting_userdata_failed.(isset($debug) && $debug?" (".mysql_error().")":"")."\n");

$user = mysql_fetch_row($result);
if ($user[1] == "1")
	die(sprintf($already_activated,$user[0])."\n");

echo sprintf($activating, $user[0])."\n";

$result = mysql_query("UPDATE `".$board_num."_users` SET `activation` = '1' WHERE `userid` = '$user
_id'");
echo ($result?$success:$failure);

mysql_close($db);

?>
