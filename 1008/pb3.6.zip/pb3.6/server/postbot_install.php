<?php
##################################################
## POSTBOT 3.6 iNSTALLATiONS-SCRiPT ##############
##################################################

# Konfiguration:
$wbb_dir = "/home/sECuRE/web/wbb/";

# Ende der Konfiguration

if (substr($wbb_dir,strlen($wbb_dir),1) != "/")
	$wbb_dir .= "/";

require("pb_config.php");

echo $creating_table_postbot."\n\n";
$result = mysql_query("CREATE TABLE `".$board_num."_postbot` ( `antwort` tinyint(4) NOT NULL default '0', `url` text NOT NULL, `forumtitel` text NOT NULL, `poster` text NOT NULL, `replyposter` text NOT NULL, `zeit` bigint(20) default NULL, `titel` text NOT NULL, `replytitel` text NOT NULL, `boardid` int(11) NOT NULL default '0') TYPE=MyISAM;");
if (!$result)
	if (mysql_errno($db) == 1050)
		echo sprintf($table_Exists, $board_num."_postbot");
	else die(sprintf($error_creating_table."\n",$board_num."_postbot",mysql_error($db)));
else echo $table_created."\n";

echo $creating_table_postbotu."\n";
$result = mysql_query("CREATE TABLE `".$board_num."_postbotu` ( `username` text NOT NULL, `email` text NOT NULL, `regdate` int(11) NOT NULL default '0', `usertext` text NOT NULL, `icq` varchar(30) NOT NULL default '', `aim` varchar(30) NOT NULL default '', `yim` varchar(30) NOT NULL default '', `msn` varchar(30) NOT NULL default '',`homepage` text NOT NULL, `birthday` date NOT NULL default '0000-00-00', `enable` text NOT NULL) TYPE=MyISAM;");

if (!$result)
	if (mysql_errno($db) == 1050)
		echo sprintf($table_Exists, $board_num."_postbotu");
	else die(sprintf($error_creating_table."\n",$board_num."_postbotu",mysql_error($db)));
else echo $table_created."\n";

echo $adding_to_newthread."\n\n";

if (!is_dir($wbb_dir))
	die(sprintf($wbb_folder_not_found."\n", $wbb_dir));

if (!is_file($wbb_dir."newthread.php"))
	die(sprintf($file_not_found."\n","newthread.php",$wbb_dir));

# search line

$c = 0;
$file = fopen($wbb_dir."newthread.php","r+");
if (!$file)
	die(sprintf($error_opening."\n",$wbb_dir."newthread.php"));
 
$buffer = array();
while (!feof($file)) {
	$buffer[] = fgets($file);
	if (strpos($buffer[count($buffer) - 1],"insert_id();") > 0) {
		echo $line_found."\n";
		$tbuffer = fgets($file);
		fseek($file,ftell($file) - strlen($tbuffer));
		if (strpos($tbuffer,"POSTBOT") > 0)
			echo $already_added."\n";
		else {
			echo $adding_hack."\n";
			$buffer[] = "/* POSTBOT */\n";
			$buffer[] = "\$bname = \$db->fetch_array(\$db->unbuffered_query(\"SELECT title,parentid FROM bb\".\$n.\"_boards WHERE boardid = \$boardid\"));\n";
			$buffer[] = "\$bnamepres = (\$bname[1]?\$db->fetch_array(\$db->unbuffered_query(\"SELECT title FROM bb\".\$n.\"_boards WHERE boardid = \$bname[1]\")):\"\");\n";
			$buffer[] = "\$bnamepres = \$bnamepres[0];\n\$bname = (strlen(\$bnamepres)?\$bnamepres.\" -> \".\$bname[0]:\$bname[0]);\n";
			$buffer[] = "\$db->query(\"INSERT INTO bb\".\$n.\"_postbot (antwort,url,forumtitel,poster,zeit,titel,boardid) VALUES ('0','\$threadid','\$bname','\".addslashes(\$wbbuserdata['username']).\"','\$time','\".addslashes(\$topic).\"','\$boardid')\");\n";
			$buffer[] = "/* END POSTBOT */\n";

			# read file completely
			while (!feof($file))
				$buffer[] = fgets($file);
			
			# go to the beginning and write file
			fseek($file,0);
			foreach ($buffer as $l)
				fwrite($file,$l);
		}
		break;
	}
	$c++;
}
fclose($file);
echo $adding_to_addreply."\n\n";

$c = 0;
$file = fopen($wbb_dir."addreply.php","r+");
if (!$file)
	die(sprintf($error_opening."\n",$wbb_dir."addreply.php"));
$buffer = array();
while (!feof($file)) {
        $buffer[] = fgets($file);
        if (strpos($buffer[count($buffer) - 1],"insert_id();") > 0) {
		echo $line_found."\n";
                $tbuffer = fgets($file);
                fseek($file,ftell($file) - strlen($tbuffer));
                if (strpos($tbuffer,"POSTBOT") > 0)
			echo $already_added."\n";
                else {
			echo $adding_hack."\n";
			$buffer[] = "/* POSTBOT */\n";
			$buffer[] = "\$bname = \$db->fetch_array(\$db->unbuffered_query(\"SELECT title,parentid FROM bb\".\$n.\"_boards WHERE boardid = \$boardid\"));\n";
			$buffer[] = "\$bnamepres = (\$bname[1]?\$db->fetch_array(\$db->unbuffered_query(\"SELECT title FROM bb\".\$n.\"_boards WHERE boardid = \$bname[1]\")):\"\");\n";
			$buffer[] = "\$bnamepres = \$bnamepres[0];\n\$bname = (strlen(\$bnamepres)?\$bnamepres.\" -> \".\$bname[0]:\$bname[0]);\n";
			$buffer[] = "\$origuser = \$db->fetch_array(\$db->unbuffered_query(\"SELECT starter,topic FROM bb\".\$n.\"_threads WHERE threadid = \$threadid\"));\n";
			$buffer[] = "\$origtopic = \$origuser[1];\n";
			$buffer[] = "\$origuser = \$origuser[0];\n";
			$buffer[] = "\$db->query(\"INSERT INTO bb\".\$n.\"_postbot (antwort,url,forumtitel,poster,replyposter,zeit,titel,replytitel,boardid) VALUES ('1','\$postid','\$bname','\".addslashes(\$origuser).\"','\".addslashes(\$wbbuserdata['username']).\"','\$time','\$origtopic','\".addslashes(\$topic).\"','\$boardid')\");\n";
			$buffer[] = "/* END POSTBOT */\n";

			# read file completely
                        while (!feof($file))
                                $buffer[] = fgets($file);

                        # go to the beginning and write file
                        fseek($file,0);
                        foreach ($buffer as $l)
                                fwrite($file,$l);
                }
                break;
        }
        $c++;
}
fclose($file);

echo $adding_to_register."\n\n";

$c = 0;
$file = fopen($wbb_dir."register.php","r+");
if (!$file)
	die(sprintf($error_opening."\n",$wbb_dir."register.php"));
$buffer = array();
while (!feof($file)) {
        $buffer[] = fgets($file);
        if (strpos($buffer[count($buffer) - 1],"insert_id();") > 0) {
		echo $line_found."\n";
                $tbuffer = fgets($file);
                fseek($file,ftell($file) - strlen($tbuffer));
                if (strpos($tbuffer,"POSTBOT") > 0)
			echo $already_added."\n";
                else {
			echo $adding_hack."\n";
			$buffer[] = "/* POSTBOT */\n";
			$buffer[] = "\$db->query(\"INSERT INTO bb\".\$n.\"_postbotu (username,email,regdate,usertext,icq,aim,yim,msn,homepage,birthday,enable) VALUES ('\".addslashes(\$r_username).\"','\".addslashes(\$r_email).\"','\".time().\"','\".addslashes(\$r_usertext).\"','\".intval(\$r_icq).\"','\".addslashes(\$r_aim).\"','\".addslashes(\$r_yim).\"','\".addslashes(\$r_msn).\"','\".addslashes(\$r_homepage).\"','\".addslashes(\$birthday).\"','".$activate_url."\$insertid')\");\n";
			$buffer[] = "/* END POSTBOT */\n";
		
			# read file completely
                        while (!feof($file))
                                $buffer[] = fgets($file);

                        # go to the beginning and write file
                        fseek($file,0);
                        foreach ($buffer as $l)
                                fwrite($file,$l);
                }
                break;
        }
        $c++;
}
fclose($file);

echo "\n".$done."\n";

mysql_close($db);
?>
