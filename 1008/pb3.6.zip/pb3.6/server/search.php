<?php
##################################################
## POSTBOT 3.6 SERVER-TEIL 4 #####################
##################################################
# SYNTAX:
# search.php <title>    - zeigt Threads/Antworten mit <title>
#                         im Titel/als Autor an

require("pb_config.php");

if (isset($_GET['titel']))
        $titel = $_GET['titel'];
else {
        $titel = "";
        if (isset($_SERVER['argc']) && $_SERVER['argc'] >= 2)
                for ($c = 1; $c < $_SERVER['argc']; $c++)
                        $titel .= $_SERVER['argv'][$c]." ";
}

if (!strlen($titel))
        Die($no_searchstring."\n");

$result = mysql_query("SELECT t1.`username`,t1.`threadid`,t1.`postid`,t1.`posttopic`,t1.`posttime` FROM `".$board_num."_posts` t1 LEFT JOIN `".$board_num."_threads` t2 ON t1.`threadid` = t2.`threadid` WHERE t1.`posttopic` LIKE '%".str_replace(" ","%",$titel)."%' OR t1.`username` LIKE '%".$titel."%' ORDER BY t1.`posttime` DESC LIMIT 0,".$max_latest);
require("latest_output.inc");
mysql_free_result($result);

mysql_close($db);
?>
