<?php
##################################################
## POSTBOT 3.6 SERVER-TEIL 2 #####################
##################################################
# SYNTAX:
# topuser.php [num] - Zeigt die Top [num] Poster an

require("pb_config.php");

$num = (isset($_GET['num'])?$_GET['num']:(isset($_SERVER['argc']) && $_SERVER['argc'] > 1?$_SERVER['argv'][1]:""));

if (!strlen($num) || $num == 0)
	$num = $max_latest;

$result = mysql_query("SELECT `username`,`userposts` FROM `".$board_num."_users` ORDER BY `userposts` DESC LIMIT 0,$num");
if (!$result)
	Die($getting_userdata_failed.(isset($debug) && $debug?" (".mysql_error().")":"")."\n");
$c = 1;
while ($u = mysql_fetch_row($result))
	echo sprintf($topuser_formatstring, $c++, $u[0], $u[1], ($u[1] == 1?"":"s"))."\n";
//	echo "Platz ".$c++.": \002".$u[0]."\002 mit \002".$u[1]."\002 Post".($u[1] == 1?"":"s")."\n";

mysql_close($db);
?>
