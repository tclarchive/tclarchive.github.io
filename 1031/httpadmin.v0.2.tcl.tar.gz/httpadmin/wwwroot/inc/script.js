/*
 * Java scripts by Ofloo all rights reserved.
 *
 * Sorry if the code is a bit messy its not, I am not exactly experianced with js, 
 * this is my first js ever so .. go easy :p
 *
 * HomePage: http://ofloo.net/
 * CVS: http://cvs.ofloo.net/
 * Email: support[at]ofloo.net
 *
 * Credit: Tnx to help from s00p @ irc.ofloo.net for helping out with js. 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


/* Set close timer */
var howLong = 10000;
t = null;

/* Self close window (with timer set above) */
function closeMe(){
  t = setTimeout("self.close()",howLong);
}

var timerID = null 
var timerRunning = false 

function stopclock(){ 
  if(timerRunning) 
    clearTimeout(timerID) 
  timerRunning = false 
} 

function startclock(){ 
  stopclock() 
  showtime() 
} 

function showtime(){ 
  var now = new Date() 
  var hours = now.getHours() 
  var minutes = now.getMinutes() 
  var seconds = now.getSeconds() 
  var timeValue = hours
  timeValue  += ((minutes < 10) ? ":0" : ":") + minutes 
  timeValue  += ((seconds < 10) ? ":0" : ":") + seconds 

  document.clock.face.value = timeValue 
  timerID = setTimeout("showtime()",1000) 
  timerRunning = true 
}

/* Global default popup window */
function popitup(url){
  newwindow=window.open(url,'name','height=110,width=180');
  if (window.focus) {newwindow.focus()}
  return false;
}

/* Addlink popup script + refresh page with error handeling */
function popaddlink(url, refurl){
  if ((document.addlink.bot.value=="") || (document.addlink.link.value=="")) {
	alert("Please fill out the required fields.\nThank You.");
	return false;
  } else {
	refresh(refurl);
    newwindow=window.open(url,'name','height=110,width=180');
    if (window.focus) {
      newwindow.focus();
	}
    return false;
  }
}

/* Global default refesh page */
function refresh(url){
  target = url;
  setTimeout('location.href = target',5000);
}

/* Drop down menus */
var zindex=1000
var ns4=document.layers
var ns6=document.getElementById&&!document.all
var ie4=document.all
var opr=navigator.userAgent.indexOf("Opera")

function dropit(e,whichone){
  curmenuID=ns6? document.getElementById(whichone).id : eval(whichone).id
  if (window.themenu&&themenu.id!=curmenuID)
    themenuStyle.visibility=ns4?"hide" : "hidden"

  themenu=ns6? document.getElementById(whichone): eval(whichone)
  themenuStyle=(ns6||ie4)? themenu.style : themenu

  themenuoffsetX=(ie4&&opr==-1)? document.body.scrollLeft : 0
  themenuoffsetY=(ie4&&opr==-1)? document.body.scrollTop : 0

  themenuStyle.left=ns6||ns4? e.pageX-e.layerX : themenuoffsetX+event.clientX-event.offsetX
  themenuStyle.top=ns6||ns4? e.pageY-e.layerY+19 : themenuoffsetY+event.clientY-event.offsetY+18

  hiddenconst=(ns6||ie4)? "hidden" : "hide"
  if (themenuStyle.visibility==hiddenconst){
    themenuStyle.visibility=(ns6||ie4)? "visible" : "show"
    themenuStyle.zIndex=zindex++
  } else
    hidemenu()
  return false
}

function hidemenu(){
  if ((ie4||ns6)&&window.themenu)
   themenuStyle.visibility="hidden"
  else if (ns4)
    themenu.visibility="hide"
}

if (ie4||ns6)
  document.onclick=hidemenu