<html>

<head>
<meta http-equiv="Content-Language" content="en-gb">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<META HTTP-EQUIV="Refresh" Content="180;URL=irc_stats.php">
<title>::: Eggdrop -- NickList :::</title>
</head>

<body bgcolor="#1B2B3B" text="#FFFFFF">
<b><font face="Arial" size="2"> 
<?php
// Change filepath to where your nicklist.txt is being stored.
$lines = file ('/home/user/web/nicklist.txt');
$count = count($lines);

foreach ($lines as $line_num => $line) {
    echo  ($line)  . "<br>\n";
}
echo "<br>";

if ($count == 1)
{
	echo  "There is ".$count." user currently on #yourchannel";
}
else{
	echo  "There are ".$count." users currently on #yourchannel";
}
?>
</font></b>
</body>

</html>