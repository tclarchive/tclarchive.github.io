README file for joingreet.tcl and partgreet.tcl

!! WARNING !!
!! Don't use joingreet.tcl and partgreet.tcl on the same bot !!
!! It will make your bot stress and your bot will lagging !!

!! PERINGATAN !!
!! Jangan gunakan joingreet.tcl dan partgreet.tcl pada bot yang sama !!
!! Ini akan membuat bot kamu stres dan bot kamu akan lagg !!


Any comment, advice, bugs, please send error and report to:
 yoichiro_san@yahoo.com

=EOF=