#---------------------------------------------------
# AdminServ v2.0 (stable)
#
# *
#
# AdminServ is a channel service bot, 
# intended primarily to act as a 
# complete combination of ChanServ, 
# NickServ, OpServ, HelpServ, and 
# Global.
#
# For questions & comments, you may
# visit http://adminserv.cmx-networks.net
# or irc.hazenet.org on channel
# #adminserv
#
# *
#
# ChanServ.c
# 
# *
#
# $Id: chanserv.c,v 2.0 2004/04/20 18:49:55 emac Exp $
#
#---------------------------------------------------


### ChanServ.c Binds

bind pub - ${trigger}access pub_access
bind pub - ${trigger}a pub_access
bind pub - ${trigger}myaccess pub_myaccess
bind pub - ${trigger}adduser pub_adduser
bind pub - ${trigger}addowner pub_addowner
bind pub - ${trigger}addcoowner pub_addcoowner
bind pub - ${trigger}addmaster pub_addmaster
bind pub - ${trigger}addop pub_addop
bind pub - ${trigger}addpeon pub_addpeon
bind pub - ${trigger}ban pub_ban
bind pub - ${trigger}b pub_ban
bind pub - ${trigger}unban pub_unban
bind pub - ${trigger}ub pub_unban
bind pub - ${trigger}kick pub_kick
bind pub - ${trigger}k pub_kick
bind pub - ${trigger}kickban pub_kban
bind pub - ${trigger}kban pub_kban
bind pub - ${trigger}kb pub_kban
bind pub - ${trigger}unbanall pub_unbanall
bind pub - ${trigger}uba pub_unbanall
bind pub - ${trigger}reg pub_register
bind pub - ${trigger}register pub_register
bind pub - ${trigger}unreg pub_unregister
bind pub - ${trigger}unregister pub_unregister
bind pub - ${trigger}csuspend pub_csuspend
bind pub - ${trigger}cunsuspend pub_cunsuspend
bind pub - ${trigger}channels pub_channels
bind pub - ${trigger}deluser pub_deluser
bind pub - ${trigger}god pub_god
bind pub - ${trigger}info pub_cinfo
bind pub - ${trigger}registrar pub_registrar
bind pub - ${trigger}rusers rusers
bind pub - ${trigger}invite pub_invite
bind pub - ${trigger}inviteme pub_inviteme
bind pub - ${trigger}staffchan pub_staffchan
bind pub - ${trigger}mode pub_mode
bind pub - ${trigger}op pub_op
bind pub - ${trigger}deop pub_deop
bind pub - ${trigger}halfop pub_hop
bind pub - ${trigger}dehalfop pub_delhop
bind pub - ${trigger}hop pub_hop
bind pub - ${trigger}delhop pub_delhop
bind pub - ${trigger}voice pub_voice
bind pub - ${trigger}v pub_voice
bind pub - ${trigger}devoice pub_devoice
bind pub - ${trigger}dv pub_devoice
bind pub - ${trigger}users users
bind pub - ${trigger}wlist wlist
bind pub - ${trigger}clist clist
bind pub - ${trigger}mlist mlist
bind pub - ${trigger}olist olist
bind pub - ${trigger}plist plist
bind pub - ${trigger}version pub_version
bind pub - ${trigger}up pub_up
bind pub - ${trigger}down pub_down
bind pub - ${trigger}upall pub_upall
bind pub - ${trigger}downall pub_downall
bind pub - ${trigger}topic pub_topic
bind pub - ${trigger}set pub_set
bind pub - ${trigger}say pub_say
bind pub - ${trigger}ping pub_ping
bind pub - ${trigger}sex pub_sex
bind pub - ${trigger}banana pub_banana
bind pub - ${trigger}wut pub_wut
bind pub - ${trigger}8ball pub_8ball
bind pub - ${trigger}staff pub_liststaff
bind pub - ${trigger}helpers pub_listhelpers
bind pub - ${trigger}nhelpers pub_listnhelpers
bind pub - ${trigger}admins pub_listadmins
bind pub - ${trigger}setinfo pub_setinfo
bind pub - ${trigger}netinfo pub_netinfo
bind pub - ${trigger}ni pub_netinfo
bind pub - ${trigger}uptime pub_uptime
bind join - "*" on_join_staff
bind join - "*" on_join_chansets
bind join - "*" on_join_greeting
bind join - "" usrjoin
bind pub n -fix2 pub_fix2
bind ctcp - version ctcpreply

### ACCESS

proc pub_access {nick host hand chan who} {
 global botnick
 if {$who == ""} {set who $nick}
 if {$who == "$botnick"} {notice $nick "$who is a Channel Service (\002Administrator\002)." ; notice $nick "$who is the \002Moderator\002 in $chan and has \002security override\002 enabled." ; return }
 set newhand [finduser $who![getchanhost $who $chan]]
 if {$newhand == "*"} {notice $nick "\002$who\002 is not registered with \002\00314$botnick\0031\002." ; return }  
  if {[getuser $newhand XTRA epithet] == ""} {
     set epithet "a \00314$botnick\0031 Staff Member"
 } else {
     set epithet [getuser $newhand XTRA epithet]
 }  
 if { [staff $newhand] && [godmode $newhand] } {
    notice $nick "$who is $epithet (\002[oaccess $newhand]\002)."
    notice $nick "$who ($newhand) [saccess $newhand $chan] in $chan and has \002security override\002 enabled."
   } elseif { [staff $newhand] && ![godmode $newhand] } {
     notice $nick "$who is $epithet (\002[oaccess $newhand]\002)."
     notice $nick "$who ($newhand) [saccess $newhand $chan] in $chan."
    } else {
      notice $nick "$who ($newhand) [saccess $newhand $chan] in $chan."
   }
 if { [getchaninfo $newhand $chan] != "" } {
     notice $nick "\[$newhand\] [getchaninfo $newhand $chan]"
   }
  return
}

### MyAccess

proc pub_myaccess {nick uhost hand chan arg} {
 set thehand [lindex $arg 0]
 if {$thehand == ""} {set thehand $hand}
 foreach c [channels] {
  if {[matchattr $thehand -|N $chan] == 1} {lappend out [join "${c}:Owner [getchaninfo $thehand $chan]" " "]}
  if {[matchattr $thehand -|C $chan] == 1 && [matchattr $thehand -|N $chan] != 1} {lappend out [join "${c}:Master [getchaninfo $thehand $chan]" " "]}
  if {[matchattr $thehand -|M $chan] == 1 && [matchattr $thehand -|C $chan] != 1 && [matchattr $thehand -|n $chan] != 1} {lappend out [join "${c}:Op [getchaninfo $thehand $chan]" " "]}
  if {[matchattr $thehand -|O $chan] == 1 && [matchattr $thehand -|M $chan] != 1 && [matchattr $thehand -|m $chan] != 1 && [matchattr $thehand -|N $chan] != 1} {lappend out [join "${c}:Peon [getchaninfo $thehand $chan]" " "]}
  if {[matchattr $thehand -|P $chan] == 1 && [matchattr $thehand -|O $chan] != 1 && [matchattr $thehand -|o $chan] != 1 && [matchattr $thehand -|C $chan] != 1 && [matchattr $thehand -|N $chan] != 1} {lappend out [join "${c}:Friend [getchaninfo $hand $chan]" " "]}
  }
  if {$out == ""} {set $out "None."}
  notice $nick "Access list for \002$thehand\002."
  foreach line $out {
   notice $nick "[split $line " "]"
  }
}

### Adduser

proc pub_adduser {nick host hand chan arg} { 
 global botnick
  set who [lindex $arg 0]
  set access [lindex $arg 1]
  if {$who == ""} {notice $nick "\002adduser\002 requires more parameters." ; return}
  if {$access == ""} {notice $nick "\002adduser\002 requires more parameters." ; return}
  if { [string index [lindex $arg 0] 0] == "*" } {
  set user [string range [lindex $arg 0] 1 end]
} else { 
  set user [finduser $who![getchanhost $who $chan]]
  }
  if {$user == "*"} {notice $nick "\002$user\002 must first register with \002$botnick\002." ; return } {
  if {$access != "400" && $access != "300" && $access != "200" && $access != "100"} {notice $nick "\002$access\002 is an invalid access level" ; return}
  if {[matchattr $user |NCMOP $chan]} {notice $nick "$who is already on the $chan user list (with [saccess2 $user $chan] access)." ; return}
  if {$access == "400"} {
  if {[godmode $hand] == 0 && [accessint $hand $chan] != 5} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|N $chan]} {chattr $user |+C $chan ; notice $nick "Added $user with \002$access\002 to $chan user list." ; mode $chan "+o $user" ; return}
 } elseif {$access == "300"} {
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 4} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|NC $chan]} {chattr $user |+M $chan ; notice $nick "Added $user with \002$access\002 to $chan user list." ; mode $chan "+o $user" ; return}
 } elseif {$access == "200"} {
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 3} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|NCM $chan]} {chattr $user |+O $chan ; notice $nick "Added $user with \002$access\002 to $chan user list." ; mode $chan "+o $user" ; return}
  } elseif {$access == "100"} {
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 2} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|MCNO $chan]} {chattr $user |+P $chan ; notice $nick "Added $user with \002$access\002 to $chan user list." ; mode $chan "+v $user" ; return}
    }
  }
}

### Addowner

proc pub_addowner {nick host hand chan arg} {
   global botnick 
  if {[godmode $hand] == 0} {nooverride $nick ; return}
  if { [string index [lindex $arg 0] 0] == "*" } {
  set user [string range [lindex $arg 0] 1 end]
} else { 
  set user [finduser $arg![getchanhost $arg $chan]]
  }
  if {$user == "*"} {notice $nick "\002$user\002 must first register with \002$botnick\002." ; return } {
  if {[matchattr $user |NCMOP $chan]} {notice $nick "$arg is already on the $chan user list (with [saccess2 $user $chan] access)." ; return}
  chattr $user |+N $chan ; notice $nick "Added $user to the $chan user list with access \002500\002." ; cmdlog $chan $nick $hand "addowner $user" ; return}
}

### Addcoowner

proc pub_addcoowner {nick host hand chan arg} { 
    global botnick
 if {[godmode $hand] == 0 && [accessint $hand $chan] != 5} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|N $chan]} {
  if { [string index [lindex $arg 0] 0] == "*" } {
  set user [string range [lindex $arg 0] 1 end]
} else { 
  set user [finduser $arg![getchanhost $arg $chan]]
  }
  if {$user == "*"} {notice $nick "\002$user\002 must first register with \002$botnick\002." ; return } {
  if {[matchattr $user |NCMOP $chan]} {notice $nick "$arg is already on the $chan user list (with [saccess2 $user $chan] access)." ; return}
  chattr $user |+C $chan ; notice $nick "Added $user to the $chan user list with access \002400\002." ; return}
  }
}

### Addmaster

proc pub_addmaster {nick host hand chan arg} { 
    global botnick
 if {[godmode $hand] == 0 && [accessint $hand $chan] < 4} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|NC $chan]} {
  if { [string index [lindex $arg 0] 0] == "*" } {
  set user [string range [lindex $arg 0] 1 end]
} else { 
  set user [finduser $arg![getchanhost $arg $chan]]
  }
  if {$user == "*"} {notice $nick "\002$user\002 must first register with \002$botnick\002." ; return } {
  if {[matchattr $user |NCMOP $chan]} {notice $nick "$arg is already on the $chan user list (with [saccess2 $user $chan] access)." ; return}
  chattr $user |+M $chan ; notice $nick "Added $user to the $chan user list with access \002300\002." ; return}
  }
}

### Addop

proc pub_addop {nick host hand chan arg} { 
    global botnick
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 3} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|NCM $chan]} {
  if { [string index [lindex $arg 0] 0] == "*" } {
  set user [string range [lindex $arg 0] 1 end]
} else { 
  set user [finduser $arg![getchanhost $arg $chan]]
  }
  if {$user == "*"} {notice $nick "\002$user\002 must first register with \002$botnick\002." ; return } {
  if {[matchattr $user |NCMOP $chan]} {notice $nick "$arg is already on the $chan user list (with [saccess2 $user $chan] access)." ; return}
  chattr $user |+O $chan ; notice $nick "Added $user to the $chan user list with access \002200\002." ; return}
  }
}

### Addpeon

proc pub_addpeon {nick host hand chan arg} { 
    global botnick
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 2} {noaccess $chan $nick ; return}
  if {[matchattr $hand I|MCNO $chan]} {
  if { [string index [lindex $arg 0] 0] == "*" } {
  set user [string range [lindex $arg 0] 1 end]
} else { 
  set user [finduser $arg![getchanhost $arg $chan]]
  }
  if {$user == "*"} {notice $nick "\002$user\002 must first register with \002$botnick\002." ; return } {
  if {[matchattr $user |NCMOP $chan]} {notice $nick "$arg is already on the $chan user list (with [saccess2 $user $chan] access)." ; return}
  chattr $user |+P $chan ; notice $nick "Added $user to the $chan user list with access \002100\002." ; return}
  }
}

### Kick

proc pub_kick {nick uhost hand chan arg} {
 global botnick
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 2} {noaccess $nick ; return}
  set who [lindex $arg 0]
  set reason [lrange $arg 1 end]
  if {$who == $botnick} {notice $nick "\002$botnick\002 may not be kicked, killed, banned, or deopped." ; return}
  if {$reason == ""} {set reason "Bye."}
  putquick "KICK $chan $who :($nick) $reason" 
  putquick "notice $nick :Kicked \002$who\002 from $chan."
}

### Kickban

proc pub_kban {nick host hand chan text} {
global botnick
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 2} {noaccess $chan $nickick ; return}
 set target [lindex $text 0]
 set reason [lrange $text 0 end]
 set bhost [getchanhost $target $chan]
 set banmask "*!*[string trimleft [string range $bhost [string first "!" $bhost] end] ?^~-?]"
 if {$target == $botnick} {notice $nickick "\002$botnick\002 may not be kicked, killed, banned, or deopped." ; return}
 putquick "MODE $chan +b $banmask"
 putquick "KICK $chan $target :$reason"
 putquick "NOTICE $nickick :KickedBanned \002$target\002 from \002$chan\002."
}

### Unbanall

proc pub_unbanall {nick uhost hand chan text} {
global botnick
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 2} {noaccess $chan $nick ; return}
   puthelp "PRIVMSG $nick :[all:clearbans $chan $nick]"
   return 1
}

### Clearbans

proc pub_clearbans { chan nick } {
   if { ![validchan $chan] } { notice $nick "Invalid channel \002$chan\002." ; return }
   if { ![botonchan $chan] } { notice $nick "I am not on \002$chan\002." ; return }
   if { ![botisop $chan] } { notice $nick "Invalid access in \002$chan\002." ; return}
   set chanbans [chanbans $chan]
   if { [llength $chanbans] == 0 } { notice $nick "No channel bans exist on $chan." : return }
   set bancount 0
   foreach ban $chanbans {
      set banhost [lindex $ban 0]
      pushmode $chan -b $banhost
      incr bancount
   }
   notice $nick "Removed \002$bancount\002 bans on \002$chan\002."
}

### Channel Register

setudef flag toys
setudef str registrar
setudef int regon

proc pub_register {nick uhost hand chan arg} {
global botnick
 if {[godmode $hand] == 0} {nooverride $nick ; return}
   set args [cleanarg $arg]
   set thechan [lindex $args 0]
   set who [lindex $args 1]
   #set newchan $chan
   if {$thechan == ""} {notice $nick "\002register\002 requires more parameters." ; return}
   if {$who == ""} {notice $nick "\002register\002 requires more parameters." ; return}
   if { [string index [lindex $args 1] 0] == "*" } {
  set owner [string range [lindex $args 1] 1 end]
} else { 
  set owner [finduser $who![getchanhost $who $chan]]
  }
  set owner [finduser $who![getchanhost $who $chan]]
  if {![validuser $owner]} {notice $nick "\002$who\002 is not a valid nick or account." ; return}
  notice $nick "Registered \002$thechan\002 to \002$owner\002 by $nick."
  channel add $thechan
  putquick "OPMODE $chan +ont $botnick"
  file mkdir data/$thechan;set fp [open data/$thechan/sets w+]
  puts $fp "greeting *"
  puts $fp "autovoice off"
  puts $fp "autoop off"
  puts $fp "topic *"
  close $fp
  chattr $owner |+N $thechan
  channel set $thechan registrar $hand
  channel set $thechan regon [unixtime]
  cmdlog $thechan $nick $hand "register $owner"
}

### Channel Unregister

proc pub_unregister {nick uhost hand chan args} {
   if {[godmode $hand] == 0} {nooverride $nick ; return}
   if {![validchan $args]} {notice $nick "\002unregister\002 requires more parameters." ; return}
   set thechan [lindex $args 0]
   notice $nick "unregistered \002$thechan\002."
   putquick "PART $thechan :$thechan unregistered by $nick."
   channel remove $thechan
   file delete data/$thechan/sets;file delete data/$thechan
   cmdlog $thechan $nick $hand "unregister"
}

### Channel Suspend

proc pub_csuspend {nick uhost hand chan arg} {
 global botnick
 if {[godmode $hand] == 0} {nooverride $nick ; return}
   set args [cleanarg $arg]
   set thechan [lindex $arg 0]
   set reason [lrange $arg 1 end]
   if {$thechan == ""} {notice $nick "\002csuspend\002 requires more parameters." ; return}
   if {$reason == ""} {notice $nick "\002csuspend\002 requires more parameters." ; return}
   notice $nick "\002$botnick\002's access to \002$thechan\002 has been temporarily suspended."
   putquick "PART $thechan :\002Suspended\002: $reason (suspended by $nick)"
   channel set $thechan +inactive
   cmdlog $thechan $nick $hand "suspend $reason"
}

### Channel Unsuspend

proc pub_cunsuspend {nick uhost hand chan arg} {
global botnick
 if {[godmode $hand] == 0} {nooverride $nick ; return}
 set thechan [lindex $arg 0]
 if {$thechan == ""} {notice $nick "\002cunsuspend\002 requires more parameters." ; return}
 if {[channel get $thechan inactive]} {
 notice $nick "\002$botnick\002's access to \002$thechan\002 has been restored by $nick."
 channel set $thechan -inactive
 cmdlog $thechan $nick $hand "unsuspend"
  }
}

### Registered Channel List

proc pub_channels {nick uhost hand chan arg} {
global channel staff
 global botnick
  if {[godmode $hand] == 0} {nooverride $nick ; return}
   set notin "\002Currently not in\002: "
   foreach chan [channels] {
    if {$chan == "$staff(channel)"} { lappend channels "\002\002"} else {
     if {[botonchan $chan]} {
       if {[botisop $chan]} {
         lappend channels @$chan
       } else {
         if {[botisvoice $chan]} {
           lappend channels +$chan
         } else {
           lappend channels $chan
       } }
     } else {
       if {![botonchan $chan]} {
        if {[channel get $chan inactive]} {
           lappend notin *$chan
        } else {
           lappend notin $chan
   } } } } }
   if {$notin == "\002Currently not in\002: "} { lappend notin "None." }
   putquick "notice $nick :Channel List for \00314$botnick\0031:"
   putquick "notice $nick :\002Currently in\002: $channels"
   putquick "notice $nick :$notin"
}

### Delete User

proc pub_deluser {nick host hand chan arg} {
 if { [string index [lindex $arg 0] 0] == "*" } {
  set user [string range [lindex $arg 0] 1 end]
} else { 
  set user [finduser $arg![getchanhost $arg $chan]]
  }
  if {![validuser $user]} {notice $nick "\002deluser\002 requires more parameters." ; return}
  if {[godmode $hand] == 0 && [accessint $hand $chan] <= [accessint $user $chan]} {noaccess $chan $nick ; return}
  notice $nick "Deleted $user (with [saccess2 $user $chan] access) from the $chan user list." ; chattr $user |-CMOP $chan
}

### Enable/Disable God

proc pub_god { nick host hand chan arg } {
    if { [matchattr $hand AHN] } {
     if { [matchattr $hand I] } {
       chattr $hand -I
       notice $nick "Security override has been \002disabled\002."
       cmdlog $chan $nick $hand "god off"
    } else {
       chattr $hand +I
       notice $nick "Security override has been \002enabled\002."
       cmdlog $chan $nick $hand "god on"
     }
  } else {
    notice $nick "\002God\002 is a privileged command."
  }
}

### Channel Information

proc pub_cinfo {nick host hand chan arg} {
set owner [userlist |N $chan]
set access [lindex $arg 1]
setudef int recvis
setudef str registrar
setudef int regon

 notice $nick "\002$chan\002 Information:"
 notice $nick "Owner(s):             $owner"
 notice $nick "Total User Count:     [llength [userlist |NCMOP $chan]]"
 notice $nick "Owner Count:          [llength [userlist |N $chan]]"
 notice $nick "Coowner Count:        [llength [userlist |C $chan]]"
 notice $nick "Master Count:         [llength [userlist |M $chan]]"
 notice $nick "Op Count:             [llength [userlist |O $chan]]"
 notice $nick "Peon Count:           [llength [userlist |P $chan]]"
 notice $nick "Record Visitors:      [channel get $chan recvis]"
 notice $nick "Registrar:            [channel get $chan registrar]"
 notice $nick "Registered:           [ctime [channel get $chan regon]]"
}

### Channel Registrar

proc pub_registrar {nick host hand chan arg} {
 notice $nick "\002$chan\002\ was registered by \002[channel get $chan registrar]\002"
}

### Record Users

proc rusers {nick host hand chan arg} {
setudef int recvis
 notice $nick "\002$chan\002\: Record Users: \002[channel get $chan recvis]\002"
}

proc usrjoin { nick host hand chan } {
if { [channel get $chan recvis] < [llength [chanlist $chan]] } {
      channel set $chan recvis [llength [chanlist $chan]]
 }
}

### Invite User To Channel

proc pub_invite {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 1} {noaccess $chan $nick ; return}
 set thenick [lindex $arg 0]
 set thechan [lindex $arg 1]
 if {$thenick == ""} {notice $nick "\002invite\002 requires more parameters." ; return}
 if {$thechan == ""} {set thechan $chan}
 if {[onchan $thenick $thechan]} {notice $nick "\002$thenick\002 is already in \002$thechan\002." ; return}
 putquick "INVITE $thenick $thechan"
 notice $nick "Invited \002$thenick\002 to \002$thechan\002."
 notice $thenick "You have been invited to \002$thechan\002 by \002$nick\002."
}

### Invite Self To Channel

proc pub_inviteme {nick uhost hand chan arg} {
 set thechan [lindex $arg 0]
 if {$thechan == ""} {notice $nick "You are already in \002$chan\002" ; return}
 if {[godmode $hand] == 0 && [accessint $hand $thechan] <= 0} {noaccess $thechan $nick ; return}
 if {[onchan $nick $thechan]} {notice $nick "You are already in \002$thechan\002." ; return}
 putquick "INVITE $nick $thechan"
 notice $nick "You have been invited to join \002$thechan\002."
}

### Invite Self To Staff Channel

proc pub_staffchan {nick uhost hand chan arg} {
global channel staff
 if {$staff(channel) == ""} {notice $nick "You are already in \002$chan\002." ; return}
 if {[godmode $hand] == 0 && [accessint $hand $staff(channel)] <= 0} {noaccess $staff(channel) $nick ; return}
 if {[onchan $nick $staff(channel)]} {notice $nick "You are already in \002$staff(channel)\002." ; return}
 putquick "INVITE $nick $staff(channel)"
 notice $nick "You have been invited to join \002$staff(channel)\002"
}

### Channel Modes

proc pub_mode {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 1} {noaccess $chan $nick ; return}
 if {$arg == ""} {notice $nick "\002mode\002 requires more parameters." ; return}
  set mode [lrange $arg 0 6]
  putquick "mode $chan :$mode"
 notice $nick "Channel modes are now \002$arg\002."
}

### Give Op To User

proc pub_op {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 2} {noaccess $chan $nick ; return}
 if {$arg == ""} {notice $nick "\002op\002 requires more parameters." ; return}
  putquick "mode $chan +ooooooo $arg"
 notice $nick "Opped users in \002$chan\002."
}

### Give Halfop To User

proc pub_hop {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 2} {noaccess $chan $nick ; return}
 if {$arg == ""} {notice $nick "\002ho\002 requires more parameters." ; return}
  putquick "mode $chan +hhhhhhh $arg"
 notice $nick "Halfopped users in \002$chan\002."
}

### Remove Halfop From User

proc pub_delhop {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 2} {noaccess $chan $nick ; return}
 if {$arg == ""} {notice $nick "\002delho\002 requires more parameters." ; return}
  putquick "mode $chan -hhhhhhh $arg"
 notice $nick "Removed halfop users in \002$chan\002."
}

### Remove Op From user

proc pub_deop {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 2} {noaccess $chan $nick ; return}
 if {$arg == ""} {notice $nick "\002deop\002 requires more parameters." ; return}
  putquick "mode $chan -ooooooo $arg"
 notice $nick "Deopped users in \002$chan\002."
}

### Give Voice To User

proc pub_voice {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 1} {noaccess $chan $nick ; return}
 if {$arg == ""} {notice $nick "\002voice\002 requires more parameters." ; return}
  putquick "mode $chan +vvvvvvv $arg"
  notice $nick "Voiced users in \002$chan\002."
}

### Remove Voice From User

proc pub_devoice {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 1} {noaccess $chan $nick ; return}
 if {$arg == ""} {notice $nick "\002devoice\002 requires more parameters." ; return}
  putquick "mode $chan -vvvvvvv $arg"
  notice $nick "Devoiced users in \002$chan\002."
}

### Channel Userlist

proc users {nick host hand chan arg} {
  if {$arg == ""} {
  set thechan $chan
  notice $nick "\002$thechan\002 user list:"
  notice $nick "Access  Account"
  if { [set users [userlist |N $thechan]] == "" } { set users "None" }
  notice $nick "500     [join $users]"
  if { [set users1 [userlist |C $thechan]] == "" } { set users1 "None" }
  if { [set users2 [userlist |M $thechan]] == "" } { set users2 "None" }
  notice $nick "400     [join $users1]"
  notice $nick "300     [join $users2]"
  if { [set users3 [userlist |O $thechan]] == "" } { set users3 "None" }
  if { [set users4 [userlist |P $thechan]] == "" } { set users4 "None" }
  notice $nick "200     [join $users3]" 
  notice $nick "100     [join $users4]"
 } else {
  set thechan $arg
  notice $nick "\002$thechan\002 user list:"
  notice $nick "Access  Account"
  if { [set users [userlist |N $thechan]] == "" } { set users "None" }
  notice $nick "500     [join $users]"
  if { [set users1 [userlist |C $thechan]] == "" } { set users1 "None" }
  if { [set users2 [userlist |M $thechan]] == "" } { set users2 "None" }
  notice $nick "400     [join $users1]" 
  notice $nick "300     [join $users2]"
  if { [set users3 [userlist |O $thechan]] == "" } { set users3 "None" }
  if { [set users4 [userlist |P $thechan]] == "" } { set users4 "None" }
  notice $nick "200     [join $users3]"
  notice $nick "100     [join $users4]"
  }
}  

### List Owners Only

proc wlist {nick host hand chan arg} {
 if { [set users [userlist |N $chan]] == "" } { set users "None" }
 notice $nick "\002$chan\002 users with \002500\002 access:"
 notice $nick "[join $users]"
}

### List Coowners Only

proc clist {nick host hand chan arg} {
 if { [set users [userlist |C $chan]] == "" } { set users "None" }
 notice $nick "\002$chan\002 users with \002400\002 access:"
 notice $nick "[join $users]"
}

### List Masters Only

proc mlist {nick host hand chan arg} {
 if { [set users [userlist |M $chan]] == "" } { set users "None" }
 notice $nick "\002$chan\002 users with \002300\002 access:"
 notice $nick "[join $users]"
}

### List Ops Only

proc olist {nick host hand chan arg} {
 if { [set users [userlist |O $chan]] == "" } { set users "None" }
 notice $nick "\002$chan\002 users with \002200\002 access:"
 notice $nick "[join $users]"
}

### List Peons Only

proc plist {nick host hand chan arg} {
 if { [set users [userlist |P $chan]] == "" } { set users "None" }
 notice $nick "\002$chan\002 users with \002100\002 access:"
 notice $nick "[join $users]"
}

### Show Current Installed Version

proc pub_version {nick uhost hand chan arg} {
global version adminserv
global versionarch adminserv
 if {$arg == "arch"} {
  putquick "notice $nick :$adminserv(version)"
  putquick "notice $nick :$adminserv(versionarch)"
 } elseif {$arg == ""} {
  putquick "notice $nick :$adminserv(version)"
  }
}

set ctcps {
 {\002$botnick\002 Channel Services v2.0 (alpha), Built: April 20, 2004, 18:49:55}
}

### Show Current Installed Version via CTCP Version Reply

proc ctcpreply {nick uhost handle dest keyword text} {
global ctcps ctcp-version
set {ctcp-version} [lindex $ctcps [rand [llength $ctcps]]]
}

### Op Self In Channel

proc pub_up {nick uhost hand chan arg} {
  if {[validuser $hand]} {
      if { [accessint $hand $chan] > 1} {
       putquick "mode $chan +o $nick"
      }
      if { [accessint $hand $chan] == 1} {
       putquick "mode $chan +v $nick"
     }
  }
}

### Deop Self In Channel

proc pub_down {nick uhost hand chan arg} {
  if { [isop $nick $chan] } {
   putquick "mode $chan -o $nick"
   }
   if { [isvoice $nick $chan] } {
    putquick "mode $chan -v $nick"
   }
}

### Op Self In All Channels

proc pub_upall {nick host hand chan arg} {
   foreach i [channels] {
     if { [validuser $hand] } {
       if { [accessint $hand $chan] > 1} {
          putquick "mode $i +o $nick"
         }    
         if { [accessint $hand $chan] == 1} {
          putquick "mode $i +v $nick"
        }
     }
  }
}

### Deop Self In All Channels

proc pub_downall {nick host hand chan arg} {
  foreach i [channels] {
    if { [isop $nick $i] } {
     putquick "mode $i -o $nick"
     }
     if { [isvoice $nick $i] } {
       putquick "mode $i -v $nick"
      }
   }
}

### Set Channel Topic

proc pub_topic {nick uhost hand chan arg} {
 if {[godmode $hand] == 0 && [accessint $hand $chan] <= 3} {noaccess $chan $nick ; return}
  if {$arg == "" && [getsets $chan topic] == "*"} {putquick "NOTICE $nick :There is no default topic for $chan." ; return}
   if {$arg == "" && [getsets $chan topic] != "*"} {putquick "TOPIC $chan :[getsets $chan topic]" ; return}
  putquick "TOPIC $chan :$arg"
  putquick "notice $nick :Topic for $chan is now '\002$arg\002'."
}  

### Set Greeting/Autovoice/Autoop/Defaulttopic

proc pub_set {nick uhost hand chan arg} {
 set what [lindex $arg 0];set ar [lrange $arg 1 end]
 switch $what {
  "greeting" {setgreet $ar $chan $nick $hand}
  "autovoice" {setav $ar $chan $nick $hand}
  "autoop" {setao $ar $chan $nick $hand}
  "defaulttopic" {settop $ar $chan $nick $hand}
  default {pub_set2 $nick $uhost $hand $chan $arg}
 }
}

### Set Greeting

proc setgreet {trig chan nick hand} { 
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 3} {noaccess $chan $nick ; return}
 set t $trig;set aa "";set fp [open data/$chan/sets r]
 while {![eof $fp]} {
  gets $fp aa
  if {![string equal -nocase [lindex [split $aa] 0] greeting]} {
   if {[info exists aa]&&$aa!=""} {lappend allEntrys $aa}
  } else {lappend allEntrys "[lindex [split $aa] 0] [join $t]"}
 }
 close $fp;set fp [open data/$chan/sets w];foreach aa $allEntrys {puts $fp $aa};close $fp
 putnot $nick "\002Greeting\002 set to: $t"
}

### Set Topic

proc settop {trig chan nick hand} { 
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 3} {noaccess $chan $nick ; return}
 set t $trig;set aa "";set fp [open data/$chan/sets r]
 while {![eof $fp]} {
  gets $fp aa
  if {![string equal -nocase [lindex [split $aa] 0] topic]} {
   if {[info exists aa]&&$aa!=""} {lappend allEntrys $aa}
  } else {lappend allEntrys "[lindex [split $aa] 0] [join $t]"}
 }
 close $fp;set fp [open data/$chan/sets w];foreach aa $allEntrys {puts $fp $aa};close $fp
 putnot $nick "\002defaulttopic\002 set to: $t"
}

### Set AutoOp

proc setao {trig chan nick hand} {
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 3} {noaccess $chan $nick ; return}
 set t [string tolower $trig];set aa "";set fp [open data/$chan/sets r]
 if {$t != "off" && $t != "on"} {
 putnot $nick "Auto-Op Options: \002On\002 or \002Off\002"
 }
 while {![eof $fp]} {
  gets $fp aa
   if {![string equal -nocase [lindex [split $aa] 0] autoop]} {
    if {[info exists aa]&&$aa!=""} {lappend allEntrys $aa}
    } else {lappend allEntrys "[lindex [split $aa] 0] [join $t]"}
  }
  close $fp;set fp [open data/$chan/sets w];foreach aa $allEntrys {puts $fp $aa};close $fp
  putnot $nick "\002Auto-Op\002 set to: $t"
}

### Set AutoVoice

proc setav {trig chan nick hand} {
  if {[godmode $hand] == 0 && [accessint $hand $chan] < 3} {noaccess $chan $n ; return}
 set t [string tolower $trig];set aa "";set fp [open data/$chan/sets r]
 if {$t != "off" && $t != "on"} {
 putnot $nick "Auto-Voice Options: \002On\002 or \002Off\002"
 }
 while {![eof $fp]} {
  gets $fp aa
   if {![string equal -nocase [lindex [split $aa] 0] autovoice]} {
    if {[info exists aa]&&$aa!=""} {lappend allEntrys $aa}
    } else {lappend allEntrys "[lindex [split $aa] 0] [join $t]"}
  }
  close $fp;set fp [open data/$chan/sets w];foreach aa $allEntrys {puts $fp $aa};close $fp
  putnot $nick "\002Auto-Voice\002 set to: $t"
}

proc getsets {chan what} {
 set what [lindex $what 0];set fp [open data/$chan/sets r]
 while {![eof $fp]} {
  gets $fp aa
   if {[string equal -nocase [lindex [split $aa] 0] $what]} {
    if {[info exists aa]&&$aa!=""} {set ans $aa}
   }
 }
 close $fp
 return [lrange $ans 1 end]
}

proc pub_set2 {nick uhost hand chan arg} {
putquick "NOTICE $nick :\002Channel Options:\002" ;
putquick "NOTICE $nick :\002Topic\002 : \002Greeting\002 : \002Auto-Op\002 : \002Auto-Voice\002" ; return}

### Force Services To Say Something

proc pub_say {nick uhost hand chan arg} {
  global botnick
  if {[godmode $hand] == 0} {nooverride $nick ; return}
  if {$arg == ""} {putquick "NOTICE $nick :\002say\002 requires more parameters." ; return 0}
  putchan $chan "$arg"
}

### PING REPLY

proc pub_ping {nick host hand chan arg} {
putchan $chan "\002$nick\002\: Pong!"
}

### TOYS

proc pub_sex {nick host hand chan arg} {
putchan $chan "\002$nick\002\: No! I will not be part of your gangbangin' orgies!"
}

proc pub_banana {nick host hand chan arg} {
putchan $chan "\002$nick\002\: No thanks on the banana, however you can try, I'm sure you're loose enough."
}

proc pub_wut {nick host hand chan arg} {
putchan $chan "\002$nick\002\: wut... Wut... WUT?!"
}

### 8Ball

set yes 0
set no 0
set question "test"

proc pub_8ball {nick host handle channel arg} {
set question "response"
  set cmd [string tolower [lindex $arg 0]]
  if {$cmd == ""} {
    putquick "NOTICE $nick :\0028ball\002 requires more parameters."
    return 0
  }
  if {[file exists 8ball.txt]} {
    set list [open 8ball.txt r]
    set response ""
    while {![eof $list]} {
      set tmp [gets $list]
      set response [lappend response [string trim $tmp]]
    }
    close $list
  } else {putquick "NOTICE $nick :Cannot locate 8ball.txt"}
  set number [rand [expr [llength $response] + 1]]
  putquick "PRIVMSG $channel :\002$nick\002: [lindex $response $number]"
}

### List All Staff

proc pub_liststaff {nick host hand chan arg} {
 global botnick
  notice $nick "\002$botnick Staff\002:"
  if { [set users1 [userlist A]] == "" } { set users1 "None" }
  if { [set users2 [userlist N]] == "" } { set users2 "None" }
  if { [set users3 [userlist H]] == "" } { set users3 "None" }
  notice $nick "\002Administrators\002:"
  notice $nick "[join $users1]"
  notice $nick "\002Network Helpers\002:"
  notice $nick "[join $users2]"
  notice $nick "\002Helpers\002:"
  notice $nick "[join $users3]"
}

### List Helpers Only

proc pub_listhelpers {nick host hand chan arg} {
 global botnick
  notice $nick "\002$botnick Helpers\002:"
  if { [set users1 [userlist A]] == "" } { set users1 "None" }
  if { [set users2 [userlist N]] == "" } { set users2 "None" }
  if { [set users3 [userlist H]] == "" } { set users3 "None" }
  notice $nick "[join $users3]"
}

### List Network Helpers Only

proc pub_listnhelpers {nick host hand chan arg} {
 global botnick
  notice $nick "\002$botnick Network Helpers\002:"
  if { [set users1 [userlist A]] == "" } { set users1 "None" }
  if { [set users2 [userlist N]] == "" } { set users2 "None" }
  if { [set users3 [userlist H]] == "" } { set users3 "None" }
  notice $nick "[join $users2]"
}

### List Administrators Only

proc pub_listadmins {nick host hand chan arg} {
 global botnick
  notice $nick "\002$botnick Administrators\002:"
  if { [set users1 [userlist A]] == "" } { set users1 "None" }
  if { [set users2 [userlist N]] == "" } { set users2 "None" }
  if { [set users3 [userlist H]] == "" } { set users3 "None" }
  notice $nick "[join $users1]"
}

### Infoline/Setinfo

proc pub_setinfo {nick host hand chan arg} {
  if {[godmode $hand] == 0 && [accessint $hand $chan] <= 0} {noaccess $chan $nick ; return}
  setchaninfo $hand $chan $arg
  putnot $nick "\[\002$nick\002\] $arg"
}

proc pub_netinfo {nick host hand chan text} {
global channel official
 global version admin server-online
 set uptimer [unixtime]
 incr uptimer -${server-online}
 global botnick trigger
 putquick "NOTICE $nick :\002$botnick Information\002:"
 putquick "NOTICE $nick :$botnick Version:       v2.0 (stable)"
 putquick "NOTICE $nick :Official Channel:         $official(channel)"
 putquick "NOTICE $nick :$botnick Host Admin:    $admin"
 putquick "NOTICE $nick :Uptime:                   [duration $uptimer]"
 putquick "NOTICE $nick :Total User Count:         [countusers]"
}

proc pub_uptime {nick host hand chan text} {
 global version admin server-online
 set uptimer [unixtime]
 incr uptimer -${server-online}
 putquick "NOTICE $nick :\002Uptime\002:  [duration $uptimer]"
}

proc on_join_greeting { nick uhost hand chan } {
 if { [getsets $chan greeting] == "*" } {return}
 putnot $nick "\002\002($chan) [uhg_filter $nick $uhost $hand $chan [getsets $chan greeting]]"
}

proc on_join_staff { nick host hand chan } {
 global channel official
 global botnick
 if {$chan == "$official(channel)"} {return}
  if {[staff $hand]} {
   notice $nick "($chan) You are recognized as a \002$botnick Staff Member\002. You will be \002Auto-Voiced\002."
   putserv "mode $chan +v $nick"
   }
   if {$nick == $botnick} {
    putquick "MODE $chan +o $botnick"
  }
} 

proc on_join_chansets { nick uhost hand chan } {
 if {[matchattr $hand |+NCMO $chan]} {
  putquick "MODE $chan +o $nick"
 } elseif {[matchattr $hand |+P $chan]} {
  putquick "MODE $chan +v $nick"
 } elseif {[getsets $chan autovoice] == "on"} {
    putquick "MODE $chan +v $nick"  
 } elseif {[getsets $chan autoop] == "on"} {
    putquick "MODE $chan +o $nick" 
  }
}

proc getsets {chan what} {
 set what [lindex $what 0];set fp [open data/$chan/sets r]
 while {![eof $fp]} {
  gets $fp aa
   if {[string equal -nocase [lindex [split $aa] 0] $what]} {
    if {[info exists aa]&&$aa!=""} {set ans $aa}
   }
 }
 close $fp
 return [lrange $ans 1 end]
}

proc uhg_filter {nick uhost hand chan q} {
 regsub -all "\{" $q "" q
 regsub -all "\}" $q "" q
 regsub -all "\\\%rnick%" $q "[r_nick $chan]" q
 regsub -all "\\\%nick%" $q $nick q
 regsub -all "\\\%date%" $q "[ctime [unixtime]]" q
 regsub -all "\\\%hand%" $q $hand q
 regsub -all "\\\%host%" $q $uhost q
 regsub -all "\\\%chan%" $q $chan q
 return $q
}

proc r_nick {chan} {set randn [lindex [split [chanlist "$chan"]] [rand [llength [split [chanlist "$chan"]]]]];return $randn}

proc staff { hand } {
  if { [matchattr $hand AHN] } {
    return 1
  } else {
    return 0
  }
}

proc putchan {chan msg} { set what "[join [split $msg]]" ; putquick "PRIVMSG $chan :\002\002$what" }

proc putnot {nick msg} { putquick "NOTICE $nick :$msg" }

proc oaccess { hand } {
  if { [matchattr $hand A] } {
    return "Administrator"
  }
  if { [matchattr $hand N] } {
    return "Network Helper"
  }
  if { [matchattr $hand H] } {
    return "Helper"
  }
 return Basic
}

proc staff { hand } {
  if { [matchattr $hand AHN] } {
    return 1
  } else {
    return 0
  }
}

proc accessint { hand chan } {
  if { [matchattr $hand |N $chan] } {
    return 5
  }
  if { [matchattr $hand |C $chan] } {
    return 4
  }
  if { [matchattr $hand |M $chan] } {
    return 3
  }
  if { [matchattr $hand |O $chan] } {
    return 2
  }
  if { [matchattr $hand |P $chan] } {
    return 1
   } 
  return 0
}

proc saccess { hand chan } {
  if { [matchattr $hand |N $chan] } {
    return "has \002500\002 access"
  }
  if { [matchattr $hand |C $chan] } {
    return "has \002400\002 access"
  }
  if { [matchattr $hand |M $chan] } {
    return "has \002300\002 access"
  }
  if { [matchattr $hand |O $chan] } {
    return "has \002200\002 access"
  }
  if { [matchattr $hand |P $chan] } {
    return "has \002100\002 access"
  }
  return "lacks access"
}

proc saccess2 { hand chan } {
  if { [matchattr $hand |N $chan] } {
    return "\002500\002"
  }
  if { [matchattr $hand |C $chan] } {
    return "\002400\002"
  }
  if { [matchattr $hand |M $chan] } {
    return "\002300\002"
  }
  if { [matchattr $hand |O $chan] } {
    return "\002200\002"
  }
  if { [matchattr $hand |P $chan] } {
    return "\002100\002"
   }
}

proc noaccess {chan who} {
  putquick "NOTICE $who :You lack access in $chan to use this command."
}

proc nooverride {who} {
  putquick "NOTICE $who :You must have \002security override\002 (helping mode) on to use this command."
}

proc notice {who what} {
  putquick "NOTICE $who :$what"
}

proc cmdlog { chan nick hand what } {
global channel staff
  putquick "NOTICE $staff(channel) :($chan) \[$nick:$hand\] $what"
}  

proc godmode { hand } {
  if { [matchattr $hand I] } {
    return 1
  } else {
    return 0
  }
}

proc cleanarg {arg} {
 set temp ""
  for {set i 0} {$i < [string length $arg]} {incr i} {
  set char [string index $arg $i]
  if {($char != "\12") && ($char != "\15")} {
   append temp $char
  }
 }
 set temp [string trimright $temp "\}"]
 set temp [string trimleft $temp "\{"]
  return $temp
}

proc pub_fix2 {n u h c a} {
 file mkdir data
 foreach chan [channels] {
  file mkdir data/$chan;set fp [open data/$chan/sets w+]
  puts $fp "greeting *"
  puts $fp "autovoice off"
  puts $fp "autoop off"
  puts $fp "topic *"
  close $fp
  }
}

putlog "AdminServ chanserv.c loaded"