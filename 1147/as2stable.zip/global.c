#---------------------------------------------------
# AdminServ v2.0 (stable)
#
# *
#
# AdminServ is a channel service bot, 
# intended primarily to act as a 
# complete combination of ChanServ, 
# NickServ, OpServ, HelpServ, and 
# Global.
#
# For questions & comments, you may
# visit http://adminserv.cmx-networks.net
# or irc.hazenet.org on channel
# #adminserv
#
# *
#
# global.c
# 
# *
#
# $Id: global.c,v 2.0 2004/04/20 18:49:55 emac Exp $
#
#---------------------------------------------------

bind pub - ${trigger}global pub_global
bind pub - ${trigger}aglobal pub_aglobal

proc pub_global {nick host hand chan text} {
 if {[godmode $hand] == 0} {nooverride $nick ; return}
	foreach chan [channels] { putquick "Privmsg $chan :\002|Announcement|\002$nick: $text" }
}

proc pub_aglobal {nick host hand chan text} {
   if {[godmode $hand] == 0} {nooverride $nick ; return}
	foreach chan [channels] { putquick "Privmsg $chan :\002|Announcement|\002Anonymous: $text" }
}

proc godmode { hand } {
  if { [matchattr $hand I] } {
    return 1
  } else {
    return 0
  }
}

proc notice {who what} {
        putquick "NOTICE $who :$what"
}
proc cmdlog { chan nick hand what } {
global channel staff
  putquick "NOTICE $staff(channel) :($chan) \[$nick:$hand\] $what"
} 
proc nooverride {who} {
  putquick "NOTICE $who :You must have security override (helping mode) on to use this command."
}

putlog "AdminServ global.c loaded"
