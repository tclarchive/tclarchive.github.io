#---------------------------------------------------
# AdminServ v2.0 (stable)
#
# *
#
# AdminServ is a channel service bot, 
# intended primarily to act as a 
# complete combination of ChanServ, 
# NickServ, OpServ, HelpServ, and 
# Global.
#
# For questions & comments, you may
# visit http://adminserv.cmx-networks.net
# or irc.hazenet.org on channel
# #adminserv
#
# *
#
# help.c
# 
# *
#
# $Id: help.c,v 2.0 2004/04/20 18:49:55 emac Exp $
#
#---------------------------------------------------

bind pub - ${trigger}help help

proc help {nick host hand chan what} {
global botnick
 switch -glob -- $what {
 "me" {
   notice $nick "\002Help Me\002"
   notice $nick "The only way I would help is by giving you a one way ticket to neverland."
}
 "emac" {
   notice $nick "Using the -f flag with 'rm /her/pants' could get you arrested."
}
 "oper" {
   notice $nick "SAY        Have $botnick say a message in a channel."
   notice $nick "GOD        Trigger security override on/off."
   notice $nick "CSUSPEND   Remove $botnick from a channel (Keeping channel database)."
   notice $nick "CUNSUSPEND Restore $botnick to a channel that was suspended."
   notice $nick "CHANNELS   List all channels $botnick is currently in."
   notice $nick "OPCHAN     Force $botnick to op itself in a channel."
   notice $nick "REG        Register a new channel with $botnick."
   notice $nick "UNREG      Remove $botnick from a registered channel (Removing channel database)."
   notice $nick "ADDOWNER   Add a new owner to a channel."
}
 "8ball" {
   notice $nick "\0028BALL\002"
   notice $nick "8ball <question>"
   notice $nick "Displays a random reply when asked a question."
}
 "ping" {
   notice $nick "\002PING\002"
   notice $nick "Displays a ping/pong reply."
}
 "sex" {
   notice $nick "\002SEX\002"
   notice $nick "$botnick replies back with a sexual remark."
   notice $nick "\002See also\002: wut, banana"
}
 "banana" {
   notice $nick "\002BANANA\002"
   notice $nick "$botnick replies back with a sexual remark."
   notice $nick "\002See also\002: wut, sex"
} 
 "wut" {
   notice $nick "\002WUT\002"
   notice $nick "$botnick replies back with a remark."
   notice $nick "\002See also\002: banana, sex"
} 
 "toys" {
   notice $nick "8BALL      Displays a random reply when asked a question."
   notice $nick "PING       Displays a ping/pong reply."
   notice $nick "SEX        $botnick replies back with a sexual remark."
   notice $nick "BANANA     $botnick replies back with a sexual remark."
   notice $nick "WUT        $botnick replies back with a remark."
}
 "seen" {
   notice $nick "\002SEEN\002"
   notice $nick "seen <nick>"
   notice $nick "Displays the last time the specified user was in the channel."
   notice $nick "\002See also\002: access, users"
}
 "helpers" {
   notice $nick "\002HELPERS\002"
   notice $nick "Shows a list of all current $botnick helpers."
   notice $nick "\002See also\002: staff, admins, nhelpers"
}
 "nhelpers" {
   notice $nick "\002NHELPERS\002"
   notice $nick "Shows a list of all current $botnick administrators."
   notice $nick "\002See also\002: staff, admins, helpers"
}
 "admins" {
   notice $nick "\002ADMINS\002"
   notice $nick "Shows a list of all current $botnick global administrators."
   notice $nick "\002See also\002: staff, nhelpers, helpers"
}
 "staff" {
   notice $nick "\002STAFF\002"
   notice $nick "Shows a list of all current $botnick staff."
   notice $nick "\002See also\002: admins, nhelpers, helpers"
}
 "stats" {
   notice $nick "\002STATS\002"
   notice $nick "View information about $botnick."
}
 "version" {
   notice $nick "\002VERSION\002"
   notice $nick "View the current running version of $botnick. Add ARCH after version for more detailed version information."
}
 "information" {
   notice $nick "VERSION    View the current running version of $botnick."
   notice $nick "STATS      View information about $botnick."
   notice $nick "STAFF      Shows a list of all current $botnick staff."
   notice $nick "ADMINS     Shows a list of all current $botnick administrators."
   notice $nick "NHELPERS   Shows a list of all current $botnick network helpers."
   notice $nick "HELPERS    Shows a list of all current $botnick helpers."
   notice $nick "SEEN       Displays the last time the specified user was in the channel."
}
 "set" {
   notice $nick "\002SET\002"
   notice $nick "set <command>"
   notice $nick "Set numerous channel settings. Using set with no command displays all available commands."
   notice $nick "\002See also\002: info"
}
 "info" {
   notice $nick "\002INFO\002"
   notice $nick "View information about a given channel."
   notice $nick "\002See also\002: set"
} 
 "inviteme" {
   notice $nick "\002INVITEME\002"
   notice $nick "inviteme <channel>"
   notice $nick "Invite yourself into a channel you have access to."
   notice $nick "\002See also\002: invite"
}
 "invite" {
   notice $nick "\002INVITE\002"
   notice $nick "invite <nick> \[channel\]"
   notice $nick "Invite yourself or others into a channel."
   notice $nick "\002See also\002: inviteme"
}
 "modelist" {
   notice $nick "\002MODELIST\002"
   notice $nick "modelist"
   notice $nick "View available modes."
   notice $nick "\002See also\002: mode"
}
 "mode" {
   notice $nick "\002MODE\002"
   notice $nick "Set channel modes."
   notice $nick "\002See also\002: modelist"
}
 "topic" {
   notice $nick "\002TOPIC\002"
   notice $nick "Set a new topic, or reset defaulttopic."
   notice $nick "\002See also\002: defaulttopic"
}
 "kickban" {
   notice $nick "\002KICKBAN\002"
   notice $nick "kickban <nick> \[reason\]"
   notice $nick "Kickban user from given channel."
   notice $nick "\002See also\002: kick"
}
 "kick" {
   notice $nick "\002KICK\002"
   notice $nick "kick <nick> \[reason\]"
   notice $nick "Kick user from given channel."
   notice $nick "\002See also\002: kickban"
}
 "unbanall" {
   notice $nick "\002UNBANALL\002"
   notice $nick "Unbans all users from the given channel."
   notice $nick "\002See also\002: ban, unban"
}
 "unban" {
   notice $nick "\002UNBAN\002"
   notice $nick "unban <nick>"
   notice $nick "Unban a user from the given channel."
   notice $nick "\002See also\002: ban, unbanall"
}
 "ban" {
   notice $nick "\002BAN\002"
   notice $nick "ban <nick|*account>"
   notice $nick "Ban a user from the given channel."
   notice $nick "\002See also\002: unban, unbanall"
}
 "bans" {
   notice $nick "\002BANS\002"
   notice $nick "List all bans in a channel."
   notice $nick "\002See also\002: wlist, clist, mlist, olist"
}
 "plist" {
   notice $nick "\002PLIST\002"
   notice $nick "List all peons (100) of a channel."
   notice $nick "\002See also\002: wlist, clist, mlist, olist"
}
 "olist" {
   notice $nick "\002OLIST\002"
   notice $nick "List all ops (200) of a channel."
   notice $nick "\002See also\002: wlist, clist, mlist, plist"
}
 "mlist" {
   notice $nick "\002MLIST\002"
   notice $nick "List all masters (300) of a channel."
   notice $nick "\002See also\002: wlist, clist, olist, plist"
}
 "clist" {
   notice $nick "\002CLIST\002"
   notice $nick "List all coowners (400) of a channel."
   notice $nick "\002See also\002: wlist, mlist, olist, plist"
}
 "wlist" {
   notice $nick "\002WLIST\002"
   notice $nick "List all owners (500) of a channel."
   notice $nick "\002See also\002: clist, mlist, olist, plist"
}
 "users" {
   notice $nick "\002USERS\002"
   notice $nick "Lists all users with access levels between Owner - Peon (500 - 100)."
   notice $nick "\002See also\002: info"
}
 "channel" {
   notice $nick "USERS      List all users (100-500) in a channel and their access levels."
   notice $nick "WLIST      List all owners (500) of a channel."
   notice $nick "CLIST      List all coowners (400) of a channel."
   notice $nick "MLIST      List all masters (300) of a channel."
   notice $nick "OLIST      List all ops (200) of a channel."
   notice $nick "PLIST      List all peons (100) of a channel."
   notice $nick "BANS       List all bans in a channel."
   notice $nick "BAN        Ban a user from the given channel."
   notice $nick "UNBAN      Unban a user from the given channel."
   notice $nick "UNBANALL   Unbans all users from the given channel."
   notice $nick "KICK       Kick user from given channel."
   notice $nick "KICKBAN    Kickban user from given channel."
   notice $nick "TOPIC      Set a new topic, or reset defaulttopic."
   notice $nick "MODE       Set channel modes."
   notice $nick "MODELIST   View available modes."
   notice $nick "INVITE     Invite yourself or others into a channel."
   notice $nick "INVITEME   Invite yourself into a channel you have access to."
   notice $nick "INFO       View information about a given channel."
   notice $nick "SET        Set numerous channel settings."
}
"setinfo" {
   notice $nick "\002SETINFO\002"
   notice $nick "setinfo <infolinehere>"
   notice $nick "This command will set a user defined information message to be displayed when you join the channel. By setting the message to '*', you will clear your infoline."
   notice $nick "\002See also\002: access"
}
"devoice" {
   notice $nick "\002DEVOICE\002"
   notice $nick "devoice <user1> \[user2\]..."
   notice $nick "Devoices the specified nick in the specified channel."
   notice $nick "\002See also\002: voice"
}
"voice" {
   notice $nick "\002VOICE\002"
   notice $nick "voice <user1> \[user2\]..."
   notice $nick "Voices the specified nick in the specified channel."
   notice $nick "\002See also\002: devoice"
}
"deop" {
   notice $nick "\002DEOP\002"
   notice $nick "deop <user1> \[user2\]..."
   notice $nick "This command makes AdminServ op the specified user."
   notice $nick "\002See also\002: op"
}
"op" {
   notice $nick "\002OP\002"
   notice $nick "op <user1> \[user2\]..."
   notice $nick "Deops the specified user\[s\]."
   notice $nick "\002See also\002: deop"
}
"downall" {
   notice $nick "\002DOWNALL\002"
   notice $nick "Executes the down command for each channel you have access to."
   notice $nick "\002See also\002: up, upall, down"
}
"upall" {
   notice $nick "\002UPALL\002"
   notice $nick "Executes the up command for each channel you have access in."
   notice $nick "\002See also\002: up, down, downall"
}
"down" {
   notice $nick "\002DOWN\002"
   notice $nick "This command will devoice/deop you in the selected channel."
   notice $nick "\002See also\002: up, upall, downall"
}
"up" {
   notice $nick "\002UP\002"
   notice $nick "Grants you your normal channel privileges."
   notice $nick "\002See also\002: upall, down, downall"
}
"deluser" {
   notice $nick "\002DELUSER\002"
   notice $nick "deluser <nick|*account>"
   notice $nick "This command removes someone from the channel user list."
   notice $nick "\002See also\002: addcoowner, addmaster, addop, addpeon, adduser, users"
}
"adduser" {
   notice $nick "\002ADDUSER\002"
   notice $nick "adduser <nick|*account> <level>"
   notice $nick "This command adds someone to the channel user list with the specified access level."
   notice $nick "\002See also\002: addcoowner, addmaster, addop, addpeon, deluser, users"
}
"addpeon" {
   notice $nick "\002ADDPEON\002"
   notice $nick "addpeon <nick|*account>"
   notice $nick "This command adds someone to the channel user list as a peon."
   notice $nick "\002See also\002: addcoowner, addmaster, addop, adduser, deluser, users"
}
"addop" {
   notice $nick "\002ADDOP\002"
   notice $nick "addop <nick|*account>"
   notice $nick "This command adds someone to the channel user list as a op."
   notice $nick "\002See also\002: addcoowner, addmaster, addpeon, adduser, deluser, users"
}
"addmaster" {
   notice $nick "\002ADDMASTER\002"
   notice $nick "addmaster <nick|*account>"
   notice $nick "This command adds someone to the channel user list as a master."
   notice $nick "\002See also\002: addcoowner, addop, addpeon, adduser, deluser, users"
}
"addcoowner" {
   notice $nick "\002ADDCOOWNER\002"
   notice $nick "addcoowner <nick|*account>"
   notice $nick "This command adds someone to the channel user list as a coowner."
   notice $nick "\002See also\002: addmaster, addop, addpeon, adduser, deluser, users"
}
"myaccess" {
   notice $nick "\002MYACCESS\002"
   notice $nick "myaccess <nick|*account>"
   notice $nick "Lists channels where you have access and infolines in each."
   notice $nick "Not supplying a nick/account gives your access instead of others."
   notice $nick "\002See also\002: access"
}
"access" {
   notice $nick "\002ACCESS\002"
   notice $nick "access <nick|*account>"
   notice $nick "Reports various pieces of information about a channel user, including channel and network access level, and the user's info line. If no nick or account is provided, $botnick returns your own information."
   notice $nick "\002See also\002: users, setinfo"
}
"user" {
   notice $nick "ACCESS         Check someone's access in a channel."
   notice $nick "MYACCESS       Show all channels where you have access."
   notice $nick "ADDCOOWNER     Give another person coowner status in a channel."
   notice $nick "ADDMASTER      Give another person master status in a channel."
   notice $nick "ADDOP          Give another person op status in a channel."
   notice $nick "ADDPEON        Give another person peon status in a channel."
   notice $nick "ADDUSER        Give another person access in a channel."
   notice $nick "DELUSER        Remove a person's access from a channel."
   notice $nick "UP             Give you ops in a channel you have access to."
   notice $nick "DOWN           Remove your ops in a channel."
   notice $nick "UPALL          Give you ops in all channels you have access to."
   notice $nick "DOWNALL        Remove your ops in all channels."
   notice $nick "OP             Gives ops to the specified user."
   notice $nick "DEOP           Remove ops from the specified user."
   notice $nick "VOICE          Give voice to the specified user."
   notice $nick "DEVOICE        Remove voice from the specified user."
   notice $nick "SETINFO        Gives user an infoline."
}
default {
set trigger "-"
   notice $nick "\002$botnick\002 / \002Trigger:\002 $trigger"
   notice $nick "\002$botnick\002 is a channel service bot, intended primarily to act as a complete combination of ChanServ, NickServ, OpServ, HelpServ, and Global combined."
   notice $nick "\002$botnick\002 command categories:"
   notice $nick "  USER               User management."
   notice $nick "  CHANNEL            Channel management."
   notice $nick "  INFORMATION        Informative commands."
   notice $nick "  TOYS               Entertainment commands."
   notice $nick "  OPER               Helper/IRC Operator commands."

 }
 }
}

putlog "AdminServ help.c loaded"