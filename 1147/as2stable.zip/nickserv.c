#---------------------------------------------------
# AdminServ v2.0 (stable)
#
# *
#
# AdminServ is a channel service bot, 
# intended primarily to act as a 
# complete combination of ChanServ, 
# NickServ, OpServ, HelpServ, and 
# Global.
#
# For questions & comments, you may
# visit http://adminserv.cmx-networks.net
# or irc.hazenet.org on channel
# #adminserv
#
# *
#
# Nickserv.c
# 
# *
#
# $Id: nickserv.c,v 2.0 2004/04/20 18:49:55 emac Exp $
#
#---------------------------------------------------

bind msg - register auth_register
bind msg - ident auth_auth
bind msg - auth auth_auth

proc auth_register {nick uhost hand arg} {
 global channel official
 global botnick admin
 if {$nick == $botnick} {return}
 if {[getting-users]} {notice $nick "Sorry, there is currently a userfile transfer going on. Try back in a couple of seconds." ; return}
   set account [lindex $arg 0]
   set pass [lindex $arg 1]
   set email [lindex $arg 2]
   if {$hand != "*"} { notice $nick "You Are already identified to account \002$hand\002." ; return }
   if {[validuser $account]} { notice $nick "That Account is already registered to somone else." ; return}
   if {$account == ""} { notice $nick "\002register\002 requires more parameters." ; notice $nick "/msg $botnick register <account> <password> \[email\]" ; notice $nick "Registers an account with \002$botnick\002 and adds your current hostmask. Each time you are seen by \002$botnick\002, you are automatically authed. You may do /msg $botnick auth <account> <password> only when your hostmask changes." ; return}
   if {$pass == ""} { notice $nick "Please Enter Password." ; return}
   if {$email == ""} { notice $nick "Please Enter a E-Mail Address." ; return}
   set host [join \*!\*[join [split $uhost "~"]] ""]
   adduser $account $host
   chpass $account $pass
   setuser $account XTRA "AUTH" "1"
   setuser $account XTRA "EMAIL" "$email"
   putcmdlog "<<$nick>> !$account! Registered $account ($host) with email address: $email"
   notice $nick "Account \002$account\002 has been registered for you with the hostmask \002$host\002 and email address set to \002$email\002."
   notice $nick "If you have any problems, please contact the staff in $official(channel)"
}

proc auth_auth {nick uhost hand arg} {
global channel staff
  global botnick
   set found 0
   set account [lindex $arg 0]
   set pass [lindex $arg 1]
   if {$hand != "*"} { notice $nick "You Are already identified to account: \002$hand\002." ; return }
   if {![validuser $account]} { notice $nick "Your Account does not exist, are you sure you registered?." ; return}
   if {![passwdok $account $pass]} {notice $nick "Incorrect password; please try again." ; return}
   set host [join \*!\*[join [split $uhost "~"]] ""]
   setuser $account HOSTS $host
   notice $nick "I recognize you."
   if {[matchattr $account A] == 1} {
   putquick "notice $staff(channel) :$nick \[$uhost\] identified to ADMINISTRATOR account $account."
   }
   if {[matchattr $account N] == 1} {
   putquick "notice $staff(channel) :$nick \[$uhost\] identified to NETWORK HELPER account $account." 
   }
   if {[matchattr $account H] == 1} {
   putquick "notice $staff(channel) :$nick \[$uhost\] identified to HELPER account $account." 
   }
}

putlog "AdminServ nickserv.c loaded"