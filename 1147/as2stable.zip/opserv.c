#---------------------------------------------------
# AdminServ v2.0 (stable)
#
# *
#
# AdminServ is a channel service bot, 
# intended primarily to act as a 
# complete combination of ChanServ, 
# NickServ, OpServ, HelpServ, and 
# Global.
#
# For questions & comments, you may
# visit http://adminserv.cmx-networks.net
# or irc.hazenet.org on channel
# #adminserv
#
# *
#
# ChanServ.c
# 
# *
#
# $Id: opserv.c,v 2.0 2004/04/20 18:49:55 emac Exp $
#
#---------------------------------------------------

bind pub - ${trigger}die pub_die
bind pub - ${trigger}rehash pub_rehash
bind pub - ${trigger}writeall pub_rehash
bind pub - ${trigger}wa pub_rehash
bind pub - ${trigger}restart pub_restart
bind pub - ${trigger}opchan pub_opchan

proc pub_die {nick uhost hand chan arg} {
 if {[matchattr $hand A] == 0} {noaccess2 $nick ; return}
 if {$arg == ""} { putnot $nick "\002die\002 requires more parameters." ; return}
  cmdlog $chan $nick $hand "die $arg"
  die "\002$nick\002 Issued DIE Command. (\002Reason:\002 $arg)"
}

proc pub_rehash {nick host hand chan arg} {
 if {[matchattr $hand A] == 0} {noaccess2 $nick ; return}
  notice $nick "Wrote database file on [ctime [unixtime]]"
  cmdlog $chan $nick $hand "rehash"
  rehash
}

proc pub_restart {nick host hand chan text} {
global botnick
putquick "NOTICE $nick :Restarting $botnick services."
restart
}

proc pub_opchan {nick uhost host chan arg} {
global botnick
  putquick "MODE $chan +o $botnick"
}

proc cmdlog { chan nick hand what } {
global channel staff
  putquick "NOTICE $staff(channel) :($chan) \[$nick:$hand\] $what"
}  
proc noaccess2 {who} {
   putquick "NOTICE $who :You lack access to use this command."
}

putlog "AdminServ opserv.c loaded"