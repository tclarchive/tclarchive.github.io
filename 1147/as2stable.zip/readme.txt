#---------------------------------------------------
# AdminServ v2.0 (stable)
#
# *
#
# AdminServ is a channel service bot, 
# intended primarily to act as a 
# complete combination of ChanServ, 
# NickServ, OpServ, HelpServ, and 
# Global.
#
# For questions & comments, you may
# visit http://adminserv.cmx-networks.net
# or irc.hazenet.org on channel
# #adminserv
#
# *
#
# readme.txt
# 
# *
#
# $Id: readme.txt,v 2.0 2004/04/20 18:49:55 emac Exp $
#
#---------------------------------------------------

How to setup AdminServ .TCL Version Bot
--
() Extract as2stable.zip to eggdrop/scripts/ folder.

() In your eggdrop.conf add the line
       source scripts/adminserv.conf

() Edit the adminserv.conf file for such values as nickname, official or staff channel, server IP, etc.
   If the network you wish to connect AdminSerc to, does not have an oper line (O:line), please comment
   out the oper line by adding a # at the front of the line.

() Edit eggdrop.conf for what server you wish to connect to as you normally do.

() When AdminServ joins the desired channel on network, do /msg adminserv root 
   for first time root privledges.

() Do /ctcp adminserv chat or DCC chat with AdminServ and do
       .chattr yournick +AG in the DCC party line.

   This will give you the Administrator access, and ability to use god.

--
AdminServ Flag Descriptions
--
  ::Channel Flags::
    N - Channel Owner
      - Owners have complete control over channels, and cannot be
        removed by any other access.

    C - Channel Coowner
      - Coowners have most control over channels, and can only be removed
        by the owner.

    M - Channel Master
      - Masters have much control over channels, and can be removed by
        owners and coowners.

    O - Channel Op
      - Ops have some control over channels, and can be removed by
        owners, coowners, and masters.

    P - Channel Peon
      - Peons only get voice in channels, and can be removed by
        owners, coowners, masters, and ops.

  ::Global Flags::
    A - Administrator
      - Administrators have complete control over AdminServ, and have
        the ability to kill, restart, rehash AdminServ.
    
    N - Network Helper
      - Network Helpers have much control, except for killing,
        restarting, and rehashing AdminServ.

    H - Helper
      - Helpers can do some controls, such as registering channels, and
        suspending channels.

  ::Misc Global Flags::
    G - Godmode
      - Allows user to use godmode (security override).

    I - Activate Godmode
      - This tells AdminServ if the triggered admin has godmode on or off.

--
AdminServ.conf
--
This file will load all needed files that AdminServ will work with.
  No files should be added to source scripts/whatever in the eggdrop.conf
  because this is all taken care of by adminserv.conf.

Included files are:
chanserv.c
global.c
help.c
nickserv.c
opserv.c

--
User Authentication & Registration.
--
New users must do
  /msg adminserv register account password email
in order to register.

AdminServ will automatically detect and auth you whenever it sees
that you are online via your hostmask when you registered.

In the event that you change your hostmask after registration,
you may auth to your account via
  /msg adminserv auth account password
and it will auth and add your new hostmask automatically.