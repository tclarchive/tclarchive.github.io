#!/usr/bin/ruby

require 'open-uri'

def printUsage
    puts "Usage: ./urbandict.rb [number of results] <search terms>"
end

if ARGV.length < 1
    printUsage
    exit
end

num_results = 1
if ARGV.length > 1
    arg1 = ARGV[ 0 ].to_i
    if arg1 > 0
        num_results = arg1
	ARGV.shift
    end
end

open( "http://www.urbandictionary.com/define.php?term=#{ ARGV.join( "+" ) }" ) do |html|
    text = html.read
    counter = 0
    text.scan /<p>([^>]+)</m do |url|
	puts url
        counter += 1
        if counter >= num_results
            break
        end
    end
end
