#########################################################################
#                   qstat map change notify script                      #
#                  this is a TCL script for eggdrop                     #
#         written by Lee (Moonunit) Donaghy lee295012@yahoo.com         #
#               Titan Internet 32 Player Onslaught server               #
#  ut2004://217.77.176.198:7777 http://ut2004.titaninternet.co.uk/vbb/  #
#########################################################################

EDIT ver 0.1.2: made a small change to reduce a memory leak, though a leak still happens for me
                currently restarting my eggdrop once a week.


note. this script was made with UT2004 in mind, qstat may not return anything usefull for other games.
check http://www.qstat.org for compatability.

# installation...

add 
  source/mapchangenotify.tcl 
at the bottom your eggdrop .conf

edit mapchangenotify.tcl 
 set your qstat path
 and number of servers your checking
 
create mapchangenotify.serverlist file in the style of the example file
and copy to your eggdrop/ folder


output will look something like this
eggdropbot DM-Corrugation now running on server 1 (TDM_Game_3SPN)

script should work with any game qstat supports.
see http://www.qstat.org/qstatdoc.html
you need to poll the server directly.
i.e qstat options ending with 's' like -q3s, -fcs, -ut2s  

this script won't read the masters servers
i.e qstat options ending with 'm' like -q3m
