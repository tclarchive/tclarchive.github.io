GamerIRC

/cservice = /msg G
In GamerIRC you can get a free vhost for your account. 
You can request the vhost in webinterface.
Have some questions? Read the FAQ or Forum. 
Your question is not listed? Join #support, #gamerirc or #help.


Here some details for you:

Register: 			/cservice register <password> <mail@host.tld> <mail@host.tld>
Auth:				/cservice auth <account> <password>
Request G: 			/msg R requestG <[#]channel>
Show you Vhosts:		/cservice vhost list
Set your Vhost:			/cservice vhost apply <vhost>
Set auto vhost (on auth):	/cservice vhost default <vhost>, /cservice userflags +a
GamerIRC Web: 			http://www.gamerirc.org
GamerIRC Webinterface: 		http://interface.gamerirc.org
GamerIRC FAQ:			http://www.gamerirc.org/faq.php
GamerIRC Rules: 		http://www.gamerirc.org/rules.php
GamerIRC Support (Operator):	#support
GamerIRC Help (Helper):		#help
Offical GamerIRC Chan:		#gamerirc
Learn2do:			#class