    _ ___________ _____        __  __
   (_)_   _| ___ Y  __ \      / _|/ _|
    _  | | | |_/ / /  \/ ___ | |_| |_
   | | | | |    /| |    / _ \|  _|  _|
   | |_| |_| |\ \| \__/\ (_) | | | |
   | |\___/\_| \_|\____/\___/|_| |_|
  _/ | ================ Fserve
 |__/    by: DVS01 (dvs02@earthlink.net) / thephreak (thephreak@gmail.com) 
        for: eggdrop 1.6.x
   released: October 11st, 2005?
description: OK! You're on your way to the use of a great fserve, probably one of the best developed ones yet,
             one which will be developed farther into the future, so keep your eyes open.  This README will be
             pretty long because the script is very large and detailed (easy to setup however).  So just sit 
             back and hang tight.

  - MOTD Macro System -
    If you look in motd.txt, you see that some words are prefixed with a %
    These words will be replaced with a dynamic value. Here is the whole list:

    Macro      | Description
  -------------|--------------------------------------------------------------------------------------------
    %          | A percent sign ('%')
    backsp     | A space before and after this is cut out, allows for combining macros together in one word
    bcred      | Displays the user's byte credits
    botnick    | Bot's nickname
    cred       | Displays the user's file/byte credits
    date2      | Date with 2-character year
    date4      | Date with 4-character year
    fcred      | Displays the user's file credits
    filecount  | Amount of files on the Fserve
    filecntf   | Amount of files on the Fserve, formatted with a comma between every 3 numbers (ie. 1,234,567)
    freeslots  | Amount of free Fserve slots
    kilocount  | Amount of kilobytes that the Fserve contents take up
    kilocntf   | Amount of kilobytes that the Fserve contents take up, with the comma formatting
    maxdl      | Maximum downloads allowed per user
    maxtrans   | Maximum transfers allowed per user
    maxul      | Maximum uploads allowed per user (DO NOT USE, not implemented yet)
    megcntf    | Amount of megabytes that the Fserve contents take up, with the comma formatting
    megcount   | Amount of megabytes that the Fserve contents take up
    nick       | User's IRC nickname
    ratiocred  | Displays the file/byte ratio and file/byte credits
    ratio      | Displays the file/byte ratio
    strdate    | Date in the following format: "Month Day#, Year"
    time12     | Time in 12 hour format
    time24     | Time in 24 hour format
    totalslots | Total amount of allowed Fserve slots
    trigcount  | Amount of times that the Fserve was triggered
    uhost      | User's ident@host
    usedslots  | Amount of used Fserve slots
    version    | Script version
    vdate      | Date of script release

    Anything else will be replaced with a blank.
  ------------------------------------------------------------------------------------------------------------

  - DCC Commands -
    In this first version, there aren't many dcc commands at all, in fact there is only one...

    Command       | Flag | Description
  ----------------|------|-------------------------------------------------------------------------------------
    .transfers    | +jJ  | List all of the transfers active, send and get..
    .set          | +n?  | This is a default eggdrop command, since no other dcc commands have been implemented
                         | yet, you can use this to change settings... example: set dvs_fserve(ad) 0
  ------------------------------------------------------------------------------------------------------------

  - Setting Up -
    Setting up is very easy, just read the top of jIRCserv.tcl and make your way down till you get to the
    ### End of configuration. line, and you're finished.  Most of the settings are default and probably
    should be used (you can figure this out).  Then upload eggdrop1.4.0 (or a newever version), untar, 
    ./configure, make (make install after that if you wish), and your eggdrop is ready.  Then upload
    the jIRCserv.tcl to your shell, and put it in your scripts directory, edit motd.txt to your liking and 
    upload it to your shell and move it wherever you set in jIRCserv.tcl (the dvs_fserve(motd) variable).
    Finally, edit your config file and put the line: source scripts/jIRCserv.tcl at the bottom of it (caps are
    required... I hope this helps you setup your fserve, if you have any questions, ANY QUESTIONS, please come
    by #nolimits on efnet (irc.core.com or irc.concentric.net or irc.frontiernet.net) and ask us or email DVS.


  - Feedback -
	Send feedback to DVS01 to let him know you love his work!
	Send feedback to thephreak for bug fixes, features, etc.
    Thank you for using jIRCserv and have a nice day!
