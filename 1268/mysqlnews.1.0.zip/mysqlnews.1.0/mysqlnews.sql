CREATE TABLE news (
  id bigint(20) NOT NULL auto_increment,
  nick varchar(20) DEFAULT '' NOT NULL,
  host varchar(100) DEFAULT '' NOT NULL,
  news varchar(255) DEFAULT '' NOT NULL,
  channel varchar(50) DEFAULT '' NOT NULL,
  timestamp bigint(20),
  PRIMARY KEY (id)
);