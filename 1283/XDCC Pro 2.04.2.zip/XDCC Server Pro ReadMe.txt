######################################################### 1MAR09 ##
## XDCC SERVER PRO v2.04.2 by SpiKe^^ -  XDCC Server for Eggdrop ##
###################################################################
#                                                                 #
#  XDCC Server Pro is a Single list multi-channel XDCC serving    #
#  script.                                                        #
#  Most settings done by DCC chat.                                #
#                                                                 #
#  REQUIRED Eggdrop Conf Settings:                                #
#   1. Transfer Module MUST Be Loaded and xfer-timeout 30 or less #
#   2. CTCP Module MUST Be Loaded and Set To 0 or 2               #
#                                                                 #
#  If the bot is behind a router or firewall:                     #
#    1. Search for this line in your Eggdrop Config:              #
#       #set reserved-portrange 2010:2020                         #
#       Remove the # to turn on the setting. Change the           #
#       portrange numbers, but don't use less than 10 ports.      #
#    2. Use the ports you chose above in the router setup         #
#       port forwarding section of your router:                   #
#    3. Use the ports you chose above in the firewall setup       #
#       port forwarding section of your firewall:                 #
#    4. Help Setting Firewall & Router Rules:                     #
#       http://mytclscripts.com/troubleshoot/troubleshoot.html    #
#                                                                 #
#  Add this line:  source scripts/xdcc_pro.tcl                    #
#  to your eggdrop config and rehash to load the script.          #
#  DCC chat the bot and use the command:  .xhelp                  #
#                                                                 #
#                                                                 #
#  NOTE : This script was tested with eggdrops v1.6.16 & above.   #
#  NOTE : Script requires tcl version 8.4                         #
#                                                                 #
#      Script has been well tested, and seems to be stable.       #
#                  ! USE AT YOUR OWN RISKS !                      #
#                                                                 #
###################################################################
#     Contact Options to report bugs, comments & suggestions      #
#                http://www.mytclscripts.com                      #
#                irc: undernet: #pc-mirc-help                     #
#                email: spike@mytclscripts.com                    #
#               Screen Shots Available On My Site                 #
###################################################################
#                     New In This Release                         #
#                                                                 #
#  1. Tcl Setting Change:  Default Path to Packs:  xpro(defpath)  #
#     Can now take Any Number of Directory Paths                  #
#  2. New Advanced Tcl Options:  Automatic File Checking:         #
#     Auto-Add New Files to the Xdcc Packs List                   #
#     Auto-Delete Missing Files from the Xdcc Packs List          #
#  3. Command  .apack -all  Can now also Remove any Missing Packs #
#  4. Script now Makes any Missing Directories in Default Path    #
#                                                                 #
###################################################################
#                 XDCC Server Pro Features                        #
#  1. Multi-Channel                                               #
#  2. Unlimitied Packs                                            #
#  3. Built-In Help System                                        #
#  4. Dynamic Settings Thru DCC Chat                              #
#  5. Default or Custom Server Ads                                #
#  6. Default or Custom Public !list Trigger                      #
#  7. Select Default Add Pack List Position                       #
#  8. Extensive DCC Add Pack Command Options:                     #
#     a)  Add Multiple Packs With One DCC Command                 #
#     b)  Add Pack(s) with Default or Custom Pack Descriptions    #
#     c)  Add Pack(s) at Default or Specific List Position        #
#     d)  Add All New Packs in a Directory                        #
#  9. Move Pack(s) to Specific List Position                      #
# 10. List or Delete Packs in Queue                               #
# 11. List or Kill File Sends                                     #
# 12. Ban Users From the Server                                   #
# 13. Accurate Server Download Totals                             #
# 14. Reset Server Totals Command                                 #
###################################################################
#                Includes Server Protection                       #
#  1. Flood Protection                                            #
#  2. User Must Be On Channel                                     #
#  3. Kill Send if User is Gone X Amount of Time                  #
#  4. DCC Chat Admin +m                                           #
###################################################################

XDCC Pro 2.04.2 Release Notes:

1. Tcl Setting Change:  Default Path to Packs:  xpro(defpath)
   Setting can now contain multiple directory paths  (comma separated).
   Script will now make all missing directories listed in default path.

   ## Default path(s) to packs files..
   ## Used with the DCC commands:  .apack <file>,<description>
   ##                        and:  .apack -all
   ## This is the route relative to the bot root directory
   ##   {./packs/}         : .apack check the packs directory
   ##   {./paks/,./help/}  : multiple paths  (comma separated)
   set xpro(defpath) {./filesys/}

2. New Advanced Tcl Options:  Automatic File Checking:
   Script can now automaticly add any new files to the xdcc packs list.
   Script can now automaticly delete missing files from the xdcc packs list.

   ## Auto-Add : Automaticly add new files to the packs list?
   ## ("1" = yes) ("0" = no)
   set xpro(autoadd) "0"

   ## Auto-Add checks what path(s) for new files?
   ##  {}          : check xpro(defpath)  (Default path)
   ##  {./packs/}  : check the packs directory
   ##  {./paks/,./help/}  : multiple paths  (comma separated)
   set xpro(aaddpath) {}

   ## Auto-Delete : Automaticly remove missing files from the packs list?
   ## ("1" = yes) ("0" = no)
   set xpro(autodel) "0"

   ## Auto-Delete checks what path(s) for missing files?
   ##  {}          : same as auto-add path(s)
   ##  {./packs/}  : check the packs directory
   ##  {./paks/,./help/}  : multiple paths  (comma separated)
   ##  {*}         : check All packs to see if they are missing
   set xpro(adelpath) {*}

   ## Automaticly check for new/missing files how often?  (in minutes)
   set xpro(acheck) "10"

3. New Advanced Tcl Option:
   Command  .apack -all  can now also remove any missing packs

   ## The  .apack -all  command also checks for and removes missing packs?
   ##   "0"   :No, .apack -all  does not check for missing packs.
   ##   "1"   :Check the packs in the current .apack -all  directories for missing.
   ##   "2"   :Checks all current packs for missing.
   set xpro(alldel) "1"



=========================================================================================================
XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop    -DCC COMMANDS INFORMATION-
=========================================================================================================

DCC chat your bot & use the command .xhelp to access the complete help system with examples of all commands.

There are 5 basic command prefixes:

  x - x is Server Command used for start, stop, reset, status, info, & dynamic settings.
  a - a is The ADD Command for adding files or channels or bans.
  d - d is The DELETE Command for deleting packs or channels or bans.
  l - l is The LIST Command for listing files in que or packs.
  m - m is the MOVE Command for moving a pack to a new position in the packlist.


XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER ADD PACKS COMMANDS-
=========================================================================================================
Package Commands ADD : Adds Packs to Default List Position.
- For files in Default Path(s)   (no file route needed)
  .apack <file>                                       : Add a single pack with default description
  .apack <file>,<description>                         : Add a single pack with description
  .apack <file>,,<file>                               : Add multiple packs with default descriptions
  .apack <file>,<description>,,<file>,<description>   : Add multiple packs with descriptions
  .apack -all                                         : Add all new packs with default descriptions

- For files NOT in Default Path(s)   (use the full route & file name)
  .apack <./route/file>                               : Add a single pack with default description
  .apack <./route/file>,<description>                 : Add a single pack with description
  .apack <./route/file>,,<./route/file>               : Add multiple packs with default descriptions
  .apack <./route/file>,<desc>,,<./route/file>,<desc> : Add multiple packs with descriptions
  .apack -all <./route/>                              : Add all new packs in ./route/ (default descriptions)
  .apack -all <./route/>,<./route/>,<./route/>        : Add all new packs in all listed directories

Package Commands ADD POSITION : Adds Packs to Chosen List Position.
  .apack #1 <file>                                    : Add a pack at list position 1 (default description)
  .apack #3 <file>,<description>                      : Add a pack with description at list position 3
  .apack #end <file>,<desc>,,<file>,<desc>            : Add packs with descriptions at end of the list
  .apack #same <file>,<description>                   : Update pack description, at same list position
  .apack #1 -all                                      : Add all new packs in <defpath>,  at list position 1
  .apack #e -a <./route/>                             : Add all new packs in ./route/,  at end of the list

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER MOVE PACKS COMMANDS-
=========================================================================================================
Package Commands MOVE : Move Exsisting Packs to Chosen Position.
  .mpack 5                  : Move pack 5 to current default add position
  .mpack 3 7 4 1            : Move packs 3 7 & 4 to beginning of the list
  .mpack 3-5 end            : Move packs 3 4 & 5 to the end of the list
  .mpack 3- e               : Move packs 1 2 & 3 to the end of the list
  .mpack 6+ 1               : Move all packs numbered 6 and higher to #1
  .mpack 2 4-6 1            : Move packs 2 4 5 & 6 to beginning of list
  .mpack 2,4-6,1            : Move packs 2 4 5 6 & 1 to default add position

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER DELETE PACKS COMMANDS-
=========================================================================================================
Package Commands DELETE : Delete Single or Multiple Packs.
  .dpack 1                  : Delete a Single Pack
  .dpack 1 3 4 7            : Delete packs numbered 1 3 4 and 7
  .dpack 3-6                : Delete packs 3 4 5 and 6
  .dpack 4-                 : Delete packs 1 2 3 and 4
  .dpack 5+                 : Delete all packs numbered 5 and higher
  .dpack 1 5-7 9+ 3         : Delete packs 1 3 5 6 7 and 9+
  .dpack -all               : Delete ALL packs!

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER LIST PACKS COMMAND-
=========================================================================================================
Package Command LIST : Show a List of Packages Offered.
  .lpack                    : List the packages offered

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER CHANNEL COMMANDS-
=========================================================================================================
Channels Commands : List, Add and Delete Serving Channel(s).
  .lchan                    : List the server channels
  .achan <channel>          : Add a channel    | works with or without a #
  .dchan <channel>          : Delete a channel | works with or without a #

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER COMMANDS-
=========================================================================================================
Server Commands : Status, Start and Stop Commands.
  .xstart                   : Start the server
  .xstop                    : Stop the server
  .xstatus                  : Server status

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER QUE COMMANDS-
=========================================================================================================
Queues Commands : List or Delete files in Queue
  .lque                     : List the files in queue
  .dque <# or nick>         : Delete file from que OR all ques for nick

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER SEND COMMANDS-
=========================================================================================================
Sends Commands : List or Kill Sends in Progress.
  .lsend                    : List the active sends
  .dsend <# or nick>        : Kill a file send

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER BAN COMMANDS-
=========================================================================================================
Server Bans Commands : List, Add or Remove Server Bans.
  .lban                     : List the server bans
  .aban <mask or nick>      : Add a ban to the server ban list
  .dban <ban# or nick>      : Delete a ban from the server ban list

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -SERVER X COMMANDS-
=========================================================================================================
  .xhelp                   : The Main DCC Server Help
                           1. For help on a specific command, use the command by itself.
                              EXAMPLE:  .apack   (get help with adding server packages)
                           2. Or try asking a simple question to the help system.
                              EXAMPLE:  .xhelp how do i add a server channel?

  .xstart                  : Start the server
                           1. Server won't start without server channels or packs.

  .xstop                   : Stop the server
                           1. Stops all channel ads and new sends from queue.
                           2. Stops all replies to server commands from users.
                           3. Server continues to monitor active sends for user gone.
                           4. Does not kill active sends unless user leaves the channel.
                           5. Does not clear the queue.

  .xstatus                 : Current server status
  .xinfo                   : Current script version and author contact information

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -RESET DOWNLOAD TOTALS COMMANDS-
=========================================================================================================
Reset Download Totals Commands : Set Server and/or Current Pack Download Stats to None
  .xreset -server          : Reset total server downloads to 0
  .xreset -packs           : Reset all current packs to 0 downloads
  .xreset -all             : Reset all file download stats to 0

XDCC SERVER PRO version 2.04.2 for Eggdrop/Windrop   -DYNAMIC SCRIPT SETTINGS COMMANDS-
=========================================================================================================
Dynamic Script Settings Commands : Change Many xdcc_pro.tcl Script Settings by DCC Command
  .xset <setting> <value>    : Set, Change, Remove or List Dynamic Settings
  .xset -<option>            1. This command takes multiple or mixed input.
                             2. Currently allows changing of nine different tcl settings.
                             3. Settings changes are applied without a rehash.
                             4. Use:  .xset -list  for the complete xset setting list.
                             5. Dynamic settings remain active until removed with .xset
                                or changed in the xdcc_pro.tcl.

  EXAMPLES:
  .xset                           : List all active dynamic settings
  .xset maxdcc 3                  : Change maxdcc value to 3
  .xset maxque -                  : Remove dynamic setting for maxque
  .xset -usrmaxq                  : Remove dynamic setting for usrmaxq
  .xset maxdcc 4 -maxque color 3  : Set 2 & remove 1
  .xset -rem                      : Remove all active dynamic settings
  .xset -list                     : List all possible dynamic settings
  .xset -help                     : Show help for the .xset command
  .xset -help color               : Show help for the color setting

XSET SETTINGS USED IN DCC CHAT:

##Maximum number of file sends at once.      [.xset md]
DCC Command: .xset md 4                      : Sets Max Send Slots to 4.        

## Maximum number of queued packs.           [.xset mq]
DCC Command: .xset mq 20                     : Sets Max Qued Files in Server to 20

## Maximum number of queued file per user.   [.xset um]
DCC Command: .xset um 5                      : Sets Max Qued Files Per User to 5

## For users with files in queue...          [.xset qt]
## can be gone from the channel how many minutes before removing from que
DCC Command: .xset qt 5                      : Sets Time to Remove Qued Files for User Gone to 5

## For users with active file sends...       [.xset st]
## can be gone from the channel how many minutes before killing sends
DCC Command: .xset st 5                      : Sets Time to Kill Send for User Gone From Channel

## Start server when the bot starts? (0|1+)  [.xset as]
## Set to "1" or more to enable. ("0" = off "1" or more to auto-start delay time in minutes)
DCC Command: .xset as 1                      : Sets Server Start To Auto-Start

## Server Colors On or Off?? (1-5 or 0=OFF)  [.xset co] 
DCC Command: .xset co 1                      : Sets Ad Colors to Theme 1 (If Custom Color is Off)

## Server Ad/List Layout Choices             [.xset al]
##  "1"  :Default - lists use pack description only
##  "2"  :Option2 - lists use file name & description
DCC Command: .xset al 2                      : Sets Ad Choice to Option2

## Use Custom Colors below or Server Colors  [.xset cu] 
##   "0"  : use server colors settings from above
##   "1"  : use custom server colors setup below
DCC Command: .xset cu  0                     : Sets Custom Colors Off




