;  ####                 #                            @ irc.IRC-Hispano.org  
; ##  ##               ##                              #eggdrop
; ##      ####  ##### ####  ####  #####   ###   ####   
; ####   ##  ## ##  ## ##  ##  ## ##  ## ## ## ##  ##  http://Sentence.unencanto.es
;   #### ###### ##  ## ##  ###### ##  ## ##    ######  Escrito en castellano 
;     ## ##     ##  ## ##  ##     ##  ## ##    ##      chispanp�m :)
; ##  ## ##  ## ##  ## ##  ##  ## ##  ## ## ## ##  ##
;  ####   ####  ##  ##  ##  ####  ##  ##  ###   ####   
;
;             |�������������������������������������������������������������|
;             |                            _.--..---"-,--c_                 |
;             |                       \L..'           ._O__)_               |
;             |               ,-.     _.+  _  \..--( /                      |
;             |                 \.-''__.-' \ (     \_                       |
;             |                   '''       \__   /\                        |
;             |                               ')                            |
;             | Patrocinio: Lacoste, he ah� el susodicho                    |
;             |                                                             |
;             |_____________________________________________________________|
;
;
;  Problemas, quejas, sugerencias, dudas, Sentence@unencanto.es
;

Versi�n del fichero: sen-stats.tcl v1.1

A�adido:
	Verifica que exista el ejecutable del pisg
	Tambi�n busca y verifica el de ftp
	Configuraci�n personalizada para cada canal, inclu�do el mensaje de spam
	De no usar ftp, dejar� el archivo donde fichero.cfg lo cree, para as�
	con tu servidor http puedas crear el alias o publicarlo.
	
Tareas pendientes:
       		  
		  Quiz� crear una funci�n para poder configurar el fichero
		  sen-stats.cfg desde partyline o msg
		  Protecci�n de flood ante !stats -aunque considero que la
		  protecci�n de eggdrop es m�s que v�lida para evitarlo.
		  
Consejos:
	 Usa cache en tu fichero pisg, el eggdrop no se quedar� bloqueado
	 momentaneamente.
	 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Modo de uso:
     	    Ubica el fichero sen-stats.tcl en eggdrop/scripts/
	    Ubica el fichero sen-stats.cfg en eggdrop/
	    A�ade en tu fichero eggdrop.conf:
	    source scripts/sen-stats.tcl
	    Teclea en tu partyline: .rehash
	    
     	    para activar las estad�sticas debes escribir en partyline:
	    .chanset #canal +psgstats.
	    Si es para todos los canales en los que se encuentra, cambia
	    #canal por *. 
	    
	    El script actualizar� las estad�sticas de todos los canales cada
	    6 horas. No obstante puedes actualizarlas cuando quieras poniendo
	    en el canal !pisg, si no usas cache y tu canal tiene mucha alfuiencia
	    tendr�s problemas con el tiempo de creaci�n del fichero html y 
	    quiz� llegue el bot a obtener timeout.
	    





