##
##
##        Mod title:  Punbb2Eggdrop 
##
##      Mod version:  1.0
##   Works on PunBB:  1.2.12
##     Release date:  2006-07-12
##           Author:  abask (abask@grin.by) help hcs (hcs@mail.ru)
##
##      Description:  this mod show all new messages in irc channel. need eggdrop bot.
##
##   Affected files:   post.php, config.php
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##


#
#---------[ 1. UPLOAD ]------------------------------------------------------
#

punbb2egg.tcl to your tcl scripts folder

#
#---------[ 2. OPEN ]---------------------------------------------------
#

punbb2egg.tcl

#
#---------[ 3. FIND ] -------------------------------------------------
#

listen 1502 script ::punbb::accept

#
#---------[ 4. CHANGE ] -------------------------------------------------
#

port 1502 to any you like
this port number must be Equally port number in punbb config.php Look below

#
#---------[ 5. OPEN ]---------------------------------------------------
#

eggdrop.conf


#
#---------[ 6. FIND ]---------------------------------------------------
#

##### SCRIPTS #####

#
#---------[ 7. IN THE END OF THIS SECTION, ADD ]---------------------------------------------------
#

source path/to/your/tcl/scripts/punbb2egg.tcl

#---------[ 8. GO TO ]---------------------------------------------------
#

your bot partilane


#---------[ 9. TYPE ]---------------------------------------------------
#

.rehash
.chanset #yourchannel +punbb


#
#---------[ 10. OPEN ]---------------------------------------------------
#

/your/punbb/path/config.php

#
#---------[ 11. FIND ]---------------------------------------------------
#

define('PUN', 1);

#
#---------[ 12. BEFORE ADD ]---------------------------------------------------
#


$botaddress = 'localhost';
$botport = '1502';
//botport must be equally port number in punbb2egg.tcl look above

 
 
#
#---------[ 13. OPEN	 ]---------------------------------------------------
#
 

 post.php  

 
#
#---------[ 14. FIND (line:315)]---------------------------------------------------
#
 
// If the posting user is logged in, increment his/her post count 


#
#---------[ 15. BEFORE ADD ]-------------------------------------------
#

//************** to eggdrop begin
		if ($tid)
		    $subject=$cur_posting['subject'];
		$socket = @fsockopen ($botaddress, $botport, $null, $null, 60);
		$to_bot = $username . ";" . $cur_posting['forum_name'] . ";" . $subject . ";" . $pun_config['o_base_url']."/viewtopic.php?pid=".$new_pid."#p".$new_pid;
						     
		if ($socket) {
		    @fputs($socket,"$to_bot\n");
		    for($i=0;$i<400000;$i++) { $g=$i; }
		    fclose($socket);
		}
//************** to eggdrop end
 
#
#---------[ 16. EXCUSE MY BAD ENGLISH AND ENJOY ]-----------------------------------------------------

