#!/usr/bin/perl

# -------------------------------------------------------------------- #
#     graph.pl v2 by Mikko Pikarinen, goblet@goblet.net 1998-1999      #
#                                                                      #
# This draws the GIF file. See graph.README                            #
# If you can't get this to work, it's YOUR problem. _DO_NOT_EMAIL_ME_  #
# This is free to use but don't remove the info about original author! #
# ---------------------------------------------------------------------#

use GD;
$datafile = "graph.dta";

$im = new GD::Image(510,270);
$white = $im->colorAllocate(255,255,255);
$black = $im->colorAllocate(0,0,0);
$red = $im->colorAllocate(255,0,0);
$red2 = $im->colorAllocate(128,0,0);
$blue = $im->colorAllocate(0,0,255);
$green = $im->colorAllocate(0,128,0);
$grey1 = $im->colorAllocate(128,128,128);
$grey2 = $im->colorAllocate(208,208,208);

# Please use values that ($maxX-$minX) == (? * 144) 
$minX = 40;
$minY = 41;
$maxX = 472;
$maxY = 240;

($sec,$min,$hour,$day,$month,$year,$wod,$doy,$isdst) = localtime(time);
$year += 1900;
if (time > 946677600) {$year += 100}
$month++;

# First make sure that we have and entry on every timestamp
for ($j = 0; $j < 144; $j++) {$gdata[$j] = "$j 0 0 0";}

# Read the data from file to the list
open(datafile,$datafile);
while ($row = <datafile>) {
  chop $row;
  ($time, $traffic, $ops, $unops) = split(" ", $row);
  $gdata[$time] = "$time $traffic $ops $unops";
}
close datafile;

# Replace entries in list with given params
($sec,$min,$hour,$day,$month,$year,$wod,$doy,$isdst) = localtime(time);
$min = substr($min+100,1,1);
$now = $hour*6+$min;
$hour++; 
$nowhour = $hour*6;
$gdata[$now] = $now;
for ($i = 0; $i < 3; $i++) {
  if ($ARGV[$i] > -1) {
      $gdata[$now] .= " $ARGV[$i]"
     } else {
      $gdata[$now] .= "0"
     }
}

# Rewrite data to the file
open(datafile, ">$datafile");
foreach $i (@gdata) {print datafile "$i\n"}
close datafile;

# Put the data to the right place in list that current time is on the right.
@ddata = @gdata[$nowhour..143,0..$now];

# Make separate lists for people and traffic and check for peaks 
$highest_traffic = $highest_people = 1;
$length = (139+$min);
for ($i = 0; $i < $length; $i++) {
  ($time,$traf,$op,$unop) = split(" ", $ddata[$i]);
  $traffic[$i] = "$traf $i";
  $people[$i] = "$op $unop $i";
  if ($highest_traffic < $traf) {$highest_traffic = $traf}
  if ($highest_people < $op) {$highest_people = $op}
  if ($highest_people < $unop) {$highest_people = $unop}
}

## Now let's draw the GIF!

# Centered title etc
$im->string(gdLargeFont,($maxX-$minX)/2-30,5,"PEOPLE &",$blue);
$im->string(gdLargeFont,($maxX-$minX)/2+40,5,"TRAFFIC",$blue);
$im->string(gdLargeFont,($maxX-$minX)/2-31,5,"PEOPLE &",$black);
$im->string(gdLargeFont,($maxX-$minX)/2+39,5,"TRAFFIC",$black);
$im->string(gdTinyFont,$minX-35,$minY-20,"traffic",$black);
$im->string(gdTinyFont,$maxX,$minY-20,"people",$black);

$im->string(gdSmallFont,$minX,$maxY+5,"traffic",$black);
$im->string(gdSmallFont,$minX+100,$maxY+5,"chanops",$black);
$im->string(gdSmallFont,$minX+200,$maxY+5,"not ops",$black);
$im->string(gdTinyFont,$maxX-110,$maxY+7,"http://www.goblet.net/",$black);

$im->line($minX+50,$maxY+11,$minX+70,$maxY+11,$red);
$im->line($minX+50,$maxY+12,$minX+70,$maxY+12,$red);
$im->line($minX+150,$maxY+11,$minX+170,$maxY+11,$blue);
$im->line($minX+150,$maxY+12,$minX+170,$maxY+12,$blue);
$im->line($minX+250,$maxY+11,$minX+270,$maxY+11,$green);
$im->line($minX+250,$maxY+12,$minX+270,$maxY+12,$green);

# Draw the frame and fill it
$im->rectangle($minX-1,$minY-1,$maxX+1,$maxY+1,$black);
$im->fill($minX,$minY,$grey2);

# Vertical grid
for ($i = 1; $i < 24; $i++) {
$im->line($minX+(($maxX-$minX)/24)*$i,$minY,$minX+(($maxX-$minX)/24)*$i,$maxY,$grey1);
}

# Horizontal grid
for ($i = 1; $i < 10; $i++) {
$im->line($minX,$minY+(($maxY-$minY)/10)*$i,$maxX,$minY+(($maxY-$minY)/10)*$i,$grey1);
}

# Print hours to the top 
($j,$foo,$foo,$foo) = split(" ",$ddata[0]/6); 
for ($i = 1; $i < 24; $i++) {
  $j++;
  if ($j == 24) {$j = 0}
  $k = $j;
  if ($j < 10) {$k = "0" . $k}
  $im->string(gdSmallFont,$minX-5+(($maxX-$minX)/24)*$i,$minY-15,$k,$black); 
}

# Print traffic amount on left
for ($i = 1; $i < 10; $i++) {
  $foo = $highest_traffic*$i/10000;
  $str = int($foo*10)/10;
  $str .= "k";
  $im->string(gdSmallFont,$minX-30,$maxY-(($maxY-$minY)/10)*$i-6,$str,$black);
}
$foo = $highest_traffic/1000;
$hstr = int($foo*10)/10;
$hstr .= "k";
$im->string(gdSmallFont,$minX-30,$minY-8,$hstr,$red);

# Make people scale smart
if ($highest_people <= 10 && $highest_people > 0) {$highest_people = 10}
if ($highest_people <= 20 && $highest_people > 10) {$highest_people = 20}
if ($highest_people <= 30 && $highest_people > 20) {$highest_people = 30}
if ($highest_people <= 40 && $highest_people > 30) {$highest_people = 40}
if ($highest_people <= 50 && $highest_people > 40) {$highest_people = 50}
if ($highest_people <= 100 && $highest_people > 50) {$highest_people = 100}
if ($highest_people <= 200 && $highest_people > 100) {$highest_people = 200}
if ($highest_people > 200) {$highest_people = 500}

# Print people amount to the right
for ($i = 1; $i < 10; $i++) {
$str = int($highest_people*$i)/10;
$im->string(gdSmallFont,$maxX+10,$maxY-(($maxY-$minY)/10)*$i-6,$str,$black);
}
$hstr = $highest_people;
$im->string(gdSmallFont,$maxX+10,$minY-8,$hstr,$red);

# Draw the traffic statistics bars
$lastY = $maxY;
$timescale = ($maxX-$minX)/144;
$trafscale = ($maxY-$minY)/$highest_traffic;
$pplscale = ($maxY-$minY)/$highest_people;
$lastX = ($firsttime-1)*$timescale+$minX;
if ($lastX < $minX) {$lastX = $minX}

foreach $i (@traffic) {
  ($Y, $X) = split(" ",$i);
  if ($Y != 1) {
    $X = $X * $timescale + $minX;
    $Y = $maxY - $Y * $trafscale;
    $im->line($X,$maxY,$X,$Y,$red);
    $im->line($X+1,$maxY,$X+1,$Y,$red);
    $im->line($X+2,$maxY,$X+2,$Y,$red);
    for ($i = 1; $i < 10; $i++) {
         $gY = $minY+(($maxY-$minY)/10)*$i;
         if ($gY > $Y) {$im->line($X,$gY,$X+3,$gY,$red2)}
    }
    for ($i = 1; $i < 24; $i++) {
    if ($minX+(($maxX-$minX)/24)*$i == $X) {$im->line($X,$maxY,$X,$Y,$red2)}
    if ($minX+(($maxX-$minX)/24)*$i == $X+1) {$im->line($X+1,$maxY,$X+1,$Y,$red2)} 
    if ($minX+(($maxX-$minX)/24)*$i == $X+2) {$im->line($X+2,$maxY,$X+2,$Y,$red2)} 
    }
  }
}
$lastY2 = $lastY;

foreach $i (@people) {
  ($Y, $Y2, $X) = split(" ",$i);
    $X = $X * $timescale + $minX;
    $Y = $maxY - $Y * $pplscale;
    if ($lastX == $minX) {$lastY = $Y}
    $im->line($lastX,$lastY,$X,$Y,$blue);
    $im->line($lastX,$lastY+1,$X,$Y+1,$blue);
    $lastY = $Y;

    $Y2 = $maxY - $Y2 * $pplscale;  
    if ($lastX == $minX) {$lastY2 = $Y2}
    $im->line($lastX,$lastY2,$X,$Y2,$green);
    $im->line($lastX,$lastY2+1,$X,$Y2+1,$green);
    $lastY2 = $Y2;

  if ($lastX != $X) {$lastX = $X;}
}

# Output of the GIF
binmode STDOUT;
print $im->gif;
