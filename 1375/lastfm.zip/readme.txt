This is an eggdrop script written in tcl using a php backend
(u can use the provided one).
It posts various informations (recent played tracks, weeklytoptracks,
weeklytopartists, topalbums, topartists, toptracks, friends, playcount)
from any last.fm user on your channel.

Tested under eggdrop 1.6.18 on a linux box but should work on older versions, too.

Feel free to contact me about bugs or feature requests.

jesse@teranetworks.de
http://forum.teranetworks.de

support via irc:
teranetworks.de:6667 (leaf: xlernt.dyndns.org:6667)
/join #woot
