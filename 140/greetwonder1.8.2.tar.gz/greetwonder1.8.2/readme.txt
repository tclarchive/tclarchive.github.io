GreetWondeR 1.8.2 (Eggdrop 1.x Greet TCL Script) 
---------------
Released: Tue Nov 2 1999 
Author: Wingman <Wingman@WINGDesign.de>
        http://www.WINGDesign.de/
GreetWondeR Homepage: http://www.WINGDesign.de/greetwonder/
---------------

1.  Introduction
2.  Features
3.  Installation/Setup
4.  A short guide
5.  DCC Commands
6.  History
7.  New procs (for tcl coders)
8.  Credits

================================
== Section 1.: INTRODUCTION   ==
================================

First of all - i should say sorry, cause of my english - it's not the best ;).

GreetWondeR is - you already guessed? :) - a greet tcl for Eggdrop 1.x. Yes,
it (should) work on 1.1.x,1.2.x,1.3.x and the new 1.4.x. But why using _this_
tcl and not one of many others on ftp.eggheads.org (e.g. greetd.tcl by guppy)?
Because this script is most comfortable and has the most features of all
greet tcls. And nearly everything is controled via partyline, dcc commands.
You want to add a greet for #chan1? Login and type: .+greet #chan1 Greetings!
You want to greet only +o users on #chan2? No problem: .+greet #chan2 +o
Greetings!. You want multiple lines? Just add one after another. You want
random greets? Just add them and turn it on: .greetrandom #chan1 on! It also
supports mask greets (e.g. *!*@*.de or *fuck*!*@*) or nickgreets (like .info,
but the bot can greet you via msg, notice, public or me/action). Other greet
scripts caused excess floods? This one NOT. It has an integrated queue system,
which prevents your bot from quitting. It's based on the "Angel" (coded by 
Hippo) and "dontflood.patch/qstuff.patch" (coded by G`Quann) Flood protection.
Last are eggdrop1.3.28+ patches, which integrate this protection in your
eggdrop src. If this patch is installed, the tcl notices it and deactivates
its own flood protection.

Have fun and pls let me know, if you like this tcl (or not) :)

============================
== Section 2.: FEATURES   ==
============================

 - full multi channel support
 - all commands via DCC available
 - each chan owner can set individual greets for his chan
 - supports flag greets
 - supports hostmask greets (e.g. *!*@*.de)
 - supports colored greets
 - supports random greets
 - supports var replacing, e.g. if u add a greet
   ".+greet Welcome greet-nick to greet-chan - For a help try /msg
   greet-botnick help" and let's say Wingman joins #Eggdrop, he'll see:
   "Welcome Wingman to #Eggdrop - For a help try /msg Eggie help"
 - can either msg/notice all users, just non-users or only known users
 - integrated flood protection (NEW QUEUE SYSTEM)
 - greets can be turned off
 - can import greets from a file
 - works on eggdrop 1.1.x/1.2.x/1.3.x or 1.4.x
 - and many more... (try .greethelp for a commandlist)

====================================
== Section 3.: INSTALLATION/SETUP ==
====================================

GreetWondeR is the first eggdrop tcl script (i think), which has an Install 
script included. This is for complete newbies, who don`t know _anything_ about 
adding scripts to the config file of the bot. 

There are 2 different ways of installing greetwonder.tcl:

First edit the header of greetwonder.tcl to your comfort.

1. Use: ./greetinstall
  a) ./greetinstall /path/to/your/eggdrop/configfile (type at your shell)
     (Example: ./greetinstall /home/wingman/eggdrop/eggdrop.conf.dist)
  b) do a .rehash (or restart)

2. the "classic" way
  a) cp greetwonder1.8.2/greetwonder.tcl /path/to/your/eggdrop/scripts
  b) vi (or an editor of your choice) eggdrop.conf.dist (eggdrop config file)
  c) insert at the END of the file the line: 
     source scripts/greetwonder.tcl
  d) do a .rehash (or restart) 

===============================
== Section 4.: A SHORT GUIDE ==
===============================

1. If you want to add a greet for #test, which should get all users:
.+greet #test Hi greet-nick - Welcome to greet-chan!
.greetwho #test all

2. If you want flag specific greets:
.+greet #test +n Hi greet-nick - You are an Owner on greet-chan!
You can define up to x lines (x is defined at the top of the tcl) for every
flag or greet.

3. If you want to greet a nick with a specific line:
.+greetnick Nickname pub Hi Nick, what's up?
(Only nicknames, which are in the userlist are allowed)

4. If u want to greet all german users with a specific line:
.+greetmask #channel *!*@*.de Guten Tag greet-nick in greet-chan!

5. A feature of this tcl is its varreplacing:
greet-nick, greet-chan and greet-botnick are replaced by the tcl vars, which
means, if let's say Wingman joins #Eggdrop and the botnick is Lamestbot, he`ll 
see (if there's greet like Hi greet-nick! Welcome to greet-chan - For a help
try /msg greet-botnick help Hi Wingman! Welcome to #Eggdrop - For a help try 
/msg Lamestbot help)

================================
== Section 5.: DCC COMMANDS   ==
=================================

.+greet [channel] [+flag] <greet>
.-greet [channel] [+flag] <linenr/all>
.+greetnick <handle> <msg/notice/pub/act> <text>
.-greetnick <nickname> 
.+greethost [channel] <nickname!ident@hostname> <greet>
.-greethost [channel] <nickname!ident@hostname> <linenr/all>
.+greetfile [channel] [+flag] <filename>
.greethow [channel] [+flag] <notice/privmsg>
.greetwho [channel] [+flag] <all/known/unknown>
.greetmove [channel] [+flag] <from> <to>
.greetrandom [channel] [+flag] <on/off>
.greet [channel] <on/off>
.greetstatus [flood]
.greethelp [command]
.greetview [channel]
.gmotd <on/off>
.greetnickview
.greetinfo
.greetver

=========================
== Section 6.: HISTORY ==
=========================
Version 1.8.2
 -- fixed: all errors with -|foo users, which can only use .greetcmds on
           their channels
 -- fixed: .greethow #foo unknown && .greetstatus
           -> there was not enough space in the column "Who" :)
 -- fixed: [18:43] <DVS01> wingman: your greet tcl is nice, but the indentation
           is whacked 
 -- new: .greethelp && e.g. handle is only chanowner -> only cmds, which he
         can access, are listed. 
 -- new: set greet(random) <on/off>
 -- new: set greet(flag_greet_seperation) <on/off>

Version 1.8.1
 -- fixed: some errors on random greets on
 -- fixed: .+greet +A test && greetview -> tcl error
 -- fixed: .+greetfile -> dynamic greetvar was not updated
 -- fixed: .+greetfile +o chan -> tcl error ($grethow not found)
 -- fixed: .-greet all && no greets saved
 -- fixed: .greetrand +f on -> tcl error (can't read "flag")
 -- fixed: now 1.3.29+ compatible (w/o loading compat.tcl) 
 -- fixed: .+greet #foo +f test { test } test 
           -> 'Added "test  test  test" (+f users) for #foo'
 -- fixed: .greetview && random greets off && $greet(max) < $count(flaggreets)  
 -- new: .-greet [channel] [+flag] <all> -> deletes all greets (for +flag
         users)
 -- new: .-greetmask all -> deletes all maskgreets
 -- new: .greetstatus <all> & some design changes

Version 1.8
 -- fixed: .+greet didn't work, if you were only a chanowner
           (fixed in greetwonder1.7+greetfix.tcl)
 -- fixed: still one [matchattr] left (errors on 1.1.x)
 -- fixed: recoded greetqueue
           ^- added maximum queue var: set greet(maxqueue) <bytes>
           ^- removed setting: set greet(senders)
           ^- removed setting: set greet(sendm) <msgs>
           ^- new: set greet(sendq) <bytes:secs> (till activating GFP)
 -- fixed: .greetstatus && no greets set
 -- fixed: recoded greet:rejn & greet:delsplt ($greetsplit -> oo)
 -- fixed: .greetmove a b -> if a > b, then putlog "$from -> [incr to -1]"
 -- new: no filesys -> no .+greetfile
 -- new: moved greetwonder.readme -> readme.txt
 -- new: moved greetinstall -> greetinstall.tcl
 -- new: added '.greethelp greetinfo'
 -- new: added '.greethelp greetver'
 -- new: added '.greethelp qstuff'
 -- new: added support for 'dontflood.patch' or 'qstuffx.x.patch'
         (see greetwonder.tcl for more information on this patch)
 -- new: .-greet [channel] [+flag] <linenr> 
 -- new: .-greetmask [channel] [mask] <linenr>
 
 Version 1.7
 -- fixed: some minor bugs
 -- fixed: .greethelp -greet and some other .greethelp bugs
 -- fixed: .greetnickview
 -- fixed: .greetmove
 -- new: complete new queue system -> no one should be able to flood your
         bot because of greetwonder (no settings needed).
         Thx to HERZ for the shell for testing and Hippo for his "curious"
         solution to the queue problem ;)
	 If your bot quits via "Excess Flood" because of GreetWondeR, then 
	 email me the logfile.

Version 1.6.1
 -- fixed: some probs with new dynamic channels (on .+chan && .+greet)
 -- fixed: .+greet #channel greet -> "greet" was added two times...

Version 1.6
 -- fixed: sometimes there were 2 putcmdlogs
 -- fixed: greet:flag2norm -> removed option "bot" (you can't greet bots with
           GreetWondeR) ; Usage: greet:flag2norm <flag>
 -- fixed: set greet(max) 0 disables now line limitations.
 -- new: back to the roots: moved .conf and .help to .tcl
 -- new: GreetWondeR now works on Eggdrop 1.1.x, 1.2.x and 1.3.x
         (any other version will cancel the script)
 -- new: moved +/-greethost -> +/-greetmask
 -- new: recoded and split up proc greet:join -> greet:chan/nick/host
 -- new: modified .greetstatus (some things changes)
 -- new: added to each var "# Default: <defaultvalue>"
 -- new: Option: set greet(hierarchie) <option> -> greet hierarchie
 -- new: Option: set greet(sorted) <flaglist> -> flag greet hierarchie
 -- new: Option: set greet(flood_join) <joins>:<secs> -> floodjoin setting

Version 1.5
(tcl)
 -- fixed: various smaller bugs (typos etc)
 -- fixed: .greetwho all -> sets greets to only known user (thx to Whilor)
 -- fixed: got some strange errors with greet:save (i think there fixed...)
 -- fixed: ooops, flood protect didn't work =) (on versions 1.4 and 1.4.1)
 -- fixed: there were still some file readings on join, removed
 -- fixed: .greethow msg or notice didn't work (and forgot putcmdlogs)
 -- new: .greetrandom [channel] [+flag] <on/off> -> turns on/off random greets
 -- new: .greetmove [channel] [+flag] <from> <to> -> moves line up or down
 -- new: .+/-greethost [channel] <nick!ident@host> <greet> (w/ wildcards)
 -- new: .greethelp <variable> (Shows help to each variable set in the conf)
         recoded proc dcc:greethelp
 -- new: .+greetfile now with line limitation (only perm owners can add w/o
         line limitation - and! only files, which are in the filearea can
         be added)
 -- new: .greetstatus now w/o [channel] option (but with option flood)
         Usage: .greetstatus [flood] (w/ flood -> w/ floodprotection display)
 -- new: proc greet:flag2norm <user/bot> <flag>
         returns: converts flag to normal status (e.g. +n --> owner)
 -- new: removed proc greet:debug
(help)
 -- new: Moved .greethelp(txts) to file: greetwonder.help
(conf)
 -- new: Moved settings to file: greetwonder.conf
 -- new: set greet(?bind) <globalflag|chanflag> -> who can use cmds...
 -- new: added line # You didn't edit your... - If you don't delete the line,
         the script will work (and the bot will !not! die, but you get a 
	 message, every time you do a .rehash or .restart)
(install)
 -- new: recoded ./greetinstall
         Usage: greetinstall /path/to/your/eggdrop/configfile
(readme)
 -- new: Moved txtfile to: greetwonder.readme
 -- new: rewrote the file (e.g. added Section proc and DCC Commands)
 -- new: removed the history for versions < 1.1
(CONTENTS)
 -- new: like the CONTENTS in your scripts dir

Version 1.4.1
 -- fixed: ./greetinstall -> typo (should be writable instead of writeable)
           (thx to HERZ)
 -- fixed: The tcl thought, 1.0.4b is hacked... (thx to Whilor)
 -- fixed: (again) little typo in greet:init line 266: chanz -> chan

Version 1.4
 -- fixed: in some cases nicks were not nick-greeted
 -- fixed: nick file was not updated 
 -- fixed: .+greet #chan test blubb -> only blubb was saved
 -- fixed: .+greet #chan +m -> Added  (+m users) for #chan
 -- new: recoded .greetreset
 -- new: greet:init (completly new coded)
 -- new: Added NEW/FIXED to all version (.txt)
 -- new: directory structure:
         /greet/ --> channels --> chan1.dat
                              --> chan2.dat
                              --> [...]
                 nicks.dat
                 greet.dat 
 -- new: set greet(delay) <seconds>
         Delay time before reshowing the greet
 -- new: Removed: set greet(init) <1/0>
 -- new: .+greetfile [channel] [flag] <filename>
         Imports greets from a file (this command is global owners
         only coz there's no line limit)
 -- new: scriptwide flag check -> only "abcdefghijklmnopqrst
         uvwxyz1234567890" (with [toupper]) allowed
 -- new: added GreetWondeR Installer:
         Usage: ./greetinstall <eggdrop configfile>
 -- new: added INSTALL in the .txt

Version 1.3
 -- fixed: smaller bugs (typos etc.)
 -- fixed: forgot a ] in greet:join (1.2+greet:joinfix)
 -- fixed: .-greetnick <nick> did'nt worked in some cases
 -- fixed: .greetnickview got confused cause of -greetnick
 -- fixed: the Greet-MOTD didn't work with |n users
 -- fixed: in file greet(data), the new version was added at the top, but the
           old headers were not removed
 -- new: moved proc greet:sucks -> greet:replace
         usage: greet:replace <nick> <chan> <line>
         returns: string
 -- new: moved (nick), (chan) and (botnick) to greet-nick, greet-chan and 
         greet-botnick. Now these strings are replaced by the proc vars
         (even if there's a char in front of or at the end of the word).
 -- new: .+greetnick <nick> <msg/notice/pub/act> <text>
         Now nicks can be greeted via /me (ACTION)
 -- new: added Init Updater - (nick), (chan) and (botnick) are replaced by
         greet-nick, greet-chan, greet-botnick

Version 1.2 
 -- fixed: .+greet +n {a b} c -> sets greet to "a b c"
 -- fixed: forgot the cmd putlog in proc gmotd
 -- fixed: 2 typos in the settings "sould" -> "should"
 -- fixed: .greetstatus sometimes didn't "set c"
 -- fixed: .greetreset showed some putlogs, which d only be available on a 
           .rehash
 -- fixed: if console was *, then $chan == * (fixed)
 -- new: did some modifications on .greetstatus 
 -- new: Now greetwonder can be runned on eggdrops != 1.3.x. But don't blame me,
         if a cmd doesn't work. If u find an error, send a mail :) 
 -- new: moved bindings to procs (no longer listed at the top)
 -- new: modified .greethow [channel]. Now you can change each flag-greet to a
         diff. way of greeting (msg/notice) -> .greethow [channel] [flag]  
 -- new: added proc greet:debug, writes debug file on an error and suggests to
         send this file to my email adress 
         Usage: greet:debug <handle> <idx> <command> <arg>
         (writes Egg Version, date, time, handle, command, arg and greet.dat to 
         greet.dat to greet-debug.date)
 -- new: modified .greetview
 -- new: removed .chaninfo modification (now: standard)
 -- new: moved [flag] -> [+flag] 
         (a bit confusing coz [flag] didn't work...)
 -- new: 1.3.27 (and above?) adds putlogs itself :-/ -> 
         proc greet:putlog. checks if version >= 1.3.27* if match 
         -> then no putlogs, else putlog cmd

Version 1.1
 -- fixed: removed some debugging putlogs
 -- fixed: recoded flood code - now handling over bind flud
 -- fixed: .+greet +n bla [test] bl -> greet = bla {[test]} 
           bl this sucks ;) - added proc lend { start string } 
           Usage: lend <startnumber> <text>
           returns: words from <startnr> to end from <text>
           (similar to [lrange] but w/o endnumber)
 -- new: bind'ed .greet n|n to owner only
 -- new: added proc getfile
 -- new: moved tcl name greetwonder[ver].tcl -> greetwonder.tcl
 -- new: removed var greet(flood) joins:secs
 -- new: added var greet(init) 0/1 -> extended startup screen?
 -- new: modified greetstatus

=======================
== Section 7.: PROCS ==
=======================

Usage: greet:ispermown <handle>
Returns: 1, if <handle> is perm owner, 0 if not

Usage: greet:flag2norm <user/bot> <flag>
Returns: normal status (e.g. +n --> owner)

Usage: greet:sl <string>
Returns: the amount of chars of the longest word in <string>

Usage: greet:stl <string>
Returns: [string tolower <string>]

Usage: greet:lend <start> <string>
Returns: Words from Startnumber till end of string (similar to [lrange x end])

Usage: greet:load <varname>
Returns: value of <varname> from file

Usage: greet:save <varname> <value>
Returns: 1 if saved, else nothing 

Usage: greet:getchannels
Returns: Channels, the bot is on (gets info from .chan file)

Usage: greet:getfile <file>
Returns: what's in the file

Usage: greet:setxtra <handle> <what>
Returns: nothing

Usage: greet:getxtra <handle>
Returns: XTRA wgreet <value>

Usage: greet:queue <chan>
Returns: 1 if queue exists, 0 if not

Usage: greet:unset <chan>
Returns: nothing

Usage: greet:replace <nick> <chan> <line>
Returns: replaces the words greet-nick/greet-chan/greet-botnick with vars and
         then returns the line

=========================
== Section 8.: CREDITS ==
=========================

-------
Cocko - Thx for the suggestions and the betatesting/bugreportings ;)
^AP^  - He's my tcl teacher =)
guppy - For his famous autobotchk =) from which a stole some code ;)
Sara  - She was the first, which mail'ed cause of this tcl ;) 
HERZ  - For his shell, where i could test the tcl under really hard conditions
Hippo - For his curious flood protection - but it works perfectly :)
...and - of course - thx to all bugreporters :)
-------

If you want to contact me on IRCNet: #Quake2.ger
                          on Undernet: #Eggdrop
