Prayer Request v1.0 Beta by ifiredmybrain
IRC - irc.awesomechristians.us #Prayer Request
Email - ifiredmybrain@ifiredmybrain.net
WWW - www.ifiredmybrain.net


-

This script uses a MySQL database to store prayer
requests and post them in the channel. Can be used
on multiple channels.

Features -
	- Reading of a random prayer request
	- Reading a certian quote
	- Reading a quote containing a certian
	  word or phrase
	- Adding a prayer request
	- Delete a prayer request

Commands -
	- .prayer (number|word|phrase)
	- .addprayer (prayer request)
	- .delprayer (number) {must have access with
	  bot to do so}
	- .prayerhelp (show help)

License -
- It may have some bugs in it if any are found
  email me and I will try to fix them, but use
  is still at your own risk
- This script is based of a script of mortician
  you can edit the code of this script but be
  sure to give us some credits.
- You can post this script on your site to download
  as long as I am shown as the author.

- If you do NOT agree with this then you are NOT
  ALLOWED to use this software.

Requirements -
To use this script the following is required:
- Eggdrop version 1.6.x
- TCL 8.0 or higher
- MySQL (3.23 or later)
- Mysqltcl (a TCL to mySQL interface can get it from 

Setup -
	- Open the prayer.tcl file
	- Edit the MySQL Options
	- Change the channels it will be used on
	- Change the character to put before commands
	  if wanted
	- Change the location of the mysqltcl interface
	  (to find out talk to the host of your shell)
	- Don't cross The Board unless you know what you
	  are doing.
	- Save tcl file and place in the scripts
	  directory
	- Go into your eggdrop config and add
	  source scripts/prayer.tcl
	- Restart or rehash your eggdrop

MySQL Database Setup -

- For every channel you will use the script on, you will
  need to create a table pr-channel, do not put the #

  CREATE TABLE `pr-channel` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `prayer` TEXT NOT NULL ,
    `author` VARCHAR( 15 ) DEFAULT 'unknown' NOT NULL ,
    `date` DATETIME NOT NULL ,
    PRIMARY KEY ( `id` )
  );

For any questions about this script email me or ask me on
irc.
