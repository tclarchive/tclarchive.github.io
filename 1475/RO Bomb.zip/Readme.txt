###############################################################################  
#                                                                             #
#  Translated to Romanian language:             [JoNi]                        #
#                                                                             #
#  IRC:                                         [JoNi] #szilagysag @ Undernet #
#                                                                             #
#  Eggdrop Version:     1.6.x                                                 #
#                                                                             #
#  Description:                  GAME SCRIPT                                  #
#                                                                             #
###############################################################################
#                                                                             #
# Pentru a activa bomba tasteza pe canal: !bomba nick                         #
# Pentru a taia cablul  tasteza pe canal: !taie culoare                       #
#                                                                             #
#                                                                             #
#                              Distractie Placuta                             #
#                                                                             #
###############################################################################