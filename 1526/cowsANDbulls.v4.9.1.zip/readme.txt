#Versions########################################################################
#cows and bulls    v4.9.1   main script
#HTML/XML builder  v3.21    ADDon
#REWARDS           v2.00    ADDon
#TEAMS             v1.20    ADDon
#installer         v1.31    instaler.txt proc
#uninstall system  v1.1     game support proc
#NEW CHANGES#####################################################################
 - fix for proc write:resalt: you can show top scores from 1 to 10 players. You can specify how many to show
 - fix for proc write:resalt: new method to sort in file.
 - fix "\\" bug in nick names.
 - fix double score option to work with everyone
 - fix HTML for rewards stats (Mozilla 4.0) and modification for vars who don't exists any more. New background.
 - fix memory stealing problems and optimization in code: cancer, setC Bus, pub:CB
 - fix no alltools need anymore (modified utimerexists function for game)
 - fix -> remove some unneeded variables in main script, remove one timer
 - fix moderator commands are now on DCC. Only n-users can use it (default). $privatepass no longer exists as option. See command section for help
 - fix for flags in rewards you can add multiple flags (bot only)
 - fix auto flags in channel for rewards ADDon are matched by nick!*@host
 - fix rewards html year output 
 - fix bugs and optimizing rewards ADDon reward:time and commands for DCC
 - fix for $resetrew and $rewards new way to represent values in rewards ADDon
 - fix for teams ADDon spell check to team names (only A-Za-z0-9._)
 - ADD auto stop game when the bot is not in channel for some reason or when he be kicked
 - ADD - game now match nick!*@host (where is needed) - security mesures for protection channel autoflag giving and teams mangment (moderators commands are nick match only)
 - ADD option for teams ADDon for owners of teams 'tjoin' - this make you member of your own team if you have diferent membership (only points of members are making teams score). You can always leave your team but your points are remuve from score.
 - ADD team names limit max 20 chars 
 - ADD timer option for rewards timer
 - ADD color management procedure and remove all color variables (some color changes and fixes).
 - ADD 2 new commands -scorereset and -cleardata and remove dell all and rescore all (dell and rescore are now -dell and -score and you can only <nick> managment with them) 
 - ADD to HTML page javascript table sorting script for easily arrange tables and edit html tables to work with it
 - ADD efficiency % - this value depends on how quickly you respond, how many times you tried to get right answer and how many players are playing in the moment
 - ADD namespace in group of procs in main script (you will see for what reason in next version ;)) 
#cows and bulls commands on main script###########################################
   PUBLIC COMMANDS
     !start   - starts game
	 !stop    - stops game
	 !hint    - hints game (flood protection - command is locked every hint by specific period '$livechan*$antihintflood%'. Every last hint is locked for all the time)
	 !skip    - skips game (flood protection - command is locked for $antiskipflood hints from first one)
   COMMANDS FOR ADMINS (on DCC)
     .cb -dell <user>            - delete some user from game
     .cb -cleardata              - clear databace
	 .cb -score <user> <points>  - change score for user
     .cb -scorereset             - change score to all users
     .cb -info <user>            - shows you information for user 
     .cb -invert                 - helps you to invert your data bace to crypt and uncrypt
	 .cb -addons                 - give you list of all loaded addons
	 .cb -uninstall              - help you to uninstall game parts or all game
	     -uninstall <game ADDon name>         -> this option will delete all addon components but will left user data
		 -uninstall <game ADDon name> full    -> this option will delete all data for addon (if you make full uninstall and install the same addon everithing will be reseted)
		 -uninstall all                       -> uninstall totally all game components you will lose all game data
		 -uninstall all now                   -> uninstall totally all game if you use autoloader
     .cb -install                - This game have instalation. Helps you to install all components for your game in right dirs with right permissions for the files.
# cb substitute to be used in htmlCB ###############################################
    #host    - player host
    #score   - player points
    #dtame   - player last guess
#INSTALATION########################################################################
FIRST OF ALL IF YOU CRYPT YOUR FILE TUPE ON DCC
<- .invert
# wait for decrypt your file
# to get ADDon names
<- .addons
# for uninstall some part of the game or uninstall all game use
<- .cb -uninstall <options>
# Unzip your new game!
# source your new game in conf or just replace file of the game (your instal.txt need to be in scripts dir to)
<- .rehash
<- .cb -install
-> C&B installer on. BotTEST begin! I have rights to read files, have rights to write files, 8.5 Tcl version exists.
-> BotTEST passed! Chose way to install! Type some of this options ( .install manual / recommended ) to begin!
-> WARNING BACK UP YOUR DATA After choose one of the options game installer delete or modify some old part of the game files. Read readme.txt for information how to install new versions!
#MANUAL INSTALATION################################### HOW TO INSTAL: (defalt options)
NOW YOU CAN INSTALL NEW ADDONS. TUPE ON DCC
<- .install manual
-> INSTALL ->  games.cb score.cb
-> Do you want to install HTML/XML builder v.....
# game oferts you to install some independent parts (ADDons)
<- .install Yes
# you can accept by tuping 'Yes' or reject by tuping 'No' after .install command
-> INSTALL ->  cbico.jpg default.css cbhtml.html htmlCB.tcl no.gif ofline-user.gif online-user.gif serv-offline.gif serv-online.gif templateCB.html templateCB.xml yes.gif
# game shows you file names of installed files in grean and not installed in red (game not replace existing files only modify some of them)
-> Do you want to delete instalation file? .install Yes/No
<- .install No
-> Option skipped!
-> Do you want to delete game zip file? .install Yes/No
<- .install No
# cleaning stuff
-> Option skipped!
-> Congratulations! You complete installation! Need to rehash your bot! .install Yes/No
# auto rehash if you whant
<- .install No
-> Option skipped!
-> Rehash your bot manual when you are ready. Some part of the game may not be working properly! Read readme.txt in scripts directory for usage information! Installer turn off!
#RCOMMENDED INSTALATION##############################################################
<- .install recommended
# instaler don't ask you and don't show you nothing but all so delete instaltion and zip file and automaticly rehash your bot
-> INSTALL -> HTML/XMLbuilder v.....
-> INSTALL -> REWARDS v.....
.........
-> CLEAN UP -> instal.txt -> OK
-> CLEAN UP -> cowsANDbulls.zip -> OK
-> Rehashing ...
-> Game ready to use! Read readme.txt in scripts directory for usage information! 
########################HTML/XML builder##########################################
Addon who makes html page with information about the game: options, players, points, ADDon information.
##########################NEW CHANGES#############################################
- table sorting script helps you to sort tables by browser
- fix for HTML a tag for IE bug
- new pattern background
# commands ###############################################################DCC######
  .cb -anonce <text> - This is simple information line over the table. Can be used for information for the game or whatever. When you not set 
	   anonce addon grabs topic line in channel and set it for anonce line in page.
#################################HOW TO MAKE MY HTML PAGE##########################
      To make your own html look this list below. Make your html and replace dynamic parts whit addon commands #. After instalation look in c&b 
	  folder. Open templates whit some text or html redactor and see how to do it. You have to specify dinamic data in tcl script 
	 (like how to look your html tables and what content to have). For CSS use diferent file or diferent id names from tags.
 		LIST OF HTML COMMANDS:
		     COMMAND      VARIABLES         WERE TO LOOK VARS        EXPLANE
		  #CBonoffstatus  $serverstat         C&B/htmlCB.tcl         Server status. This is picture running / stopped game. If you wish to change 
		                                                             picture change 'array set serverstat' or just change picture in C&Bhtml\html 
																	 directory
          #CBserver       $mapvars            C&B/htmlCB.tcl         This is name of the server were bot is running 'irc.wtf.com'
          #CBchannel      $cbchannel          cowsANDbulls.tcl       Game supported channel.
          #CBlastupdate   $mapvars            C&B/htmlCB.tcl         Last time where game web page has been updated
          #CBpermstart    $permisionstart     cowsANDbulls.tcl       Who have permissions to start the game \
          #CBpermstop     $permisionstop      cowsANDbulls.tcl       Who have permissions to stop the game   \ see permissions variables if you wish 
          #CBpermhint     $permisionhint      cowsANDbulls.tcl       Who have permissions to hint the game   / to change it.
          #CBpermskip     $permisionskip      cowsANDbulls.tcl       Who have permissions to skip the game  /
          #CBpermmode     $permformoderators  cowsANDbulls.tcl       Who have permissions to moderate game /
          #CBdiffic       $pointer            cowsANDbulls.tcl       Game dificulty is shows how numbers you will guess. Indicators repeat pointer 
		                                                             who you set in variable 'pointer'
          #CBpoints       $cbpoints           cowsANDbulls.tcl       How many points you got when make score.
          #CBhints        $bothints           cowsANDbulls.tcl       How many hints are allowed
          #CBchantimer    $livechan           cowsANDbulls.tcl       How many time the bot will wait until he set new game if noone is playing.
          #CBaturnoff     $turnoffhints       cowsANDbulls.tcl       Automatic turn off on/off - all on/off
          #CBshowhints    $shownums           cowsANDbulls.tcl       To show or not numbers in hints on/off
          #CBresult       $showresalt         cowsANDbulls.tcl       To show results on/off
          #CBseries       $showseries         cowsANDbulls.tcl       To show series on/off
          #CBtop3         $topgamers3         cowsANDbulls.tcl       To show TOP3 players on/off
		  #CBplayerslist  [html sistem]       C&B/htmlCB.tcl         This is all players list without any <table> tags only $playoutput elements
		  #CBgamecount    [html sistem]       C&B/htmlCB.tcl         Game counter
		  #CBanonce       [html sistem]       C&B/htmlCB.tcl         Anonce. To set anonce in web page read below
		  #CBaddons       [html sistem]       C&B/htmlCB.tcl         Html line were html file show you loaded ADDons
		  #CBdouble       $doub               cowsANDbulls.tcl       Show you double points %
		  THIS IS COMMANDS ONLY FOR PLAYERS ROWS (see  $playoutput in C&B/htmlCB.tcl)
		  #CBnumber       $playoutput         C&B/htmlCB.tcl         Serial number
		  #CBflag         $playoutput         C&B/htmlCB.tcl         Channel flag
		  #CBnick         $playoutput         C&B/htmlCB.tcl         Nickname
		  #CBscore        $playoutput         C&B/htmlCB.tcl         Score
		  #CBlasgues      $playoutput         C&B/htmlCB.tcl         Last guess
###########HOW TO SPECIFY OPTIONS IN OTHER ADDONS to work with htmlCB (example for rewards)###########
   - first write in templateCB.html or templateCB.xml table header and put #<ADDon name> in place where will be identical table information (different rows)
   <div class='tabbertab'><h2>rewards</h2><p><div class='mtable'><table id='sortr'><thead>(name of the colomns)</thead>#rewards</table></div></p></div>
   - second thing is to modify 'set html<addon name>'. It is placed in addon. You have to make normal row - part of your table already you written in template
     set htmlrewards "<tr id='sol'><a href='#' id='sol'><td>#CBnumber</td><td>#host</td><td>#rewardpoints</td><td>#relfalg</td><td>#timeleft</td></a></tr>"
    #CBnumber #host #rewardpoints #relfalg #timeleft placed as a substitute for real data and arbitrarily invented they will need in the next option
   - third option is like simply string map first with one of you allready specify options #CBnumber #host #rewardpoints #relfalg #timeleft then logical
    substitute. Substitute itself is made by substitute symbols
	 Legend of substitute symbols: < = {, > = }, ( = [, ) = ], ' = ", -> = >, <- = <
     You can see no variables here. They are here! The main are: #host - user host #score - game score #dtame - last guess. All ADDons who save in db have some 
	 of them. Search in ADDon section
    set htmlcombrewards "#rewardpoints <(string map '0 (expr #score - (string map {- 1} #Rpoints))' (expr 0 -> #score - (string map {- 1} #Rpoints)))> "
    or more clearly you can see this:
	set htmlcombrewards "#rewardpoints {[string map "0 [expr #score - [string map {- 1} #Rpoints]]" [expr 0 > #score - (string map {- 1} #Rpoints]]]} "
    AND
	string map $htmlcombrewards $htmlrewards
#############################################REWARDS addon###################################################
Gives auto-rewards to users (flag)
##########################NEW CHANGES###################################
- New logical connections for the ADDon. All rules from old game exists only options are diferent.
- New example reward table looks like this:
set rewards { 
 {"+o"  "C" "10000" "10" "30"}
 {"+v"  "C" "5000" "0" "0"}
 {"-hp|f"  "B" "100000" "10" "7"}
}
Do not remove {}. I add for example how to add +f flag on your bot and to show you multiply adding of flags. You can do this with your channel flags too. 
- new way for $resetrew which reset all players who don't have rewards. You only need to specify period in days.
# commands ######################################################################DCC#####
	  .cb -rewards <nick> flag +f (changes flag to +f)                                moderators only
	  .cb -rewards <nick> flag - (changes flag to normal user and delete duration)    moderators only
	  .cb -rewards <nick> duration +2 (+2 days reward time)                           moderators only
	  .cb -rewards <nick> duration -2 (-2 days reward time)                           moderators only
	  .cb -rewards <nick> duration 2 (sets duration on 2 days from now)               moderators only
	  .cb -rewards <nick> duration - (changes reward time to forever)                 moderators only
	  .cb -rewards <nick> reset <nick> (resets all rewards stats for user)            moderators only
	  .cb -rewards <nick> info (shows you info to a user)                             moderators only
	  !info -> public comand show to users their info                                 all users
# cb substitute to be used in htmlCB ##############################################
   #Rpoints - reward points who bot gives when drops user
   #Rflag   - rewards flag
   #RtimeL  - reward timer
################################EXPLANE FOR ADDON################################## 
    The idea is users to get some rewards for scores they get. Like 7 days op or voice. :) 1 month +f. 
    If you have bots wich have a lot of options and you set some commands only for those users who have +f others will have 
    to play C&B game and yell point to get +f status. See what i mean. Use this addon for good and make your chanel with best 
    population ;)
    - REWARDS ADDon have simple structure. Have 1 rewards table $rewards variable. Here you set your rewards
	  EXAMPLE: 
	       set rewards { 
                {"+o"  "C" "10000" "10" "30"}
                {"+v"  "C" "5000" "0" "0"}
                {"+f"  "B" "100000" "10" "7"}
                {"+m"  "B" "20000000" "1" "10"}
		    }
	 1. First column you set your flag it can be + or - <flag>
     2. Specify C - Channel flags or B - Bot flags (for bot flags search in google for 'eggdrop flags')	 
 	 3. This is score who some user have to done to be rewarded .In case if some user have 5000 points gets +v 
	  if he got 10000 - +v changes to +o.
	 4. 4 column is people limit. If you have 10 ops that means no other have reward +o before some reward expire (if expire). 
	 5. Next column is for rewards expire in days. 
	  Last 2 columns for limit and expire period has option - if you leave it 0 have no limit and expire period is forever. 
	  If some user have for example NONE expire period and after that you set in reward table some period this user have no expire period until 
	  you change it manual or after current user change reward level. Same is with limits if you set some limit after limit was empty 
	  and people are more that limits is no one gets this reward before rewards expire. 
	- next important setting is:
         set resetrew "2"
      This is option who makes reset to all results every <days> you specify. You set how many days to wait rewards timer. This option 
	  not reset people who have rewards. They have diferent timers and if they don't get new rewards before expire period they 
	  reset his score (if have reset period). This option you can leave it 0 (means is off).
############################teams addon#################################
I add new addon that will separate your channel to teams. They will compete among themselves. Anyone can make a team and invite friends.
##########################NEW CHANGES###################################
# commands #####################################################DCC#####
 + user commands: (on private)
teams new <name of team> - creates team
teams rename <new name> - rename your team
teams delete - delete your team
teams invite <nick> - invites nick to join your team 
  - have flood protection (people who do not accept your invitation)
  - you can invite only active cb players which are in cb channel
  - you can't invite people who allready have teams or DND users
teams leave - leave team
teams DND - set your status to DND and this stops all team join requests
teams tjoin - makes team owner to join his own team if he was member of diferent team when he was created his own
When you receive an invitation you can use:
 refuse - refuse invitation
 join - you join team
  + moderators commands: (on DCC)
 .cb -teams delete <team name> - to delete team
 .cb -teams rename <team name> <new name> - to rename obscene names 
# cb substitute to be used in htmlCB ###################################
 #teams - all teams information 'owner#membership'
###################################################################################################################################################
How to play. Link for wikipedia http://en.wikipedia.org/wiki/Bulls_and_cows
###################################################################################################################################################
NOTE:
For eggdrops: your bot need to have permissions to write and store files in directories.
For windrops: if you have problems with vista, win7 permissions run eggdrop.exe as administrator for instalation. 
  
#All bugs in original version of the game is supported (gameoverbg@gmail.com). All other questions for game mods is not supportable.