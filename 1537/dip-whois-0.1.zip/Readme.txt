Domain/IP Whois by Sickness (v0.1)

About:
Uses WhoisXML from hexillion.com to retrieve whois information
In my opinion this script will give you the best results.
I've seen other avaible scripts fail on various lookups where this DB does not.

Requirements:
TCL http lib (yes you have this! :P)

Notes:
Tested on Eggdrop 1.6.19 (TCL 8.5)
Thanks leprechau for finding the url ;)
Thanks #eggtcl on EFnet for all the help in the past years
If you're having problems with this script and need help, I'll be avaible on #eggtcl somehwere ;)