Edit eva.tcl ( the first 10-15 lines ) 

then add a connection block in your hub and make sure that the info in eva.tcl match it.

.rehash and /connect hub.network.org 

Enjoy.