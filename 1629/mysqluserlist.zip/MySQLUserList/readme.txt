##########################################################################
#
#   MySQL User List Script
#   Author: MPIIIMan
#   Version: 1.0
#   Requirements: libmysqltcl
#   Support: mpiiiman@gmail.com
#
##########################################################################
#
#   Requirements: libmysqltcl
#
##########################################################################
#   
#   General Description:
#   This script populates a MySQL table with the users on a given channel
#   
#   Technical Description:
#   When the bot starts the script, the user table is completely emptied.
#   The user table will get populated after the bot has been on the chan
#   for one minute.
#   The bot will then update the table on JOIN, QUIT, NICK, LEAVE, KICK.
#   Every hour the bot will completely re-synch the table.
#
##########################################################################
#
#   Use the Query below to set up your MySQL Table
#
##########################################################################

CREATE TABLE `irc_users` (

`Username` varchar(255) NOT NULL,
  
 UNIQUE KEY `unique` (`Username`)

);