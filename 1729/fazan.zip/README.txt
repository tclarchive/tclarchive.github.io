INSTALARE :

1.Pune tcl-ul "fazan.tcl" precum si directorul "fazan" in scripts.
2.Pune in config linia "source scripts/fazan.tcl"
3.Rehash
4.Cam atat :)

						Have Fun.