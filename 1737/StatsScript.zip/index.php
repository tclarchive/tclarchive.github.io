<?php 
 
 
$channel = bin2hex ($_GET['chan']); 
 
$datei = $channel.".html"; 
 
if (file_exists ($datei) ) { 
 include_once ($datei); 
} 
else 
{ 
 echo "<center><h3>Diese Statspage existiert nicht, oder wurde noch nicht generiert.</h3></center>";
 echo "";
 echo "<center>---</center>";
 echo "";
 echo "<center><h3>This Statspage doesnt exist, or was not generated yet.</h3></center>";
 echo "";
 echo "<center>Stats by Uncle|Sam (#Antenne @ Quakenet.org)</center>";
} 
 
 
 
?>  