################################################################
### Scramble.tcl Author : Bhasirc Network & Indra^Pratama    ###
### Edition by : Indra^Pratama Staff BhasIRC Network         ###
### Last updated : 2012/01/22                                ###
### CopyRight @ BhasIRC Network visit Http://www.bhasirc.com ###
### Thanks To : Egghelp Owner Website Http://www.egghelp.org ###
################################################################

About instalasi scramble.tcl You Must Following my instruction so that this script can run in your eggdrop :

1. make folder "scramble" in directori your "eggdrop"
2. put file 'scramble.tcl' and 'scramble.rc' to folder "scramble"
3. open folder "quizdata" in directori "scramble"
4. insert file 'questions.bandon.en, channelrules.txt, channeltips.txt & prices.txt' to folder "quizdata"
5. Edit file "scramble.rc" change "quizchannel = #channel" to name your channel
5. If you want added new question, edit file 'questions.bandon.en' and copy paste using format before you edition
6. if you want add questions in your bot command is: /msg NICKBOT !userquest Questions::Answers
      Example: /msg Botnick !userquest your city::balikpapan

How setting config to your BOT :
- tcl will be running if you make sure the source, Look this example !!! 

source scripts/alltools.tcl
source scripts/action.fix.tcl
source scramble/scramble.tcl

Note : Its Scripts Support 2 Languages You Can Change This Script To Be English or Indonesia Only And This Scripts Support Colour And You Want Question in English??? Use File "q.en" and You Must Make Only Your File Question on "q.en" if you confused i will help you about the Question see "entertainment.txt" in that file txt have a question and answer You just copy & paste the question and answer and type the question you can look example in "q.en" file and take in "entertainment.txt"
Thanks For Using Scramble.tcl By BhasIRC Network :)
