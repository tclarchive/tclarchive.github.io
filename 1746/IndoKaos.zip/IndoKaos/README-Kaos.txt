############################################################################
###---IndoKaos By Indra^Pratama Staff BhasIRC                         ---###
###---Author This Scripts : Indra^Pratama Staff BhasIRC               ---###
###---Website Author : www.ajimaltez.co.cc and www.bhasirc.com        ---###
###---Thanks To : www.egghelp.org Website provider Eggdrop Tcl script ---###
############################################################################
#######################################################################################
###---How Setting IndoKaos Game                                                  ---###
###---Make Folder Kaos put Kaos.tcl                                              ---###
###---Make In Directori Kaos New Folder Name "question" put Kaos.cfg and Kaos.db ---###
###--- And Following Put Source in Eggdrop.conf                                  ---###
###--- source scramble/kaos.tcl                                                  ---###
###--- source scramble/question/kaos.cfg                                         ---###
###--- source scramble/question/kaos.db                                          ---###
#######################################################################################