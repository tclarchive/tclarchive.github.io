aop.tcl

aop.tcl is an auto-op script for eggdrops running netbots. 
It's my first script and it's not even 100% mine, but that doesn't really matter :-)
It's based upon chanlimit.tcl by johoho and slennox and actually works the same way with some minor adjustments.

I wrote it for a friend who had some problems with op-flooding and I decided to make it public when I read the same "complaints" in the eggdrop mailinglist. 
Although auto-opping isn't the securest thing on earth... this script can usefull to some people.

Feel free to e-mail me for any complaints or tips or whatever. (evolver@blue.penguin.nl)

One last note: Don't try this script with the cookie ops from Raeky. I haven't tried using them together but I don't think it will be something nice :-)
   
