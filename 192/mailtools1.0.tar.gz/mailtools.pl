#!/usr/bin/perl

########################################################
########################################################
###                                                  ###
## Script courtesy of Microlf <bortah@defcon.hiof.no> ##
## A part of the mailtools1.0.tcl eggdrop script      ##
## by Taske <espensol@defcon.hiof.no                  ##
###                                                  ###
########################################################
###                                                  ###
## GENERAL INFO:                                      ##
## -------------                                      ##
## You have to make a .forward file in the root of    ##
## your home directory (the directory you end up in   ##
## when you do 'cd'). .forward must start with the    ##
## path to this script on the form:                   ##
## "|/home/username/path/mailtools.pl"                ##
## Be sure to include the quotation marks!            ##
##                                                    ##
## IMPORTANT: Make this perl script executable by     ##
##            issuing the command:                    ## 
##            chmod +x mailtools.pl                   ##
###                                                  ###
########################################################
########################################################

# GLOBAL VARIABLES (change these to suit you)

# Your homedirectory
$homedir = "/home/username";

# Name of the file to store checked mail in.
$mailfile = "botmail";

# The path to the spool directory of your system
$mailpath = "/var/spool/mail";

# The name of the account the bot is on
$name = "username";

# Subject of the mails this script is going to check.
# IMPORTANT: Make it the same as chk_subj in mailtools1.0.tcl
$subject = "IRCchk";

###############################################
### DO NOT CHANGE ANYTHING BELOW THIS LINE! ###
###  If you do, strange things may happen.  ###
###############################################

@mail = <STDIN>;

foreach $line (@mail) {
   if($line =~ /Subject: $subject/) {
      $botmail = 1;
   }
}

if ($botmail == 1)  {
   open(FOUT, ">>$homedir/$mailfile") or die "Error opening file.";
      foreach $line (@mail) {
         if($record == 1) {
            if($line =~ /[a-z]/) {
               print FOUT $line;
            }
         }
         if($line =~ /Subject:/) {
            $record = 1;
         }
      }
   close FOUT;
}
else {
   open ( M , ">>$mailpath/$name" ) or die "Cannot open mailfile.";
   print M @mail;
   print M "\n";
   close M;
}