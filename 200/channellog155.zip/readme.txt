Eggdrop Multiple Channel Logger for mIRCStats
The tcl will only run on eggdrop1.6.0 or newer!!!
NOTE: This version of mEL uses new config files!!!
      Config files will only be imported when stored in the same "statsdir"!!
NOTE2: If you're upgrading from 1.5.4 don't worry about the script 'misreading'
       your current init.mel because 1.5.5 doesn't support ignores. The script
       will automatically convert your init.mel.

Installing the logger.

Copy channellog155.tcl to the scripts directory of your eggdrop. 
Use a text editor (notepad in windows or pico on linux machines) to edit the
tcl. Variables statsdir and statslogdir should be filled in correctly or else
the script won't run and neither will your bot. Make sure those pathnames
exist on your system and remember that linux is case-sensitive.
Next set variable "logkeeper" to *your* nickname on the bot. If you in-
correctly set this variable then you can't do anything with mEL at all.
Finally choose whether or not you want to use a '#' in logfile names and if you
are upgrading from a pre 1.5.4 version. Close the texteditor and save the changes
made. Next copy the file mel.help to your eggdrop's help directory and add the
line "loadhelp mel.help" to the config file of your eggdrop.
Then add the line "source scripts/channellog155.tcl" to the configuration file 
of your eggdrop. Then simply restart your bot.

Here's an overview of possible commands on mEL v1.55:
Ok, all partyline commands for mEL start with .mel
Simply typing in .mel gives you an overview of parameters you can add to the
command.

.mel	on			- Turns logging on. This only works when at
				  least one channel has been added for logging.
				  When the tcl loads for the first time the
				  logging is still disabled and will auto-
				  matically start as soon as you add a channel.
	off			- Yes, well, this turns off logging. 
	setdays <0/n>		- Sets the amount of days to log before auto-
				  matically switching logfiles. When setting
				  this to 0 mEL goes into mAC mode, which means
				  mEL will log continuously and mAC will take
				  care of the logfile switching.
	status			- Shows you whether mEL is on or off, on what
				  day it is logging or if it is in mAC mode and
				  the channels mEL is currently logging.
	+chan <#channel>	- Adds a channel you wish to be logged. Logging
				  starts right after you've added the channel.
	-chan <#channel>	- Removes a channel. mEL closes logfile of this
				  channel. If no channels are left to be logged
				  mEL shuts down logging.
	erase			- Removes redundant logfiles. When you -chan a
				  channel the logfiles won't be removed. Use
				  this command to remove those logfiles from
				  the partyline.
	addkeeper <nick>	- Adds a logkeeper. The new logkeeper can do
				  everything in mEL you can, except for adding
				  or removing other log keepers.
	rmkeeper <nick>		- Removes a logkeeper. There's only one log-
				  keeper that can't be removed and that's you!
	listkeeper		- Shows you a list of logkeepers.



FAQ!

Q: Why did you write this script?
A: Maybe I got bored a long time ago :-P Nahh... I was just browsing and all
   of a sudden I got to Ave's mIRCStats page and I saw the incredibly beauti-
   ful statistics page you could make with just mIRCStats and a mIRC log.
   But to make correct statistics pages I needed a 24/7 logfile, but I was
   on dialup. So I figured I'd write a script for eggdrop which logs the
   same way mIRC does. And you just downloaded it! :-)

Q: Why have you removed ignores?
A: Because mIRCStats itself has a much better ignore function.

Q: Is the 'erase' command safe?
A: Yes, it's perfectly safe. mEL keeps track of channels which have been
   -chan'ed. Only the logfiles of those channels will be erased when found.
   Note that the 'erase' command does not work with parameters so therefor
   nothing but old logfiles can be erased from the partyline.

Q: mEL adds a datestamp to each and every logfile, can I disable that?
A: Yes, you can. But not from the partyline. Set the variable dslogfiles to 0.

Q: I'm running mEL in mAC mode and I want to switch back to manual mode. Do
   I lose the current logfile?
A: You what?!?! Why would you want to.... ehhh... hmmmm... :-P
   No, you don't lose the current logfile, it gets backed up and mEL starts
   a new logfile. Same thing happens when you switch from manual to mAC mode.

Q: I have a brilliant idea for mEL... 
A: Great!! Send any ideas, suggestions or even modifications to mEL to
   mel@angelbears.org

Q: I set up the script on my eggdrop and everything seems to be running fine, 
   but every time I try to use the .mel command I get this:
	[13:48] <MelTest> You are not allowed to perform maintenance!
	[13:48] <MelTest> Contact Jules for more information
	[13:48] <MelTest> mIRCStats Eggdrop Logger v1.5.5
   What's wrong here?
A: Well, you forgot to set the variable logkeeper. Make sure that *your* handle
   is set as the logkeeper, not the eggdrops nickname!! 

Q: When I do .mel status I get the following message:
	[13:24] <MelTest> mEL has disabled switching!!! Please use .mel setdays to enable switching!!
	[13:24] <MelTest> mEL is NOT running in mAC mode and mEL is NOT switching logfiles!!!!!
   What on earth did I do wrong?!?
A: Nothing much, really... mEL needs you to use .mel setdays... after you've done that once this
   message will go away and never come back :-)

Q: Every time my eggdrop reboots or rehashes I get this during startup:
	[13:09] <MelTest> v1.5.5 DO NOT FORGET TO SET 'UPGRADE' TO 0!!! DO IT NOW!!!
   Add to that that all the channels, keepers and ignores are gone!!!!
A: Let's hope you only got this message twice... You have upgraded from an older version
   and let mEL import old settings... but you forgot to disable the importing...
   First of all set 'upgrade' to 0. Then look for the file init.mel.before and open it.
   If you're lucky you'll find all your imported stuff in there. If so, rename it to
   init.mel.
   oops... you weren't lucky... only means you gotta do more work... the old config files
   now have extension *.pre... change their extension to *.mel, set 'upgrade' to 1 and reboot
   the bot... now... IMMEDIATELY set 'upgrade' to 0... that should fix it.

Q: So, really, when does the automatic switcher actually switch logfiles?
A: Yes, that can be confusing, though I've tried to make .mel status as clear as possible.
   The status command should give you something like this:
   <MelTest> mEL is turned On
   <MelTest> mEL switches logfiles every 5 day(s).
   <MelTest> Next switch is at the first second of 02/04/2001
   <MelTest> Today is 28/03/2001
   <MelTest>     Logging #meltest
   <MelTest> 
   <MelTest> Storing settings in mel/
   <MelTest> Storing logfiles in mel/logs/
   OK, so this means that when the date changes from 01\04\2001 to 02\04\2001 the logfile
   gets switched.
   This status overview also explains where your logfiles are stored... some users got confused
   with that bit. 