# MySQL dump 8.2
#
# Host: localhost    Database: bots
#--------------------------------------------------------
# Server version	3.23.13a-alpha

#
# Current Database: bots
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ bots;

USE bots;

#
# Table structure for table 'bot'
#

CREATE TABLE bot (
  id int(3) unsigned NOT NULL auto_increment,
  bot char(25),
  PRIMARY KEY (id)
);

#
# Table structure for table 'chan'
#

CREATE TABLE chan (
  id int(2) unsigned NOT NULL auto_increment,
  chan char(25),
  PRIMARY KEY (id)
);

#
# Table structure for table 'hand'
#

CREATE TABLE hand (
  id int(6) unsigned NOT NULL auto_increment,
  hand char(16),
  PRIMARY KEY (id)
);

#
# Table structure for table 'host'
#

CREATE TABLE host (
  id int(10) unsigned NOT NULL auto_increment,
  host char(80),
  PRIMARY KEY (id)
);

#
# Table structure for table 'ident'
#

CREATE TABLE ident (
  id int(8) unsigned NOT NULL auto_increment,
  ident char(20),
  PRIMARY KEY (id)
);

#
# Table structure for table 'last'
#

CREATE TABLE last (
  lin int(10),
  lout int(10),
  nick int(8)
);

#
# Table structure for table 'master'
#

CREATE TABLE master (
  Stat int(2),
  fecha_hora timestamp(14),
  nick int(8),
  host int(10),
  ident int(10),
  hand int(6),
  chan int(2),
  bot int(3),
  msg int(10),
  mod int(8),
  id int(8) unsigned NOT NULL auto_increment,
  PRIMARY KEY (id)
);

#
# Table structure for table 'mod'
#

CREATE TABLE mod (
  id int(8) unsigned NOT NULL auto_increment,
  mod char(80),
  PRIMARY KEY (id)
);

#
# Table structure for table 'msg'
#

CREATE TABLE msg (
  id int(10) unsigned NOT NULL auto_increment,
  msg text,
  PRIMARY KEY (id)
);

#
# Table structure for table 'nick'
#

CREATE TABLE nick (
  id int(8) unsigned NOT NULL auto_increment,
  nick char(16),
  PRIMARY KEY (id)
);

#
# Table structure for table 'stats'
#

CREATE TABLE stats (
  id int(1),
  stat char(10)
);

