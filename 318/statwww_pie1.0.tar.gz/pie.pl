#!/usr/bin/perl

# -------------------------------------------------------------------- #
#     pie.pl by Mikko Pikarinen, goblet@goblet.net 1999                #
#                                                                      #
# This draws the GIF file. See pie.README                              #
# If you can't get this to work, it's YOUR problem. _DO_NOT_EMAIL_ME_  #
# This is free to use but don't remove the info about original author! #
# ---------------------------------------------------------------------#

use GD;

# first parameter must be the channelname.
$datafile = "pie." . substr($ARGV[0],1,99) . ".dta";
$datafile =~ tr/A-Z/a-z/;

# Create the gif-object and allocate the colors.
$im = new GD::Image(420,290);

$white = $im->colorAllocate(255,255,255);
$blk = $im->colorAllocate(0,0,0);
$red = $im->colorAllocate(255,0,0);
$blu = $im->colorAllocate(0,0,255);
$gre = $im->colorAllocate(0,128,0);
$grey1 = $im->colorAllocate(128,128,128);
$grey2 = $im->colorAllocate(220,220,220);

$col[1] = $im->colorAllocate(255,0,0);
$col[2] = $im->colorAllocate(0,224,0);
$col[3] = $im->colorAllocate(255,255,0);
$col[4] = $im->colorAllocate(0,208,208);
$col[5] = $im->colorAllocate(0,0,255);
$col[6] = $im->colorAllocate(128,0,0);
$col[7] = $im->colorAllocate(255,128,128);
$col[8] = $im->colorAllocate(0,128,0);
$col[9] = $im->colorAllocate(208,128,0);
$col[10] = $im->colorAllocate(208,0,208);

# Make the border and other background stuff
$im->arc(265,160,301,201,0,360,$grey2);
$im->fill(265,140,$grey2);
$im->line(0,0,419,0,$grey1);
$im->line(0,0,0,289,$grey1);
$im->line(419,0,419,289,$blk);
$im->line(0,289,419,289,$blk);
$im->rectangle(3,15,97,270,$grey2);
$im->fill(4,16,$grey2);
$im->line(98,15,98,270,$blk);
$im->line(3,270,98,270,$blk);
$im->line(3,15,98,15,$grey1);
$im->line(3,15,3,270,$grey1);

# Channel name to the top
$foo = length($ARGV[0])/2;
$im->string(gdLargeFont,255-$foo*8,3,$ARGV[0],$blk);
$im->string(gdLargeFont,256-$foo*8,3,$ARGV[0],$blu);

# Date to the right upper corner
($sec,$min,$hour,$day,$month,$year,$wod,$doy,$isdst) = localtime(time);
$year += 1900;
if (time > 946677600) {$year += 100}
$month++;
$im->string(gdTinyFont,350,25,"$day.$month.$year",$blk);
$im->string(gdTinyFont,300,260,"http://www.goblet.net/",$blk);

# Format, read and process the topten-data.
for ($j = 0; $j < 11; $j++) {$perc[$j] = 0;}
$amount = 1;
open(datafile,$datafile);
while ($row = <datafile>) {
  chop $row;
  ($perc[$amount], $nick[$amount]) = split(" ", $row);
  $amount++;
}
close datafile;

# Convert percents to degrees and add spaces for values less than 10.0%
for ($j = 0; $j < $amount; $j++) 
    {
     $sect[$j] = $perc[$j]*3.6666666666666;
     $foo = length($perc[$j]); 
     if ($foo < 4) {$perc[$j] = " " . $perc[$j]}
    }

# Draw the slices
$s = 270;
for ($i = 1; $i < $amount; $i++)
   {
   $e=$sect[$i]+$s;
   if ($e < $s) {$e = $e+360}
   for ($k = 1; $k < 300;$k++) 
      {
       $e = int($e) % 360;
       if ($e > 360) {$e=360}
       $im->arc(255,131,$k,$k*0.66,$s,$e,$col[$i]);
       $im->arc(255,130,$k,$k*0.66,$s,$e,$col[$i]);
      }
   $s = $e;
   }

# Write the nicks into the box and right coloured lines below them.
for ($i = 1; $i < $amount; $i++) 
    {
    $im->string(gdSmallFont,6,$i*25,$nick[$i],$blk);
    $im->string(gdSmallFont,65,$i*25,"$perc[$i]%",$blk);
    $im->line(5, (($i * 25) + 15), 95, (($i * 25) + 15), $col[$i]);
    $im->line(5, (($i * 25) + 16), 95, (($i * 25) + 16), $col[$i]);
    $im->line(5, (($i * 25) + 17), 95, (($i * 25) + 17), $col[$i]);
    }

# Draw the rim for pie etc
for ($i=131; $i < 150; $i++)
    {
    $im->arc(255,$i+1,300,300*0.66,0,180,$blk);
    $im->arc(255,$i,299,299*0.66,0,180,$grey1);
    }
$im->arc(255,130,300,300*0.66,0,360,$blk);
$im->arc(255,131,300,300*0.66,0,360,$blk);

# Output the gif-image.
binmode STDOUT;
print $im->gif;
