|------		  ------|
|-- WebWriter v 1.2.1 --|
|------		  ------|
modified 18.02.99

This script is written by Bj0rge @ irc.sol.no --> #Ris0r, #TB, #Quiz-Show & #�ndal.

If you got any questions, go msg me @ undernet (if I'm online), Or else you can send me a e-mail @ naessbj@online.no
Feel free to edit whatever you like in this script, but please give me (at least a small) credit :)

### Changes in version 1.2.*
	+The only change in version 1.2.* is the possibility
	 to use it for more than one channels...
### Changes in version 1.2.1
	+This version should now work with Netscape.. *erm..*
	+The last seen field contains now hour:minute format
	+The "#" -character in the htm file is stripped out
	+more...