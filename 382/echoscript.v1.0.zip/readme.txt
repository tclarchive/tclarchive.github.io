EchoScript 1.0 By Neo

 This script is used to echo a person or bot  using your
 eggdrop bot.  It's  very  simple, just  place  the chan 
 you want the bot to echo to, then ddc chan with the bot
 and type <.+site nick usermask> "nick' can be  anything
 u like  and "usermask" is the mask of the person or bot
 u want the bot to echo.  If you've  done all  that, you
 are all set.  To remove  the person or  bot you want to
 echo, ddc chat your bot and type <.-site nick>.

                                -neo (neo@intergate.ca)