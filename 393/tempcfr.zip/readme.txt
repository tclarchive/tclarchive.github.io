	TEMPC100FR.tcl

Traduction francaise du tcl tempc100.tcl

Par : lechat

www.lechat.t2u.com

lechat@t2u.com

Tout droit reserves a l`auteur original de ce script
seul la traduction a ete effectuee , aucune modification au script a ete apportee.

amusez-vous 

lechat