/*
** Background Execution for Eggdrop
** Written by Fosters@G0
**
** (c) Copyright 1998 Eden Developments
**     All Rights Reserved
**
** Useage:
**
**  bgexec filename command [args]
**
** Compile With:
**
**  gcc bgexec.c -o bgexec
*/

#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Protos */
extern void bgexec(char *file, char *command);

int main(int ac, char *av[])
{
	char buf[512];
	int loop;
	
	if(ac < 3)
	{
		fprintf(stderr, "Useage: %s outputfilename command [arg1 ... argN]\n", av[0]);
		return(20);
	}
	
	/* Build string for system() */
	for(loop = 2;loop < ac;loop++)
	{
		strcat(buf, av[loop]);
		strcat(buf, " ");
	}
	
	bgexec(av[1], buf);
	
	exit(0);
}

void bgexec(char *file, char *command)
{
	char buf[1024], tmp[256], cbuf[512];
	FILE *ip, *op;
	
	if(fork() == 0)
	{
		tmpnam(tmp);
		sprintf(buf, "%s >>%s 2>>%s", command, tmp, tmp);
		system(buf);
		
		/* Rather lame file copy, but it works :) */
		if(ip = fopen(tmp, "r"))
		{
			if(op = fopen(file, "w"))
			{
				while(fgets(cbuf, sizeof(cbuf), ip))
				{
					fputs(cbuf, op);
				}
				fclose(op);
			}
			fclose(ip);
		}
		
		remove(tmp);
	}
	
	return;
}
