/*
** bgexec.c by Fosters
** Eggdrop 1.3.x module for background execution
**
** (c) Copyright 1998 Eden Developments
**     All Rights Reserved
*/

#define MAKING_BGEXEC
#define MODULE_NAME "bgexec"
#include "../module.h"
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#undef global
static Function * global = NULL;

static int processes;
static char bgexec_path[121];

/* Execute command in background */
static int tcl_bgexec STDVAR
{
	char exe[512];
	
	BADARGS(3, 3, " file command");
	
	if(!bgexec_path[0]) strcpy(bgexec_path, "~/bin/bgexec");
	
	/* The bgexec program will fork ... this avoids zombie eggdrops :) */
	sprintf(exe, "%s %s %s", bgexec_path, argv[1], argv[2]);
	system(exe);
	processes++;
	
	return TCL_OK;
}

static int bgexec_expmem()
{
	int size = 0;

	context;
	return size;
}

/* a report on the module status */
static void bgexec_report (int idx, int details)
{
	int size = 0;

	context;
	if (details)
	{
		dprintf(idx, "   bgexec v1.3 by Fosters\n");
		dprintf(idx, "   %d background processes have been run\n", processes);
	}
}

static tcl_cmds bgexeccmds[] =
{
	  {"bgexec", tcl_bgexec },
	  { 0, 0 }
};

static tcl_strings bgexecstrings[] =
{
	{"bgexec_path", bgexec_path, 120, 0},
	{ 0, 0, 0, 0}
};

static char *bgexec_close()
{
	context;
	
	rem_tcl_commands(bgexeccmds);
	rem_tcl_strings(bgexecstrings);
	module_undepend(MODULE_NAME);
	
	return NULL;
}

char *bgexec_start ();

static Function bgexec_table[] =
{
	(Function) bgexec_start,
	(Function) bgexec_close,
	(Function) bgexec_expmem,
	(Function) bgexec_report,
};

char *bgexec_start (Function * global_funcs)
{
	global = global_funcs;
	context;
	
	module_register(MODULE_NAME, bgexec_table, 1, 3);
	
	if (!module_depend(MODULE_NAME, "eggdrop", 103, 0))
		return "This module requires eggdrop1.3.0 or later";
	
	add_tcl_commands(bgexeccmds);
	add_tcl_strings(bgexecstrings);
	
	processes = 0;
	
	return NULL;
}
