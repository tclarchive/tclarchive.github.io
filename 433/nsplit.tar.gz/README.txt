# nSPLiT v1.01 (c)2001 jestrix
# jestrix@jestrix.net
# #jiso on efnet
####################################

This script is a netbots component
netbots (c)1998-2001 by slennox <slennox@egghelp.org>

####################################
INTRODUCTION:

nSPLiT compares the currently linked servers on the network to a master list in order
to report split servers.
Whenever a 'SPLT' is detected, the split list is updated.  It is also updated every
X minutes (user-defined) to catch any splits that occurred on servers not reported to 
any of the bot's channels.

More specifically, nSPLiT is coded as a netbots component (tested on netbots v3.80 with eggie
v1.6.6).  Whenever the current links list needs to be updated, the main bot, which responds to
the public command, tells one of the linked bots to fire off a LINKS command to the server.  This
bot then relays the information back to the main bot, where the list is updated. No bot will be
used twice in a row: the list is cycled repeatedly.

You may wonder what the purpose of using this method is. Previous versions of nSPLiT (prior to
v1.00) had the main bot request a LINKS from the server. If there were a lot of splits, or if the
update time was brief, the server would ban the bot for linklooking.  Under the new method, the
bot who actually sends the LINKS always varies, so there is very little chance of the bots being
banned (unless of course you only have 2 bots in your botnet). In my botnet of 33 bots, the script
prevents all bans.  If you require a greater indepth explanation, read through the code: it's all
commented for explanation.

This script relies on a master server list.  The first time you run it, the list will be 
generated from the servers currently linked. If you wish to update the master list after this,
(which is a good idea) you must use the dcc command
".updatelinks"

Please note that the original files will be generated only after the bot has completed all of
its other startip tasks (like asking for ops, invites, etc).  Give it a few minutes before you
write me and tell me it's not working!!!

If you wish to manually update the list, the format is simply a 1 line file with each server
seperated by a @
Example:
irc.aaa.com@irc.bbb.net@irc.ccc.org@

Note the trailing @ !  That is important....

##################################
INSTALLATION:

-As I have said before, this is a netbots component!  Therefore, your botnet must be running netbots
-to user this script.  It has been tested on eggdrop1.6.6 with netbots v3.80 - compatability with
-previous versions is not guaranteed.

STEP ONE:
Put nsplit.tcl in your netbots directory of the main bot

STEP TWO:
Edit the netset.tcl of your main bot.  Add the following info:
 set nb_component(nsplit) 1     <-Tells netbots to load the nsplit component
 set ns_bot "bitchtits"         <-The name of the main bot as specified in its conf
 set ns_offlinebots "Hubbot"    <-Names of any offline bots who cannot send LINKS commands
 set ns_lnklst "/bot/links.lst" <-Full path to the Master Links file (file will be created)
 set ns_lnktmp "/bot/links.tmp" <-Full path to the Current Links file (file will be created)
 set ns_chan "#lame"            <-A channel where all your bots hang out (used to determine if a bot is on the same side of a split)
 set ns_updtt 30                <-Amount of time (in minutes) between link updates
 set ns_showhubs 0              <- 0/1 - 0 will exclude hubs from being displayed on the public command.
 set ns_hublist [list ircd irc-h hub services]  <- A list of terms to search for to determine if a server is a hub.  (this list is set for EFNet)

STEP THREE:
Rehash your main bot.  Make sure the following information is displayed on rehash:
 Loading netbots.tcl v3.80 by slennox..
 Loaded components: etc etc, nsplit, etc etc
 
STEP FOUR:
Update all the netbots!
 Use ".netupdate -file netbots/nsplit.tcl" to send out the new file.  This assumes you are using a
  netbots directory in the bot's root dir.  Some people may have to change this to scripts/netbots/nsplit.tcl.
 Use ".netupdate -settings" to send out the new netset.tcl
 

That's it.  Any questions?  Direct them to jestrix@jestrix.net or find me in #jiso on efnet


##################################
COMMANDS:

--In the partyline (owners only):
   .updatelinks    -  refreshes the master list
   .getlinks ?bot? -  refreshes the current link list.  If a bot is specified, that bot will send
                      out the LINKS command to the server.

--In the channel:
   !netsplits    -  lists current netsplits. (If the current links list is not available for some
                    reason, the channel will recieve the following error:
                    nSPLiT 1.01 Splits are currently unavailable
       
##################################
Version History 

v1.01 - bug free reworking of v1.00
v1.00 - complete rewrite as netbots component (buggy - not public)
v0.25 - partial rewrite to help prevent links flooding
v0.20 - Initial public release


/me thanks Mooeyenz for the substance abuse counseling required to write this script.