####################################################################################################################							#########################
###################                      Count2_4FR.tcl                 #########################


ceci est la traduction francaise du tcl count2_4.tcl Join Counter 2.4 by Turbo- 

e-mail du createur : milesp@connect.ab.ca

Aucun changement autre que la traduction francaise n`as ete effectuee sur ce script et l`auteur en garde les droits originaux

pour Informations sur cette traductions ou commentaires :

lechat@t2u.com

Enjoy !

lechat