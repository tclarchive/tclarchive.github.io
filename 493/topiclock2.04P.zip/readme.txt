 topiclock.tcl v2.04P [11 November 2001]
original info: 
	topiclock.tcl v2.04 [11 November 2000] 
	Copyright (C) 1999-2000 Teemu Hjelt <temex@iki.fi>

Updated and enhanced by Paladinz Nov 2001
iant@cyberdude.com or find me on 1warez on IRC Underent
 
 If you have any suggestions, questions or you want to report 
 bugs, please feel free to send me email to temex@iki.fi

 With this script you can lock topics of channels,
 so that the users of the channels can't change them.

ADDED BY PALADINZ
now this script saves the topics to a file on your shell, so it is available when you need to restart the bot,
the original tcl lost the topic when the bot restarted.

 Current DCC Commands:
    .tlock, .tunlock, .tlockall, .tunlockall, .tlhelp
     
 Current MSG Commands:
    tlock, tunlock, tlockall, tunlockall, tlhelp
 
 Current Channel Commands:
    tlock, tunlock, tlockall, tunlockall, tlhelp

 Tested on eggdrop1.6.6 with TCL 7.6

 Version history:
 v1.00 - The very first version!
 v1.01 - Fixed a little bug in topc:tl_change proc.
         Also made the channel option optional and
         added the help section.
 v2.00 - Rewrote almost everything and made this script also more compact.
         Fixed a bug that allowed multiple timers to start. Now the flood
         protection takes effect only on chans whose topic is locked. Added
         also channel and msg commands. Now you can also lock or unlock
         topics of all channels by using tlockall and tunlockall commands.
 v2.01 - Oops! Missing ')' caused a syntax error and I also forgot to bind few procs.
 v2.02 - Little cosmetic changes.
 v2.03 - Made this script more secure and fixed few little bugs.
 v2.04 - Fixed minor bug in the topc:tl_change proc. (Found by TiM)
 v2.04P - Support for the use of files to store topics added by Paladinz
