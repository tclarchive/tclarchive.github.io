#Complete Channel Administration Script (CCA Script)

Installation Instructions:

	- Add 'source scripts/ccaset.tcl' (without the '') to your eggdrop.conf file
	- *EDIT* the ccaset.tcl file to use your OWN settings (unless you run #Lamer on EFNet)
	- *EDIT* the rulesend.tcl to include your own messages (Example messages are already there)
	- Copy ALL of the TCL files into your 'scripts' directory
	- Rehash your bot (no restart required)
	- Visit #FTP4Warez on EFNet and msg me (Loki`) your comments and/or requests
		(YES, I *will* add to/change this script upon request)
	- Type !ccashelp and !ccasfeatures on your op channel for full feature/trigger listing

Have Fun!  And enjoy your lamer free channel!



#---------------------------------------------------------------------------------------
#             Currently Supported Features:
#---------------------------------------------------------------------------------------
#  Auto-Banning XDCC/TDCC Bots
#  Monitoring and Auto-Banning Onjoins/Onparts (including virus DCC's)
#  Monitoring for SPAM and Mass MSG'ing and Auto-Banning
#  Auto-Banning of SPAM-type recruiters
#  Auto-Kicking of people using annoying script ads in the channel
#  Auto-Kicking of people listing websites in the channel
#  Auto-Kicking of people using ! or @ triggers
#  Auto-Kicking of people using excessive !!!!!!!!!!!'s and/or ??????????'s
#  Auto-Kicking of people begging within 60 seconds of joining
#  Auto-Sending of channel rules upon CTCP request
#  Auto-Sending of customizable text upon CTCP request
#---------------------------------------------------------------------------------------
#             Basic channel OP triggers support:
#---------------------------------------------------------------------------------------
#  Perm Banning:
#	!ban <nick> [reason]
#	!perm <nick> [reason]
#	!ban <hostmask> [reason]
#	!perm <hostmask> [reason]
#---------------------------------------------------------------------------------------
#  Kick/Banning (60min ban):
#	!kb <nick> [reason]
#---------------------------------------------------------------------------------------
#  Kicking:
#	!k <nick> [reason]
#	!kick <nick> [reason]
#---------------------------------------------------------------------------------------
#  Unbanning of both channel and/or bot bans:
#	!unban <hostmask> [global]
#---------------------------------------------------------------------------------------
#  Adding FTP's to the bot and/or giving them +v in the channel:
#	!addserv <nick>
#---------------------------------------------------------------------------------------
#  Removing FTP's from the bot (essentially the same as !deluser):
#	!delserv <nick>
#---------------------------------------------------------------------------------------
#  Adding new OPs to the bot and/or giving them +o in the channel:
#	!addop <nick> [global]
#---------------------------------------------------------------------------------------
#  Removing users from the bot (essentially the same as !delserv):
#	!deluser <nick>
#---------------------------------------------------------------------------------------

# Created by Loki` (#FTP4Warez on EFNet)

#Version History:
#
#10/02/2001 - 1.0	Initial Release
#10/05/2001 - 1.1b	Added the following:
#				!addbot <nick>		- Adds a user with +vf flags (meant for sitebots)
#				!chattr <nick> <flags>	- Changes users flags
#				!chpass <nick>		- Resets password to nothing, and msg's the user to set a new one
#				!addhost <nick>	[host]	- Adds user's current host to the bot (must have same nick)
#10/21/2001 - 1.1	Redesigned to work completely within netset.tcl (NetBots.TCL is a must.. get it!)
#11/16/2001 - 1.12	Added the following:
#				Added a 5 strike ban warning system (allows up to 5 warnings b4 perm banning)
#				Auto-banning of IRC Flooders (allows 2 warnings b4 perm ban)
#				Refined the autoban criteria (you can edit this urself, but now the defaults are better)
#				Color (green) script logging (so you can pick it out faster)
#				2 timed channel messages (fully customizable)
#				Added support for ACTION script ad checking (/me checking)
#11/21/2001 - 1.13	Added	!override		- Allows you to reverse an auto permban
#				All auto permbans are now announced in a channel of ur choice (allowing for an override)
#				Added an advertising timer, meant for advertising in channels NOT occupied by other groups
#				Added auto-banning of join/parts to avoid flooding and SPAM (2 min ban)
#11/24/2001 - 1.14      Added the following:
#                               Fixed a MAJOR bug - Moved ccasbase.tcl load statement (prevented script from running)
#                               Fixed a delayed banning issue (the mask was put as *!*@, not as the actual mask)
#                               Added !ccasfeatures trigger (just in case you want to flaunt your new script) ;)
#                               Added !ccashelp trigger - Lists currently supported triggers (for +o only)
#12/10/2001 - 1.15      Added the following:
#                               Added support for non op onjoin checking bot (it will msg other bots to ban)
#12/19/2001 - 2.0       Added the Following:
#                               Added non-op support for onjoin virus sends
#                               Added MUCH better support for !unban trigger
#                               Added a GLOBAL switch for !unban trigger (ie: !unban *!*@*blah.com global)
#                               Changed the auto-permban to use a global ban instead of a channel ban

