<?php
//////////////////////////////////////////////////////////////////////////
//    ___   __  __ ___   ____   __  __ ____  ______ ____ __  __   ____	//
//   / _ \ / /_/ // _ \ / _  \ / / / // _  \/_  __// __//  \/  \ / __/	//
//  / .__// __  // .__// /_/ // /_/ // /_/ / / /  / _/ / //_// // _/	//
// /_/   /_/ /_//_/    \_  _/ \____/ \____/ /_/  /___//_/   /_//___/	//
//                       \_\						//
//									//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//									//
//	PHPQuoteMe v1.0.0 by Adunaphel 					//
//	email: Adunaphel@windows2000voorchristus.nl			//
//									//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//									//
//	This is a PHP script which generates a webpage			//
//	containing the quotes stored in a channel with 			//
//	the QuoteMe TCL script.						//
//	Feel free to edit this code as you want,			//
//	but please give me credit					//
//	by naming me among the authors.					//
//	This script took me some time to write,				//
//	but it was written in my spare time,				//
//	and i am no professional, so it may not be completely bugfree.	//
//	If you have troubles with the script, you can email me		//
//	at Adunaphel@windows200voorchristus.nl				//
//									//
//	MAKE SURE TO STATE YOUR COMPLAINT				//
//	AND IN CASE OF ERRORS, ATTACH THE SCRIPT AS YOU EDITED IT	//
//	ELSE I CANNOT HELP YOU						//
//									//
//	Feel free to post this script on your site as a download,	//
//	as long as the script is in place				//
//	(meaning there are more TCL scripts available on the site)	//
//	and you list me as the Author.					//
//									//
//	I HAVE ABSOLUTELY NO CONNECTION OR WHATSOEVER TO		//
//	THE AUTHORS OF THE QUOTEME TCL SCRIPT				//
//	I AM MERELY A PERSON WHO WANTED TO LIST THE QUOTES		//
//	FROM HIS CHAN ON THE SITE OF THAT CHAN				//
//									//
//	I AM NO PROFESSIONAL PROGRAMMER (YET)				//
//	SO I AM NOT LIABLE FOR ANY DAMAGE TO _ANYTHING_			//
//	WHILE USING THIS SCRIPT						//
//									//
//	If you want to use this script,					//
//	some knowledge of PHP can come in handy, but is not needed	//
//	to use this script, you need a webserver that supports PHP,	//
//	with the QuoteMe quotes file present on the system.		//
//	Windrop is also supported in this script.			//
//									//
//////////////////////////////////////////////////////////////////////////

//edit these lines to customize the colors and the background-image

$background = " ";
$bgcolor = "#FFFFFF";
$textcolor = "#000000";
$linkcolor = "#FF0000";
$alinkcolor = "#AA0000";
$vlinkcolor = "#DD0000";

//	set the path to the file containing the quotes, ending with a /
//	e.g. /home/eggdrop/eggdrop/
//	windows users, use double backslashes in the path, else it will NOT work
//	e.g. d:\\eggdrop\\

$path = "";

//	enter the quoteme output file here that is used in the script
//	e.g. .quoteme#quotes

$file = $path . "";

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//									//
//	the beginning of the code, no editing needed beyond this point	//
//									//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////





$fid = fopen ($file, "rb");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Quotes</title>
<?php
// if there is an external stylesheet, uncomment the following line
// echo("<link href=\"style.css\" type=\"Text/CSS\" rel=\"stylesheet\">\n");
?>
</head>
<?php
echo("<body background=\"" . $background . "\" bgcolor=\"" . $bgcolor . "\" text=\"" . $textcolor . "\" link=\"" . $linkcolor . "\" alink=\"" . $alinkcolor . "\" vlink=\"" . $vlinkcolor . "\">");
?>
<center>
<?php
// if there is a header image present, uncomment the following linw
// echo("<img src=\"images/quote.jpg\" width=\"191\" height=\"55\" alt=\"\">\n");

// else uncomment the following line
// echo("<h1>Quotes</h1>\n");
?>
<table width="600" cellpadding="0" cellspacing="0" border="0">
<tr>
<td>
<dl compact>
<?php
/*
	initiatie the counter, used to chop the output into
	useable pieces
*/
$count = 0;
if (!$start)
{
	/*
		if $start is not in the link, it means it should start at 0
	*/
	$start = 0;
}
/*
	as there are 20 quotes per page, $end should be 21 higher than $start
*/
$end = $start+21;
while (!feof($fid))
{
        $buffer = fgets($fid, 4096);
	if ($buffer != "")
	{
		/*
			these two line get rid of the irritating accolades ( { } )
			that QuoteMe puts in the file
		*/
		$buffer = str_replace("{", "", "$buffer");
		$buffer = str_replace("}", "", "$buffer");
		/*
			only when $count lies between $start and $end, output will be generated
		*/
		if (($start < $count) && ($count < $end))
		{
			echo ("<dt>" . $count . "</dt><dd>" . htmlspecialchars($buffer, ENT_QUOTES) . "</dd>\n");
		}
		$count++;
	}
}
echo("</dl>\n<br>\n<br>\n<p align=\"center\">\n");
/*
	if $count is higher than 21, it means there are more than 20 quotes in the file,
	meaning the output is chopped to pieces.
	the links used to view all the pieces are created here
*/
if ($count > 21)
{
	/*
		if $start is equal to 20, it means that there is 1 page before this one,
		that starts at 0, so $start is not needed in the link
	*/
	if ($start == 20)
	{ 
		echo("\n<a href=\"" . $PHP_SELF . "\">&lt;&lt; previous 20</a>.");
	}
	/*
		if $start is not equal to zero, and it is not equal to 20,
		which means there are more than one page before this one,
		which should start 20 entries befor the current page.
	*/
	elseif ($start != 0)
	{
		$countstart = $start-20;
		echo("\n<a href=\"" . $PHP_SELF . "?start=" . $countstart . "\">&lt;&lt; previous 20</a>.");
	}
	/*
		if both statements are not true,
		it means this is the first page, which means there is no
		previous page
	*/
	else
	{
		echo("&lt;&lt; previous 20.");
	}
	/*
		$total is initiated, which stands for the number of pages
		that are available
	*/
	$total = ceil(($count-1)/20);
	/*
		create the direct links to the pages
	*/
	for ($i = 1; $i <= $total; $i++)
	{
		/*
			$begin is the value that $start will have in the link
		*/
		$begin = ($i-1)*20;
		/*
			if $begin is equal to the curren value of $start,
			it is the link tot the current page, whis will not be
			printed as a link
		*/
		if ($begin == $start)
		{
			echo(".[" . $i . "].");
		}
		/*
			if $begin is zero, it means this is the link to the first page,
			where $start needs no value in the link
		*/
		elseif ($begin == 0)
		{
			echo(".<a\nhref=\"" . $PHP_SELF . "\">[" . $i . "]</a>.");
		}
		/*
			if both statements are untrue, just print the link with $begin
			as value for $start
		*/
		else
		{
			echo(".<a\nhref=\"" . $PHP_SELF . "?start=" . $begin . "\">[" . $i . "]</a>.");
		}
	}
	/*
		if $end is smaller than $count, this is not the last page,
		meaning there is a page beyond this one
	*/
	if ($end < $count)
	{
		$countstart = $start+20;
		echo(".<a\nhref=\"" . $PHP_SELF . "?start=" . $countstart . "\">next 20 &gt;&gt;</a>\n");
	}
	/*
		if that is untrue, this is the last page,
		meaning there are no pages beyond thsi one,
		so no link should be printed
	*/
	else
	{
		echo(".next 20 &gt;&gt;\n");
	}
}
?>
</p>
</td>
</tr>
</table>
<br>
</center>
</body>
</html>
