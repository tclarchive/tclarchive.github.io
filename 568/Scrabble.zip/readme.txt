## Scrabble Script for Eggdrops - by Ozh
## Another Useless but Funny Script :P

## USAGE 

This ultra useful script will do the following :
  <You> !scrabble hello
  <Eggdrop> hello is worth 8 points :)


## INSTALLATION

As usual : upload it in your eggdrop/scripts directory,
add "source scripts/scrabble.tcl" to your eggdrop .conf
file, and .rehash


## COPYRIGHT

Of course this professionnal script is fully copyrighted !
Ozh, ozh@planetquake.com, and probably !scrabbling
in #sarl on irc.quakenet.org
(c) Ozh 2002 ! :)
