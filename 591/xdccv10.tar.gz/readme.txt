XDCC Server for Eggdrops v1.0
Code : RaPhiuS / PaRaSiTe
email: henrraph@skynet.be
-----------------------------

Introduction :

 Well, you have in front of you a fully working XDCC server written in tcl and intended to be used with eggdrops 1.6.x+ series. The purpose for writting this
 script was to give eggdrops a fully xdcc platform with easy package management, easy channel management, queues system & also an easy way to configure it ! 
 (you just have to edit 4 settings in xdcc.tcl). This script has also some additionnal features that you'll see when you'll use it ;) It has been tested with
 eggdrops 1.6.8 & 1.6.10 but will normally work with all the 1.6.x suite and may also work with others minor version. Also, most of the tests i did with this
 script were done under linux and i know some troubles may appear under windows when for example you try to add a package which path contains blanks... You
 know how to solve it ? Then that's great because i didn't looked at it :) Well i hope this script will fill your needs =) Enjoy !

Installation :

 NOTE : The script will not work if your eggdrop haven't the transfer module loaded ! In your bot's .conf file ensure you have the following line set :
        --> loadmodule transfer <--
	
 If you don't know how to add this script to the bot i STRONGLY advise you to refer to the eggdrops docs ! Anyway if you too lazy then just do the following:
 
   - edit your xdcc.tcl file and set the settings you want for the server (these are the four settings just at the beginning of the file)
   - save xdcc.tcl 
   - edit your .conf bot file
   - at the end add this : source scripts/xdcc.tcl
   - save the file
   - restart or rehash the bot and the script will be loaded :)
   
 To get started with the script just type in partyline with the eggdrop : .xhelp and you'll get all the things you need to setup correctly the server :)
 (.xhelp command will only work if you are a master of the bot !!)
 
History :  03/05/2002
           v0.2 : - Note that package & channels  commands will only work in dcc chat and only for masters
	          - Added the xhelp command. This command just show the help in the partyline
                  - Added the xinfos command. Just some infos about the best warez channel ;)
                  - Added the xlistpacks command. If the pack don't exist it will return an error. This command just read xpacketsfile & xcpackfile.
                  - Added the xaddpack command. This command have to be called with the right parameters which are <file> & <description>
                    and the <file> parameter must be the full patch to an existing file otherwise the command will return an error. This
                    command update xpacketsfile & xcpackfile.
           04/05/2002
           v0.4 : - Added the xdelpack command. This command certainly not behave in the best way to update the xpacketsfile & xcpackfile... Anyway
                    it works fine and do it's job ! Also this command need to be called with the right parameter otherwise it will return an error. The
                    command also ensure the pack specified in the parameter exists otherwise it will tell that the package simply don't exists.
                  - Added the xlistchans command. If the pack don't exist it will return an error. This command just read xchannelfile.
                  - Added the xaddchan command. This command have to be called with the right parameter and also the # char have to be supplied. It creates
                    the xchannelfile if it don't exists and update the xchannelfile in the other case. It also ensure that the specified channel at parameter
                    is not already inserted in xchannefile otherwise the channel will not be added.
                  - Added the xdelchan command. Like xdelpack command, xdelchan certainly not behave in the best way to update the xchannelfile but it works
                    so hehe ;) It have to be called with the right parameter. xdelchan also ensure that the channel specified at parameter exists in the list
                    and that the XDCC server have channels set otherwise it will return an error.
           05/04/2002
           v0.5 : - Begin to wrote the xctcpmonitor thing to react on ctcp command. Every CTCP request with keyword XDCC will produce this server to react
                    to this request by executing the arg command specified. If arg is unknown to the xctcpmonitor nothing will happen. If no arg is specified
                    the help will be displayed. xctcpmonitor reacts to these specified args : list, info, help & send #<packnumber>. xctcpmonitor also
                    ensure a <packnumber> is specified otherwise will warn the requester. All CTCP requests with keyword XDCC are logged.
                  - Started to write the queue system of the server. pushqueue { nick packnumber } has been written. It simply insert a new queue in the
                    file xqueuefile and ensure that nick has not more than maxuserqueue queues. It also ensure the package specified exists and that the
                    queue is not full otherwise pushqueue will warn the user.
                  - Wrote the showxdcc command which is used to display the server contents on channel(s) specified in xchannelfile. Also started to work
                    with timers but didn't find a way to get it work fine.. Will work more on that ! ;)
           06/04/2002
           v0.6 : - Finally understood how timers work ! Thanks to Spod (#landtag), MC_8 & stdarg (#eggdrop) which explained me some usefull things ;) Now
                    timers work for showxdcc & processqueue. Of course those timers will go on only if the server is open ;) All the channels specified in
                    xchannelfile are showxdcc'ed
                  - Added support for lost transfers & time out ! The XDCC server will warn the user and log the error.
                  - Added xdccsend command which take care of errors that could happen (errors are logged)
                  - Added xupdate command. When a user finished successfully the transfer this command is called (as dccsend command call a sent bind when
                    the transfer is finished) and will update xcpackfile et xcbytefile. The finished transfer is also logged.
           07/04/2002
           v0.7 : - Added the common !list command. If the server is running and a joining user want to know quickly which are the servers, this command
                    will send him the XDCC server infos. I also added a !xdcc command which produce the same result as !list.
                  - Did some changes on showxdcc command to decrease the number of lines sent when advertising ;) (hope my friend Live43D will be happy =))
                    If you serve 486 packs don't cry if you get flooded (hehe ;) ). Thanks to Live43D (#landtag)
                  - Added xformatsize proc which convert a size fully given in bytes in a string more "lookable". Updated all the script parts that deal
                    with file size.
           08/04/2002
           v0.8 : - Added xstatus command which is only intended to show in party line the XDCC server status
                  - Fixed the bug on how many times a pack have been downloaded
                  - Fixed a bug discovered in xformatsize (now works great ;))
           12/04/2002
           v0.9 : - Fixed a small bug for the /ctcp botnick XDCC info command... It was an error when displaying the bot version which didn't take care about
                    the two sub-release numbers. Now the two sub-release and also the two minor release numbers have been added to ensure this command will
                    not display an erroneous bot version. Thanx to Zium ;) (#divxfr) 
                  - Added xrehash command which restart the server after a rehash. It reloads the queued files if they exists and also relaunch the timers
                    in all the channel specified in xchannelfile (processqueue is the last process to be launched). Of course if no channel are set no timers
                    will be set. Thanx to Zium for his suggestion ;) (#divxfr)
                  - Fixed a small thing in xdelchan command. If the channel removed is the last from the list then xchannelfile will be deleted and server
                    will be automatically closed.
                  - Fixed a small thing in xdelpack command. If the package removed is the last from the list then xpacketfile & xcpackfile will be deleted
                    and server will be closed.
                  - Added a correction to xstart command. Now it needs to have xchannelfile & xpacketsfile otherwise it will not run the server.It's nonsense
                    to run a server without serving anything and/or serving in no channels.
           14/04/2002
           v1.0 : - Did some changes on the variable xdcctime which is now considered as an internal, not to modify, variable. The way i did the multi
                    channels showxdcc is really certainly NOT the best way but i think it will work great with something like 5 channels setup... It may also
                    work with more channels but haven't tested that yet... If you have suggestions please email me...
                  - I set the time display between each channel of the list to 3 mins... This annoy me in the way that the first channel of the list will be
                    showxdcc'ed more times than for example the last channel of the list... But my motivation to change this setting was to try to not flood
                    the bot when the number of channels becomes huge ! ;) Anyway the script is now ready for a public release =)

Greetings : 

 I would like to thanks Spod, MC_8 & stdarg for the help they gave me with my stupid questions ;) I would also like to thanks Zium for testing the script !
 Greetings to all my friends on : #landtag, #warezaka, #warezbelge, #divxfr, #warez-palace & #warezmania on Undernet ! (If you have suggestions for the script
 you'll find me there ;)). Also greetings to all scripter's out there growing the eggdrops possibilities with so many usefull thingies =)
 
NO CARRIER. PaRaSiTe -