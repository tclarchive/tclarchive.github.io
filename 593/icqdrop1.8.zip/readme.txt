Please note this version (1.6 - 1.8) of ICQ-Drop was edited by GeC (gec@raw.scene.org) from IRCnet #give

Please note this version (1.5) of ICQ-Drop was edited by simple (simple@utw.com) from Undernet #tcl

Please note this version of ICQ Drop was edited by Xanith (xanith@startrekmail.com) (Server irc.millenia.org)

But all credits go to ^DaRk^ on EFnet (Darkbringer@Rocketmail.com) 
                   
How to get this damn script to work (Made for eggdrop1.3.*):

1.) Load it in your TCLs.
2.) Make sure to load userinfo.tcl with a XTRA ICQ field also. (other userinfo's with XTRA field ICQ will also do)
3.) I suggest you use '.icq <your icq #>' in order for this to work with your nick or '.chicq <user> <users icq #>. 
4.) To send an ICQ message from dcc chat, type '.icqsend <user> <message>' To send an ICQ message via /msg, type '/msg <botname> !icqsend <user> <message>' To send an ICQ message via public channel chat (for fun?), type '!icqsend <user> <message>. Where <user> is a in the bot registered nick or an ICQ number.

What GeC changed:
This readme file %)
More (secure) feedback
Rights (op-only, validusers, for security reasons)
More information for the receiver

What simple changed:
I also changed what Xanith changed, a better Gui and stuff for the ICQ message reciever. Also i updated just about all the code that ^DaRk^ wrote (he was new to tcl at the time, and he admits it was sloppy). No bugfixes we done (amazing work ^DaRk^!), just much simplification.

What Xanith changed:

On the receiving end of the script (what the user receives in icq) is all that I changed. So that you can see what user sent the message and what bot it came from.

Also it said that .icqsend would work but it was bind'd as .icqmsg I changed it to .icqsend.

Future Plans Anyone? 

I would like to -eventually- create an actual account on ICQ that the bot could actually connect to just like a client. All we would need is source. So, you amiga users that benefit from StrICQ, send me some code for that so i can adapt it to TCL. Email addy is simple@utw.com
let me know....

Enjoy, 
-simple
