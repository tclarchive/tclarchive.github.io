####################
## PM-users v1.00 ##
####################

Author: Papillon <papillon@surferstarten.net>

Copyright � 2002 Papillon aka Hallvard Rykkje

A very small script. It searches through the chanlist and sends a priv msg 
to all of the users in the userlist which are on that chan.

Commands: !pm #chan <msg>  - in priv msg to the bot
          .pm #chan <msg>  - in dcc chat

To install just add thisline at the bottom of the bots's config-file:
source scripts/pm-users.tcl

If u have ideas of how to improve this script ... or you just need to get in 
touch with me .. the e-mail addy is: papillon@surferstarten.net

Have fun ;)