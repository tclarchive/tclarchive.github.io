channel guardian 1.1 by hd2000 <winstonlim@visto.com>

type .help to list the help

a channel helper hope u like it 
