#!/usr/bin/perl
use MP3::Info;

print "MP3List.tcl Suport File v1.00 by David Proper (DrN)\n";
print "Copyright 2002 Radical Computer Systems - All Rights Reserved\n";
print "\n";

$totfiles = 0;
$totdirs = 0;

open (DATA, ">mp3list.dat");
open (DATA2, ">mp3list.txt");
open (DATA3, ">mp3playlist.txt");

&addfile(DATA2,"mp3list.hed");

########################################################################
#
# Add all your directories to add to the list here:
#
&procdir("/home/all/mp3");
&procdir("/tt/dj");


########################################################################
&addfile(DATA2,"mp3list.fot");

close (DATA);
close (DATA2);
close (DATA3);
print "Total of $totfiles files in $totdirs directories.\n";

sub addfile {
 local($data,$fn) = @_;
 print "Opening $fn\n";
 open (ADDIT, "$fn"); @addit = <ADDIT>; close(ADDIT);
  foreach $line(@addit) {
   chomp $line;
   print $data "$line\n";
                        }
             }

sub procdir {
 local($dir) = @_;
 local(@files,$file);
++$totdirs;

print "Reading $dir\n";
opendir(DIR,"$dir/.") || die("\nCould not open $dir");
@files = sort(grep(!/^\.\.?$/, readdir(DIR)));
closedir(DIR);

foreach $file(@files) {
# print "Checking $file \n";
# if(-f "$dir/$file") {print "$dir/$file is a file.\n";}
 if(-d "$dir/$file") {&procdir("$dir/$file")}
 if(-f "$dir/$file") {
   $num = length($file);
   while ((substr($file,$num,1) ne ".") && ($num > 0)) { $num = $num -1;}
   $ext = substr($file,$num,length($file)); if ($num eq 0 ) {$ext = "";}
   $ext =~tr/[a-z]/[A-Z]/;
   if (($ext eq ".MP3") || ($ext eq ".mp3")) {
#       print "Proccessing $file\n";
 my $info = get_mp3tag("$dir/$file");
 print DATA "$dir|$file|$info->{TITLE}|$info->{ARTIST}|$info->{ALBUM}|$info->{YEAR}|$info->{COMMENT}|$info->{GENRE}\n";
#TITLE, ARTIST, ALBUM, YEAR, COMMENT, GENRE
++$totfiles;
 if ($title eq "") {$title = "Unknown";}
 print DATA2 "#" . padright("$totfiles"," ","5") . ": $file\n";
 print DATA3 "${dir}/${file}\n";
      }
 }
}
}

sub padright { # padright("the string ","_","55")
(my $text, my $pad, my $count) = @_;
#($text,$pad,$count) = split(/|/, $params,3);
#print " params = $params \n text = $text \n pad = $pad \n count = $count\n";

$line = "";
$_loop = length($text);
while ($_loop < $count) {$_loop = $_loop + 1; $line = "${line}${pad}";}

#return "${text}" . substr($line,0,$count - length(line));
return "${text}$line";
}

