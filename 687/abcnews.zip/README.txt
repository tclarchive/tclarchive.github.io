Please take some time to set the options in abcnews.tcl,
load it like you would load a normal script ("source scripts/abcnews.tcl" in eggdrop.conf).

Dont steal code, i will catch you ;)


ThEdGE (thedge@xs4all.nl)