###################################################
##                                               ##
##              War Management                   ##
##                        by kalhimeo            ##
##                                               ##
##  http://sourceforge.net/projects/war-manager/ ##
##                                               ##
###################################################

#############################################
##                1.General                ##
#############################################


This script is written for the famous irc bot eggdrop (http://www.eggdrops.com).
It is released under GNU/GPL Licence (details on http://www.opensource.org/licenses/gpl-license.html).

I tested it with eggdrop and a windrop ( both in 1.6.x ).

If you found a bug, you can message me at kalhimeo@users.sourceforge.net or visit #pwf on Quakenet.
( Please do not email if you have initialisation problem with you eggdrop, ONLY FOR BUGS REPORT ).

For users who used previous version of War Manager, unfortunatly spacedude's mirc plugin don't work anymore with 1.7 :/ If you write something similar for this new version, send it to me and i will release it in next version.
I'm also looking for beautifuller templates to distribute with this script ( with reference the creator's nick for sure ) and for shells account.
Anyway, don't hesitate to visit me on #pwf Quakenet if you think you can help me.
Thx and enjoy ;) .
 

#############################################
##             2.Installation              ##
#############################################


Warning: some terms used here may be specific to utilisation of eggdrop. If you don't know eggdrops yet, plz read some doc about these first.

As i said, this script require a configured eggdrop monitoring a minimum of 2 chans ( your private clan channel + public clan channel ).
You first have to put the scripts files into the "scripts" directory of your eggdrop ( warmanager.tcl and the sendftp.tcl corresponding to your OS version ).
Then, you have to add these lines to load the scripts at the end of your config file :
source scripts/warmanager.tcl
source scripts/sendftp.tcl ( or source scripts/sendftpwin.tcl if you are using a windows OS )
You also have to copy .template files in the egg root directory.
The second step is the configuration of the script itself, open warmanager.tcl with your favorite text editor and fill the settings like this ( keep the " " when these are present ) :

- war_pubchan : your clan public chan.

- war_privchan : your clan private channel.

- war_keys($war_privchan) : the key of your private channel if needed, leave it to "" to disable.

- war_clanname : the name of the clan ( will be used in every output of the script ).

- war_authsys : Set to 1 to enable the auth system ( only user with flag +W can auth themselves and add wars in the database, every member can still use !add, etc ). ( 0 to disable )

- war_timeoutdelay : the dealay in minutes after which the bot automaicly remove the authentication of admins.

- war_playernumber : the default number of players required for a war ( can be specified individually when adding a war via IRC but this is the one used if not specified in command line ).

- war_subnumber : the number of substitute player who can add themselves for a war.

- war_shownumber : the default number of war that are shown in !pending, !upcoming, !id if no number <x> are entered.

- war_nicksize : Determine wich player alias (long/short) will the bot use in table result ( like !search ). ( 1=short alias , 2=long alias , 3=handle )

- war_agenda : set how many matches to show ( maximum ) when a player use !agenda

- war_hideplayer : Hide the player line up for upcoming match on public chan (if not, choose wich alias will be used). ( 0=hidden , 1=short alias , 2=long alias , 3=handle )

- war_privmsging : You can enable this feature that allow the bot to message evey player for the war in the next 15 minutes ( only works when the hour is equal to the hour of the war minus 15 min )

- war_searchall : if set to 1, the bot will search in every war informations when a player use !search ( ie. in map name or infos ). Set to 0 will make the bot search in clan name only

- war_topiclength : Number of character allowed in the topic by the server ( leave this setting for quakenet )

- war_trigger : Trigger for all commands, you should change it only if you have a conflict with an other script ( ie : if you are using an other script that use the same commands )

- war_html : Set to 1 to enable the html stats generator ( 0 to disable ).

- war_htmldelay : the delay between two updates of the war stats html page.

- war_template : the file name of the template file. ( available with this package : sample.template and default.template )

- war_webname : the name of the file on this ftp server.

- war_upload : enable or disable the upload of the html file on a ftp server ( you may want to disable this feature if bot is on the same computer as webserver ).

- war_uploadbackup : enable or disable the upload of the war database backup file ( WarArchives.back ) on the webserver with the FTP settings as the html stat page upload.

- war_webserver : the address of the ftp server where the stats page will be uploader.

- war_weblogin : the login used to log on this ft server.

- war_webpassword : the password used to log on this ftp server.

- war_webfolder : the folder on the ftp server or on the local machine where the file will be uploaded/copied.

- war_bckg1 : is the background color used for the first case ( +2x ) of the first line ( +2x ). That means it can be used as an alternative color with others war_bckg ( you can choose to alternate by rows or lines, bckg 1 and 2 are for the same line and 3 and 4 for the next line, etc )

- war_bckg2 : is the background color used for the second case ( +2x ) of the first line ( +2x ). That means it can be used as an alternative color with others war_bckg ( you can choose to alternate by rows or lines, bckg 1 and 2 are for the same line and 3 and 4 for the next line, etc )

- war_bckg3 : is the background color used for the first case ( +2x ) of the second line ( +2x ). That means it can be used as an alternative color with others war_bckg ( you can choose to alternate by rows or lines, bckg 1 and 2 are for the same line and 3 and 4 for the next line, etc )

- war_bckg4 : is the background color used for the second case ( +2x ) of the second line ( +2x ). That means it can be used as an alternative color with others war_bckg ( you can choose to alternate by rows or lines, bckg 1 and 2 are for the same line and 3 and 4 for the next line, etc )

- war_font : is the font type that will be used in the tables ( war history and map stats )

- war_txts : is the size of the text used in these tables

- war_txtc : is the color of the text used in these tables


You can now .rehash your bot and start adding your clan members in the bot. Refer to eggdrop docs for this part of config.
You don't need to give special flags to your members, you just have to add the +W flag to admins if war_authsys is set to 1.
That's all, you can now enjoy this script :)

NOTE : for user updating from 1.6x version or older, you will have to use .convertdb in telnet with your eggdrop the first time you use 1.7 to convert the old DB in the new format, if you don t do this all old war infos will not be concidered by the bot.


#############################################
##               3.Features                ##
#############################################


- Store upcoming wars into a database, clan members can add themselves to these as full player or substitute.

- The bot announce the next war in the topic and asks for players if there are any missing ( less than specified number ) for a war planned in the next 24h.

- You can add the result of a war played ( this kind of war without scores appears in the pending list ).

- You can also add the score of a match that you played and that was not planned by the bot.

- You can set a MOTD on your clan private chan to make some advertice to your members.

- You can retrieve informations about wars in database on your private or public channels like !search, !last or !next ( commands available depends of the chan where these are used ).

- The bot can generate an html webpage from a template file ( = html file that you can customise and the bot will fill it with war results ) and can upload it on the ftp server of your website.

- Many other Commands for an easyest management of wars for warmanager and also for players ( !agenda, ... )

- Flood protection for commands on the public chan included.


#########################
# Public Chan Commands  #
#########################


!last <x>     =>  Show the last <x> wars of your clan
!next         =>  Show the next war of your clan
!search <key> =>  Search for any entrie matching <key> in the database ( can be a player and/or a team name, depending of war_searchall setting ) 
!help         =>  Show the available commands on the public chan


#########################
# Private Chan Commands #
#########################


!addmatch team(x) date(hh:mm-dd/mm/yy) map(x) ( + infos(x) or/and number(x) if desired )
=> Add a match in the calendar, infos(x) and number(x) are not required ( Players will be able to !add to this math )

!addscore team(x) map(x) yourscore(x) oppscore(x) (+ infos(x), number(x), date(hh:mm-dd/mm/yy) and/or player(x) if desired)
=> Add a played war in database. If date() is omited, current time will be used. You can also use date(dd/mm/yy) without the hour. If players/infos are omited, these are set to "n/a"

!addresult <id> <your-score> <opponent-score>
=> Add a result on a pending match.

!chinfo <id> <new entries>
=> Change stored informations about <id>. Available entries are the usual trigger: team(),date(),hour(),day(),year(),map(),yourscore(),oppscore(),player(),info(),number(). You can change as many entries as you want at once

!delete <id>
=> Delete a war from database.

!motd <msg>
=> Set a welcome message on the private chan. Use !motd 0 to disable.

!add <id>
=> Add youself to the war referenced by <id>

!remove <id>
=> Remove yourself from the war referenced by <id>

!agenda
=> Shows you all the upcoming match you subscribed

!alias short/long <handle> <alias>
=> Add an alias ( short or long ) to this handle

!search <keyword>
=> Search for any entries in database matching <keyword>

!id <x>
=> Shows you the last <x> entries in database and their ID

!pending <x>
=> Shows you the <x> more recent war waiting for a result

!upcoming <x>
=> Shows you the next <x> war in the calendar

!last <x>
=> Shows you the last <x> war(s)

!help
=> Shows the available commands on the private chan

/msg botnick admin <password>
=> Authenticate yourself in the bot ( only used if you enable war_authsys )


#########################
#   DCC CHAT Commands   #
#########################

.alias <short/long> <handle> <alias>  	=>  add an alias for this handle ( will be used in table result and topic, i recommend you to set a short alias for every player )
.convertdb 				=>  convert an old database ( 1.6x or older ) to the new 1.7 format ( use it only once )

#############################################
##               4.Version                 ##
#############################################

########
# 1.7  #
########

- New trigger system, more intuitive and more accurable, you can set individual player number for each war and you don't have to use "_" instead of space anymore. The order of informations don't have importance anymore, you can start adding a war with info(x) or with map(x)
- Internal date system completly modified, no more errors at the end of the month or year in automanagement, 200% more accurate ( wars are saved under unixtime ) and bot can now find the day of the war ( ie. Wednesday... )
- New trigger for player : !agenda will show up upcoming wars the player subscribed too.
- The bot shows the number of player who subscribed and number of player required in the listing commands ( !upcoming, etc ) in the form "(3/5) players"
- New variable customisable by the user for a better personalisation of the script ( war_searchall, war_agenda , war_trigger )
- The !chinfo is now more understable ( old one was so complicated, i agree ;) ) and should be more accessible.
- Bug fixed when using more than 1 substitue
- Many other bug fixes solved due to new DB format

########
# 1.6d #
########

- You can now enable a new feature that allow the bot to message all players who subscribed to a war, 15 min before this war.
- You can change the string "admin" used to authenticate ( conflict with my other script pwf.tcl using the same string ).
- Many little changes to improve code.
- Fixed a little bug when using lower and upper case character in channel name.
- Fixed a bug with map statistics.
- Fixed a bug in the html page with substitute.
- Minor bux fixes.

#######
# 1.5 #
#######

- Added new variables to customise the table output in the html generated file ( i think you are now able to customise it at 100% with the template + these settings ).
- Fixed some bugs with the html generated page.
- Fixed bug when using more than 5 players for a game.
- New template included ( sample.template ) wich is a quite beautifuller than the default one ( but i m sure you can do better, it s only to show how to use the new bgcolor features for tables ).
- The players names are now sorted in alphabetic order and separated by a space into the html page.
- New system to avoid the insertion of errors in the database ( date and score ).
- MOTD can now be disabled with !motd 0

#######
# 1.4 #
#######

- Added more stats in the war stats html page ( map stats + average scores ).
- Added variable to hide player line up for upcoming matches on the public channel.
- Added variable to set the default output of the nick size for players in result table  ( works with the .alias command ).
- Added variable to set number of player required fo a war.
- Added variable to disable the upload of the war stats file ( ex: if the webserver is on the same computer as the egg ).
- Added variable to enabale the upload of the war backup file on webserver.
- Added new switch for chinfo : hour and year.
- Auto backup everyday at 00h00 of the WarArchives file ( WarArchives.bak ) and can upload this file to the webserver if enabled.
- New alias system, and master can now add long or short aliases for players' nicks  ( ex: to reduce the size of the topic ).
- The MOTD and the aliases are now saved into a file ( WarMiscs ).
- Bug fixed with the !next public command.

#######
# 1.3 #
#######

- The template for html building now works you can edit it as you wish ( leave spaces arround the variables starting with % ).
- The output on the channel ( !pending, !upcoming, etc ) are now smarter and the collumn size is now proportional to the length of the data.
- First public Version.

#######
# 1.2 #
#######

- Added the html building support with update on you ftp server.

#######
# 1.1 #
#######

- Added the War Management support, the bot add custom msg into the topic and manage all the war calendar.

#######
# 1.0 #
#######

- The basic features of the bot are now fully functionnal ( !addmatch, !addresult, !add, etc ).


#############################################
##              5.Thanks to                ##
#############################################


I especially wanted to thanks these persons who helped me or make the bot better and better :

- SpaceDude for his mirc script to easyly use the bot without typer commands ( no more included in this package because don't work with 1.7 )

- TiDweL and Omnipotent who helped me during the bot testing and debugging phases.

- All the guys who come on #pwf to support me and report bugs ( laMersSs, redeye, r1ch4rd, dolby, four,... )

#############################################
##                 6.FAQ                   ##
#############################################


- When a player try to !add to a war, bot does nothing
=> You have to add every player in eggdrop userlist first ( with correct ident@host ) to allow the bot to recognise them. Go read eggdrop's doc if you don't know how to do this ( look under .+user )

- The bot doens't uplaod my html stat page, what's the prob ?
=> Check you correctly loaded the sendftp.tcl, according to your OS, in eggdrop config file.

- I lost all my database when i installed WarManager 1.7, WTF ?
=> Don't worry your database is still present if you didn't delete it manually, but due to the new db format of 1.7 you first have to use .convertdb in telnet to convert your old db to the new format ( use it only once )

- My mirc plugin to easy add wars don't work anymore with WarManager 1.7
=> No, it doesn't due to new trigger format :/ I m waiting for an update of such plugin from users of my script, if someone do it, it would be nice to send it here or let's come on #pwf

- Some commands are not working on my privchan, why ?
=> This kind of bug appears when you set the same channel for your private and public chan. If you don't want to use a public chan, just set the setting to a chan that does't exist ( #gszegzsgqgqgh or something like that :p )

- I can't use character like [, ], {, } or " in clan name or informations, why ?
=> These characters are specific to tcl language and makes the bot bugs in automanagement, didn't find a fix to this prob yet that's why i forbid the use of this chars

- I updated some infos of a war with !chinfo but the topic isn't updated.
=> This is due to a known bug but can't be fixed without creating a bigger one, there is an easy way to fix it: just delete the topic. The bot will update it immediatly


PLEASE DON'T MAIL ME ABOUT EGGDROPS PROBLEMS, I ONLY GIVE SUPPORT ABOUT SCRIPT PROBLEMS

That doesn't mean you can't ask me questions if you have a problem, come on the channel, if i'm present i will help you.














