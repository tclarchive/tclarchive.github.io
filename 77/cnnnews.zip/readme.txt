CNN News.tcl by Thrill  - README

This small script will turn your bot into a full fledged 'news headline' parser. It will fetch headlines from cnn.com
and pastes them on command into the irc-channel. For this it needs Lynx (v2.8+ tested ; maybe earlier versions will
work too) and an Eggdrop Bot (v1.6.1 tested). 
v1.1 : Now includes URL's after the headlines.

What it does? 

The script gets a headline page from www.cnn.com and parses this to the channel, based on the user's selection
of which headlines he/she would like to read.
This could be one of the following:
Top Stories, World News, US News, Politics News, Weather News, Business News
Technology News, Space News, Health News, Entertainment News, Sports News, Travel News

Usage:

After installing the script in eggdrop.conf and configuring it (read the script for that) you can use the command 
'!news <item>' to view certain headlines. For a full list of which <item>'s you can choose, enter '!news help'.

For example: !news top - gives the Top Stories Headlines


Disclaimer:

The author takes no responsibility whatsoever for the usage of this script. You may change and copy the script
to your own liking, but give credit where credit is due (ie do not remove my name/email ). The author takes
no responsibility whatsoever for the changes you make to this script. If it doesnt work or other problems arise,
you are on your own.
The script uses headlines from CNN.com. All headlines it parses are (c) CNN.com. 

Where can the author be reached: jmildham59@hotmail.com
                                 (read the doc/script before you mail me please)
