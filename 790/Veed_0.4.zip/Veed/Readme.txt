####     #### ######## ######## ######## 
 ####   ####  ##       ##       ##     ##
  ###   ###   ######   ######   ##     ##
   ### ###    ##       ##       ##     ##
    #####     ######## ######## ########  v0.4
############################################# 

##### What are Veed scripts?
Veed scripts are some scripts with multichannel support,based on an idea from Ze's UndernetCS script. These scripts make each channel owner configure the scripts for his needs. He may activate/deactivate the script, and change other settings like ban messages etc. for his own channel, so the global masters and bot owner dont need to change anything, and the best of all: Everything is configured from the partyline.

##### History 
06.01.02 Happy new year! Version 0.4 out, added a new script, read about Vaway below.

22.12.01 Version 0.3 out, added a new script, read about Vadvertise below.
         also fixed some bugs in the 2 earlier scripts, and got a new inidb.tcl
         The inidb version 0.4.2 had a bug which made the bot crash if loading a lot of data.
         Thanks to Ze for making inidb.tcl v0.4.3

12.12.01 This is the first official release of this script... version 0.2

Naveed my_naveed@hotmail.com

^Naveed^ @ #Des-Pardes @ Undernet

##### Which scripts are included?
Currently these scripts are included:

��� Vdeop - which was made since I have some operators who love to op their friends too, and this script work as a strictop script, read the top of Vdeop.tcl for more info. Everything shall be configured from the partyline. .Vdeop

��� Vbadwords - made to avoid bad words in the channel, read more at the top of the     Vbadwords.tcl. Set the badwords in the Vbadword file, rest from partyline. .Vbad

��� Vadvertise - made to avoid users inviting to other channels. Read more at the top of the
    Vadvertise.tcl   Everything shall be configured from the partyline. .Vadv

��� Vaway - made to avoid opers sitting with op in channel while they are away. There is no need for a user to be op 
    while he cant take care of the channel, it only give us a lots of users with op.
    Read more at the top of the Vaway.tcl. Some settings in the file, else configuration from the partyline. .Vaway

##### Installation. 
Set all files in the same directory.
Set the directory in the Veed.tcl file, and all configuration is done, rest in partyline. Typing .Veed in the dcc partyline may give you a good start.

##### Upgrade
Replace all .tcl with the new ones, keep the .conf files with your settings.
Set the directory in the Veed.tcl file, and all configuration is done, rest in partyline. Typing .Veed in the dcc partyline may give you a good start.


##### Comments.
This script had been tested on eggdrop 1.6.6 I havent tested on others, but it should work fine, but not my responsibility if you mess it up :)
I recommend to set the bot running these scripts as a +f (friend) 
and add the other bots as +f too, to avoid mass flood,and fight between them.
Global masters are able to change the settings along with the channel owner.
By default bots and global users arent punished for doing anything, and this cannot be changed without changing the code. Dont change!!!

#Found bugs?

Send comments and bugs found to my_naveed@hotmail.com

##### Other things to come?
I'm working on some other scripts too, they will be added in the later versions.
Any requests or ideas of scripts which could be good to have a multi channel support for? drop me a mail.

Enjoy!!!
Naveed

