Eggdrop tcl scripts allvoice.tcl, allhop.tcl, allop.tcl ( works for windrop also )
========================================================
               install the tcl scripts
========================================================
its kinda easy all u have to do is save this scripts in ur main eggdrop or windrop script 
C:\Windrop\scripts  or  C:\eggdrop\scripts or where ever u installed them :P
after saving the scripting into ur scripts folder Oper eggdrop.conf in the main folder
the near the end of the conf there will be a section called 
##### SCRIPTS #####
or somethink like that after u found the section add 
source scripts/allvoice.tcl
source scripts/allhop.tcl
source scripts/allop.tcl

one of them then rehash or load up then u all ready to go

=====================================================
                     Author
=====================================================
Author: Chaos
Author E-mail: Chaos@utchat.com
irc: irc.utchat.com
Channel: #Eggdrop #utgames
