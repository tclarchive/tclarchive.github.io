unknown script v0.1
by Ronnie Soak

1. Content
2. Description
3. Instalation
4. Usage
5. Known Bug
6. History
7. Contact

1. Content

-> quickop (A _REAL_ fast opping script)

-> revenge ( Some nice revenge script)

-> nmass (new netmass (it hasn't to do something with the 
   mass.tcl from slennox, I wrote this for my self :))

-> slowjoin (Script to let a botnet join a channel delayed 
   to avoid join flood)

-> ebitch (superbitch script, got from Raiden, adapted to my 
   package by myself)

2. Description

This script collection all uses a small script called queue.tcl.
Like the name says it queues commands, and if there are too many
request at a time it handles it another bot on the botnet. This
is the initial release so not all things are working, but much
is doing very well :)

3. Instalatoin

first unload all other oping/revenge/mass/bitch scripts from 
your bots, this meands, you can use unload.tcl or remove the 
line in the config and restart the bot, if you only rehash, 
you'll get probably error messages from your bot complaining 
about missing functions.

After this, add the following lines to your netset.tcl:

# Ronnie Soaks Scripts
set nb_component(quickop) 1
set nb_component(nmass) 1
set nb_component(queue) 1
set nb_component(slowjoin) 1
set nb_component(revenge) 1
set rs_debug(qo) 0                # Set this to 1 if you want debug msgs for quickop
set rs_debug(nm) 0                # Set this to 1 if you want debug msgs for nmass
set rs_debug(q) 0                 # Set this to 1 if you want debug msgs for queue
set rs_debug(sj) 0                # Set this to 1 if you want debug msgs for slowjoin
set rs_debug(rv) 0                # Set this to 1 if you want debug msgs for revenge

save it, .netupdate -file netbots/netset.tcl, .nethash
that should do it, now you can use unknown script.

4.Usage

New Commands:

.nmass (+/-[o|h|v|(or whatever userchanmode)])/kick #channel

some examples:

.nmass +o #shitchan         ops all people in #shitchan
.nmass kick #lamercentral   kicks all people in #lamercentral
.nmass -v #voicedchan

.netdjoin delaytime #channel

let the botnet join between now and delaytime, for example if
delaytime is 60, some bots will join in 30s other in 21s and so
on, but in 60s all bots should have joined the channel.

New Userflags:

+E   masskick extemp
+T   revenge extemp
+P   revengeable person

New Channelflags:

+superbitch
switches superbitch on, that means, someone ops and is not a bot
he gehts kicked and the oped one get deoped.


5. Known Bugs

-> need-unban/limit/key doesn't work yet

-> masskick doesn't work somehow (only kicks some people of the chan,
   not all)

-> afaik the rest should work good, if you find bugs, please inform me

6. History/Changelog

0.1 Initial Release

7. Contact

You can contact me on QuakeNet in #weltfrieden, my nick is soaK.
Also you can send me an e-mail to puffowner@hanfplantage.org for
any hints, bugs or other else :)