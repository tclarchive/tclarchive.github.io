#define KEY 0x0000DEAD
#include <stdio.h>
#include <sys/shm.h>
#include <sys/param.h>

struct ONLINE{
  char tagline[64];
  char username[24];
  char status[256];
  char host[256];
  char currentdir[256];
  long groupid;
  time_t login_time;
  struct timeval tstart;   
  unsigned long bytes_xfer; 
  pid_t procid;
};

static struct ONLINE *online;
static int num_users = 0;
static int shmid;
static struct shmid_ds ipcbuf;
				 
static int checkusers(void){
  register int i, j, found = 0;
  for (i=0; i<num_users; i++){
      if (online[i].procid == 0)
        continue;
      fprintf( stdout, "@%d@%s@%s\n", online[i].procid, online[i].username, online[i].host);
      found++;
    }
  return (found);
}

int main( int argc, char **argv ){
  int numusers;
  fprintf( stdout, "@\n");
  if ((shmid = shmget( (key_t)KEY, 0, 0)) == -1){
    exit(1);
  }
  if ((online = (struct ONLINE *)shmat( shmid, NULL, SHM_RDONLY)) == (struct ONLINE *)-1){
    exit(1);
  }
  shmctl( shmid, IPC_STAT, &ipcbuf);
  num_users = ipcbuf.shm_segsz / sizeof( struct ONLINE );
  numusers = checkusers();
  shmctl( shmid, IPC_STAT, &ipcbuf);
  if (ipcbuf.shm_nattch <= 1){
    shmctl( shmid, IPC_RMID, 0);
  }
  shmdt(0);
  exit(0);
}

