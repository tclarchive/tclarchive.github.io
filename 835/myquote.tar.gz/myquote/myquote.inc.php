<?php

/**           ______________________________________
             |                                      |
             | MyQuote v1.4 by mortician            |
             |                                      |
             | IRC:   irc.undernet.org - #mortician |
             | email: mortician@linux.be            |
             | www:   www.mortician.tk              |
             |                                      |
             | ==================================== |
             |                                      |
             | Special thanks to Win a 2            |
             | (extended the php)                   |
             |                                      |
             | IRC:   irc.quakenet.org - #gibt1     |
             | email: win_a_2@gmx.net               |
             |______________________________________|


* --------------------------------------------------------------------
* fill in your details below.
* --------------------------------------------------------------------
*/
// your irc-network, nothing script related, but will be displayed on the page
    $server = "undernet.org";

// MySQL database variables
    $db_db = "";      // database name
    $db_host = "localhost"; // host
    $db_id = "";     // username
    $db_pass = "";   // password
    $prefix = "qt-";	// table prefix (same as in the tcl, if you didn't change it there it's "qt-")

/**
* --------------------------------------------------------------------
* please email any bugs or comments (mortician@linux.be)
* --------------------------------------------------------------------
*/

/**
* --------------------------------------------------------------------
* MAGIC BORDER
* Don't cross this line unless you feel prepared to code
* (scroll down to "begin html section" if you want to edit the css a bit)
* --------------------------------------------------------------------
*/

// connecting to database
  $db_server = mysql_connect("$db_host","$db_id","$db_pass");
  mysql_select_db($db_db, $db_server);

  $uri=$_SERVER['PHP_SELF'];

  if (isset($_GET["chan"])) 
      { 
          $chan = $_GET["chan"];
      } 
  else
      {
          echo "<head><title>MyQuote v1.4</title></head><body>
                <p><img src=\"http://users.pandora.be/mortician/img/myquote1.4.jpg\" alt=\"myquote v1.4\" /></p><h2>Available Channels:</h2>
                <table border=\"0\" cellspacing=\"5\" cellpadding=\"0\">
               ";
          $result = mysql_query("SHOW TABLE STATUS LIKE '$prefix%'");

          while ($record = mysql_fetch_object($result))
          {
                $record->Name = preg_replace("/$prefix/","",$record->Name,1);
                echo "<tr><td><a href=$uri?chan=$record->Name>#$record->Name</a></td>
                          <td style=\"text-align: right\">$record->Rows quotes</td>
                          <td>(Last Update: "; echo date ("M d Y - H:i", strtotime($record->Update_time)); echo ")
                      </tr>";
          }

          echo "</table></body>";
          die("</html>");
     }

// website variables
  $table = $prefix . $chan;
  $channel = "#" . $chan;
  $search = ""; $next = ""; $previous = ""; // initialize some variables
  $uri=$uri . "?chan=" . $chan;

// checking GET and POST variables (if set ok, else a deafult value)
    if (empty($_GET['ord'])) { $ord = "id"; } else { $ord = $_GET['ord']; }
    if (empty($_GET['off'])) { $off = "0"; } else { $off = $_GET['off']; }
    if (empty($_GET['dir'])) { if ($ord == "id") {$dir = "DESC";} else {$dir = "ASC";} } else { $dir = $_GET['dir']; }
    if (empty($_GET['limit'])) { $limit = "30"; } else { $limit = $_GET['limit']; }
    $uriwol=$uri;
    $uri=$uri . "&limit=" . $limit;

  if ($ord != "author" && $ord != "quote" && $ord != "date") { $ord = "id"; }
  //if ($ord == "date") { $dir = "DESC"; } else { $dir = "ASC"; }


  if (isset($_GET['search']) && empty($_POST['form'])) {
     $search = $_GET['search'];
  } elseif (isset($_POST['search'])) {
     $search = $_POST['search'];
  }

// creating SQL query's
  if ($search == "") {
     $sql = "SELECT * FROM `$table` ORDER BY `$ord` $dir LIMIT $off,$limit";
     $rows = "SELECT COUNT(*) FROM `$table`";
  } else {
     $search = ereg_replace("'", "", $search); $search = ereg_replace("\"", "", $search);
     $sql = "SELECT * FROM `$table` WHERE quote like '%$search%' ORDER BY `$ord` $dir LIMIT $off,$limit";
     $rows = "SELECT COUNT(*) FROM `$table` WHERE quote like '%$search%'";
  }

// executing query
  $mysql_result = mysql_query($sql);
  $rows = mysql_fetch_row(mysql_query($rows));
  $num_rows = $rows[0];

// offset strings (next/previous)
  if ($off > 0  && $limit > 0) {
     if ($off >= $limit) { $noff = $off - $limit; } else { $noff = 0; }
     $previous = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;off=$noff&amp;dir=$dir\">&lt;</a>";
     $first = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;off=0&amp;dir=$dir\">&lt;&lt;</a>";
  }
  else { $previous="&lt;"; $first="&lt;&lt;"; }
  $noff = $off + $limit;
  if ($noff < $num_rows && $limit > 0) {
     $next = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;off=$noff&amp;dir=$dir\">&gt;</a>";
     $last = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;off=" . ($num_rows-($num_rows%$limit)) . "&amp;dir=$dir\">&gt;&gt;</a>";
  } else { $noff = $num_rows; $next="&gt;"; $last="&gt;&gt;"; }



$url = new url($uri,$search,$ord,$dir,$limit);

/**
 *  url creations:
 *    id, date, author, quote
 *  Parameters:
 *    $uri: starting url
 *    $search: search string given by user
 *    $ord: now ordering by
 *    $dir: ASC or DESC
 *    $limit: showing x quotes
 */
class url {
  var $uri, $search, $ord, $dir, $limit;
  var $id, $date, $author, $quote;

  function url( $uri, $search, $ord, $dir, $limit) {
      $this->uri = $uri;   $this->search = $search;
      $this->ord = $ord;   $this->dir = $dir;
      $this->limit = $limit;

      if ($dir == "ASC") { $dir = "DESC"; } else { $dir = "ASC"; }

      if ($ord != "id") { $this->id = "<a href=\"$uri&amp;search=$search&amp;ord=id&amp;limit=$limit\">id</a>"; }
      else { $this->id = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;dir=$dir&amp;limit=$limit\">id</a>"; }

      if ($ord != "date") { $this->date = "<a href=\"$uri&amp;search=$search&amp;ord=date&amp;limit=$limit\">date&nbsp;&nbsp;&nbsp;</a>"; }
      else { $this->date = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;dir=$dir&amp;limit=$limit\">date&nbsp;&nbsp;&nbsp;</a>"; }

      if ($ord != "author") { $this->author = "<a href=\"$uri&amp;search=$search&amp;ord=author&amp;limit=$limit\">submitted&nbsp;by</a>"; }
      else { $this->author = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;dir=$dir&amp;limit=$limit\">submitted&nbsp;by</a>"; }

      if ($ord != "quote") { $this->quote = "<a href=\"$uri&amp;search=$search&amp;ord=quote&amp;limit=$limit\">quote</a>"; }
      else { $this->quote = "<a href=\"$uri&search=$search&amp;ord=$ord&amp;dir=$dir&amp;limit=$limit\">quote</a>"; }
  }

}



$stats = new stats($table);

/**
 *  table stats:
 *    Num_quotes: Number of quotes (rows) in the table
 *    Data_length: Length of the datafile.
 *    Ceate_time: When the table was created.
 *    Update_time: When the datafile was last updated.
 *    top5: matrix of top5 quoters => top5["data"][place] (data = user, # or %)
 *  Parameters: $table -> table to get stats from
 */
class stats {
   var $table;
   var $Num_quotes, $Data_length, $Create_time, $Update_time;
   var $top5;

   function stats($table) {
     $result = mysql_query("SHOW TABLE STATUS LIKE '$table'");
     $record = mysql_fetch_object($result);
     $this->Num_quotes = $record->Rows;
     $this->Data_length = round($record->Data_length/1024,2);
     $this->Create_time = date ("M d Y - H:i", strtotime($record->Create_time ));
     $this->Update_time = date ("M d Y - H:i", strtotime($record->Update_time));

     $result = mysql_query("SELECT author, COUNT( * ) FROM `$table` WHERE author != '' GROUP BY author ORDER BY 2 DESC LIMIT 0,5");
     $i = 1;
     while ($record = mysql_fetch_row($result)) {
        $this->top5["user"][$i] = $record[0];
        $this->top5["#"][$i] = $record[1];
        $this->top5["%"][$i] = round($record[1]*100/$this->Num_quotes,1);
        $i++;
     }
   }

}


?>
