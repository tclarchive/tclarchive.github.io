<?php echo '<?xml version="1.0" encoding="iso-8859-1"?>'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<?php require ("myquote.inc.php"); ?>

<!--
              ______________________________________
             |                                      |
             | MyQuote v1.4 by mortician            |
             |                                      |
             | IRC:   irc.undernet.org - #mortician |
             | email: mortician@linux.be            |
             | www:   www.mortician.tk              |
             |                                      |
             | ==================================== |
             |                                      |
             | Special thanks to Win a 2            |
             | (extended the php)                   |
             |                                      |
             | IRC:   irc.quakenet.org - #gibt1     |
             | email: win_a_2@gmx.net               |
             |______________________________________|
-->

<head>
   <title><?php echo $channel ?> Quotes</title>

   <style type="text/css">

td { font-family: verdana, arial, helvetica;
     font-size: 12px;
     font-weight: normal;
     text-decoration: none;
     text-align: left;
}

/** top5 quotes */
th { text-decoration: underline; }

/** showing quotes */
.head { background-color: #CCF; }
.td1 { background-color: #EBEBFB; vertical-align: top;}
.td2 { background-color: #FBFBFF; vertical-align: top;}

/** channel - server */
h3 { font-family: verdana, arial, helvetica;
     font-size: 16px;
     font-weight: bold;
     text-decoration: none;
}

/** links */
a { font-family: verdana, arial, helvetica;
     font-size: 12px;
     font-weight: normal;
     text-decoration: none;
     color: blue;
}
a:hover { color: red;
      border: 1px dotted #7474c9;
      background-color: #f0f0ff;
}

/** other text */
.text1 { font-family: verdana, arial, helvetica;
     font-size: 12px;
     font-weight: normal;
     text-decoration: none;
}
   </style>

   <script type="text/javascript">
     <!--
     function Go(x) {
       window.location.href = '<?php echo "$uriwol&limit=";?>' + x;
     }
     //-->
   </script>
</head>


<body>
<h3><?php echo "$channel - $server"; ?></h3>
<div align="right" class="text1">
<form action="">Quotes per page:<select size="1" name="limit" onChange="Go(this.form.limit.options[this.form.limit.options.selectedIndex].value)">
<?php 
for($i=1;$i<=10;$i++)
{
    echo "<option ";
    if (($i*10) == $limit) { echo "selected "; }
    echo "value=\"" . ($i*10) ."\">" . ($i*10) ."</option>";
}
?>
<option value="-1">all</option>
</select></form>
</div>
<hr />
<table width="100%" border="1" cellspacing="0" cellpadding="0">
    <tr><td style="text-align: center">

    <br />

    <form name="quotes" action="<?php echo "$uri"; ?>" method="post">
       <input type="text" name="search" value="<?php echo "$search"; ?>" />
       <input type="hidden" name="form" value="1" />
       <input type="submit" name="Submit" value="Search" />
    </form>

<?php
/**
* top off table + next/previous links
*/
?>
<table width="95%" border="0" cellspacing="4" cellpadding="5" align="middle">
   <tr>
       <td colspan="2"><?php echo "$first&nbsp;$previous&nbsp;&nbsp;|&nbsp;&nbsp;$next&nbsp;$last"; ?></td>
       <td colspan="2"><div align="right"><?php echo"($num_rows quotes, showing $off - $noff)"?></div></td>
   </tr>

   <tr>
       <td class="head"><?php echo $url->id ?></td>
       <td class="head"><?php echo $url->date ?></td>
       <td class="head"><?php echo $url->author ?></td>
       <td class="head"><?php echo $url->quote ?></td>
   </tr>

   <?php  /** echoing quotes ... */
      $class = "td1";
      while ($record = mysql_fetch_object($mysql_result)) {

        $record->quote = ereg_replace ("<", "&lt;", $record->quote);
        $record->quote = ereg_replace (">", "&gt;", $record->quote);
   ?>

   <tr>
        <td class="<?php echo $class ?>"><?php echo "<a name=\"$record->id\" href=\"#$record->id\">$record->id</a>" ?></td>
        <td class="<?php echo $class ?>"><?php echo date ("d/m/y H:i", strtotime($record->date)) ?></td>
        <td class="<?php echo $class ?>"><?php echo $record->author ?></td>
        <td class="<?php echo $class ?>"><?php echo $record->quote ?></td>
   </tr>

   <?php
        if ($class == "td1") { $class = "td2"; } else { $class = "td1"; }
      }
   ?>

   <tr>
       <td colspan="2"><?php echo "$first&nbsp;$previous&nbsp;&nbsp;|&nbsp;&nbsp;$next&nbsp;$last"; ?></td>
       <td colspan="2"><div align="right"><?php echo"($num_rows quotes, showing $off - $noff)"?></div></td>
   </tr>
</table>

    </td></tr>
</table>

<br />

<table border="0" cellspacing="5" cellpadding="20"><tr><td valign="top">

   <?php echo $stats->Num_quotes ?> quotes in database, using <?php echo $stats->Data_length ?> Kb
   <p>DB Creation: <?php echo $stats->Create_time ?><br />
   Last quote: <?php echo $stats->Update_time ?></p>
   <a href="<?php echo $_SERVER['PHP_SELF']; ?>">Other Channels</a>

</td><td valign="top">

   <table border="0" cellspacing="0" cellpadding="0">
   <tr>
      <th colspan="2">Top 5 Quoters:</th>
   </tr><tr>
      <td><?php echo $stats->top5["user"][1] ?>:&nbsp;</td>
      <td style="text-align: right"><?php echo $stats->top5["#"][1] ?> quotes&nbsp;</td>
      <td>(<?php echo $stats->top5["%"][1] ?>%)</td>
   </tr><tr>
      <td><?php echo $stats->top5["user"][2] ?>:&nbsp;</td>
      <td style="text-align: right"><?php echo $stats->top5["#"][2] ?> quotes&nbsp;</td>
      <td>(<?php echo $stats->top5["%"][2] ?>%)</td>
   </tr><tr>
      <td><?php echo $stats->top5["user"][3] ?>:&nbsp;</td>
      <td style="text-align: right"><?php echo $stats->top5["#"][3] ?> quotes&nbsp;</td>
      <td>(<?php echo $stats->top5["%"][3] ?>%)</td>
   </tr><tr>
      <td><?php echo $stats->top5["user"][4] ?>:&nbsp;</td>
      <td style="text-align: right"><?php echo $stats->top5["#"][4] ?> quotes&nbsp;</td>
      <td>(<?php echo $stats->top5["%"][4] ?>%)</td>
   </tr><tr>
      <td><?php echo $stats->top5["user"][5] ?>:&nbsp;</td>
      <td style="text-align: right"><?php echo $stats->top5["#"][5] ?> quotes&nbsp;</td>
      <td>(<?php echo $stats->top5["%"][5] ?>%)</td>
   </tr>
   </table>

</td></tr></table>

<hr />

<?php /** leave this table like it is please! */ ?>
<table width="100%">
   <tr><td style="text-align: center">
   <a href="http://www.mortician.tk">powered by MyQuotes v1.4 - mortician</a><br />
   extended by <a href="mailto:win_a_2@gmx.net?Subject=MyQuotes&nbsp;v1.4">w1n</a>
   </td></tr>
</table>
<?php /** thanks ;-) */ ?>
<hr />
</body>
</html>
