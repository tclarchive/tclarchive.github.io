# phpMyAdmin MySQL-Dump
# version 2.3.3pl1
# http://www.phpmyadmin.net/ (download page)
#
# Prisijungimo adresas: localhost
# Atlikimo laikas:  2003 m. Gegu�io 24 d.  13:52
# Serverio versija: 3.23.49
# PHP versija: 4.2.3
# Duomen� baz� : `ginklai`
# --------------------------------------------------------

#
# Sukurta duomen� strukt�ra lentelei `irc_topics`
#

CREATE TABLE irc_topics (
  id mediumint(9) NOT NULL auto_increment,
  topic text NOT NULL,
  nick varchar(50) NOT NULL default '',
  chan varchar(50) NOT NULL default '',
  data_laikas datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

