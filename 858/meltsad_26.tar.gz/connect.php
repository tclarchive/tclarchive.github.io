<?php
  $database= "meltsad_stats";
  $sqlhost= "localhost";
  $sqluser= "";
  $sqlpass= "";
  $link = mysql_connect ("$sqlhost", "$sqluser", "$sqlpass");
  mysql_connect($sqlhost,$sqluser,$sqlpass) OR DIE (mysqlerror());
  mysql_select_db($database) OR DIE ("Couldn't select database!");
?>
