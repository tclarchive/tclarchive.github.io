<?
include ("connect.php");

# Todo: Edit connect.php
# 	Create a databse
#	Create the tables (use meltsad.sql)


$std_chan = "plan-b";
#Channel to be displayed, if none is selected in the menu

$std_scale = "day";
#Standard-Scale


if ($channel == "") {$channel = $std_chan;}
if ($scale == "") { $scale = $std_scale; }
if ($detail == "") { $detail = date(n); }

echo "<IMG SRC=meltsad_pic.php?stat_chan=$channel&scale=$scale&detail=$detail>"; 

	$result = mysql_query("SELECT DISTINCT chan FROM stats") or die (mysql_error());
?>
	<form name="meltsad" method="post" action="<? $PHP_SELF ?>">
	<SELECT NAME="channel">
<?
	echo "<OPTION VALUE=\"$channel\">$channel";
	echo "<OPTION VALUE=\"nix\"> ";
	while ($row = mysql_fetch_array($result, MYSQL_NUM)) {
		$tmpchan= substr("$row[0]", 1);    
        	 echo "<OPTION VALUE=\"$tmpchan\">$tmpchan";
	}

?>
	</SELECT>
	<SELECT NAME="scale">

<?	echo "	<OPTION VALUE=\"$scale\">$scale
		<OPTION VALUE=\"nix\"> 
		<OPTION VALUE=\"month\">month
		<OPTION VALUE=\"day\">day
		<OPTION VALUE=\"hour\">hour
        </SELECT>";
	if ($scale == "day") {
        $dayname = date ("M", mktime(0,0,0,$detail,1,2003));
	echo "	<SELECT NAME =\"detail\">
	      	<OPTION VALUE =\"$detail\">$dayname
	 	<OPTION VALUE =\"NIX\">
	";
	for ($x=1;$x<=12;$x++) {
        $dayname = date ("M", mktime(0,0,0,$x,1,2003));
		echo "<OPTION VALUE=\"$x\">$dayname";
	}
	echo "</SELECT>";
	}
?>
	<input type="submit" name="Submit" value="Submit">
	</form>

