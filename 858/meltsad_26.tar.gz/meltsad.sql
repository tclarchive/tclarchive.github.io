CREATE TABLE `stats` (
  `chan` varchar(64) NOT NULL default '',
  `nick` varchar(16) NOT NULL default '',
  `banmask` varchar(64) NOT NULL default '',
  `date` varchar(16) NOT NULL default ''
) TYPE=MyISAM;

