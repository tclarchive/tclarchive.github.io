<?
include ("connect.php");

$lines = file ('/home/meltdown/eggdrop/scripts/meltsad.stats');
# path to the stats-file

$ttffont = "/data/www/comic.ttf";
# _full_ path to any ttf-font

$width = 800;
#pic_width

$height = 500;
#pic_height


########### DONT EDIT BELOW #############

$result = mysql_query("DELETE FROM stats");
foreach ($lines as $line) {
	$line = str_replace("\\", "", $line);
        $line = str_replace("\'", "", $line);
	$pieces = explode (",", $line);
	$result = mysql_query("insert into stats values ('$pieces[0]', '$pieces[1]','$pieces[2]','$pieces[3]')") or die (mysql_error());
}

header ("Content-type: image/jpeg");
$besch_abstand = 40;
$stat_chan = "#".$stat_chan; 

$im = @ImageCreate ($width, $height);
	$background_color = ImageColorAllocate ($im, 255, 255, 255);
	$text_color = ImageColorAllocate ($im, 233, 0, 0);

if ($scale == "day") {
	$monthday = date ("F", mktime(0,0,0,$detail,1,2003));
	$month = "(".$monthday.")";
}

	ImageTTFText ($im, 10, 0, 15, 35, 14, $ttffont, "$stat_chan - Showing Bans/$scale $month");
	Imagerectangle ($im,0,0,$width-1,$height-1,1);
	Imageline ($im,0,$height-40,$width,$height-40,1);

if ($scale == "month") {
        $std=0;
        for($x=30;$x<$width;$x=$x+$width/12){
	   $std++;
           $zahl=$std;
           if($zahl < 10) $zahl = "0".$zahl;
           $resultlog = mysql_query("SELECT Count(*) AS total FROM stats WHERE chan = '$stat_chan' 
			AND date LIKE '$zahl/%'") or die (mysql_error());
           $ausgabe = mysql_fetch_array($resultlog);
	   if ($peek < $ausgabe[total]) $peek = round ($ausgabe[total]);
	}
        $std=0;
        for($x=30;$x<$width;$x=$x+$width/12){
           $std++;
           $zahl=$std;
           if($zahl < 10) $zahl = "0".$zahl;
           $resultlog = mysql_query("SELECT Count(*) AS total FROM stats WHERE chan = '$stat_chan'
                        AND date LIKE '$zahl/%'") or die (mysql_error());
           $ausgabe = mysql_fetch_array($resultlog);

           Imagefilledrectangle 
($im,$x-5,$height-20-($ausgabe[total]*($height-70)/$peek),$x+5,$height-$besch_abstand,1);
           $dazu=imagettfbbox(10,0, $ttffont, $std);
           ImageTTFText ($im, 10, 0, $x-($dazu[2]-$dazu[0])/2, $height-($besch_abstand/2), 14, $ttffont, $std);
           $dayname = date ("M", mktime(0,0,0,$zahl,1,2003));
           $dazu=ImageTTFBBox(8,0, $ttffont, $dayname);
                   ImageTTFText ($im, 8, 0, $x-($dazu[2]-$dazu[0])/2, $height-5, 14, $ttffont, $dayname);


        }
}

if ($scale == "day") {
        if($detail <10) $detail = "0".$detail;
	for($x=25;$x<$width;$x=$x+$width/32){ 
	   $tag++;
	   $zahl=$tag;
	   if($zahl < 10) $zahl = "0".$zahl;
	   $resultlog = mysql_query("SELECT Count(*) AS total FROM stats WHERE chan = '$stat_chan' 
		AND date LIKE '$detail/$zahl/%'") or die (mysql_error());	
	   $ausgabe = mysql_fetch_array($resultlog);
           if ($peek < $ausgabe[total]) $peek = $ausgabe[total];
	}
	$tag=0;
        for($x=25;$x<$width;$x=$x+$width/32){
           $tag++;
           $zahl=$tag;
           if($zahl < 10) $zahl = "0".$zahl;
           $resultlog = mysql_query("SELECT Count(*) AS total FROM stats WHERE chan = '$stat_chan'
                AND date LIKE '$detail/$zahl/%'") or die (mysql_error());
           $ausgabe = mysql_fetch_array($resultlog);
	   Imagefilledrectangle 
($im,$x-5,$height-20-($ausgabe[total]*($height-70)/$peek),$x+5,$height-$besch_abstand,1);

	   $dazu=imagettfbbox(10,0, $ttffont, $tag);
	 	  ImageTTFText ($im, 10, 0, $x-($dazu[2]-$dazu[0])/2, $height-($besch_abstand/2), 14, 
		$ttffont, $tag);
	   $dayname = date ("D", mktime(0,0,0,6,$tag,2003));
	   $dazu=ImageTTFBBox(8,0, $ttffont, $dayname);
		   ImageTTFText ($im, 8, 0, $x-($dazu[2]-$dazu[0])/2, $height-5, 14, $ttffont, $dayname);
	}
}
if ($scale == "hour") {
	$std=0;
	$peek=0;
        for($x=25;$x<$width;$x=$x+$width/25.5){
           $zahl=$std;
            if($zahl < 10) $zahl = "0".$zahl;
	   $resultlog = mysql_query("SELECT Count(*) AS total FROM stats WHERE chan = '$stat_chan' 
		AND date LIKE '%/%/%/$zahl/%'") or die (mysql_error());	
	   $ausgabe = mysql_fetch_array($resultlog);
           if ($peek < $ausgabe[total]) $peek = $ausgabe[total];
	$std++;
	}
        $std=0;
        for($x=25;$x<$width;$x=$x+$width/25.5){
           $zahl=$std;
            if($zahl < 10) $zahl = "0".$zahl;
           $resultlog = mysql_query("SELECT Count(*) AS total FROM stats WHERE chan = '$stat_chan'
		 AND date LIKE '%/%/%/$zahl/%'") or die (mysql_error());
           $ausgabe = mysql_fetch_array($resultlog);

           Imagefilledrectangle 
($im,$x-5,$height-20-($ausgabe[total]*($height-70)/$peek),$x+5,$height-$besch_abstand,1);

##	ImageTTFText ($im, 10,0,$x, $height-20-(($ausgabe[total]/$peek)*($height-70)),14,$ttffont,$ausgabe[total]);
	   $dazu=imagettfbbox(10,0, $ttffont, $std);
	   ImageTTFText ($im, 10, 0, $x-($dazu[2]-$dazu[0])/2, $height-($besch_abstand/2), 14, $ttffont, $std);
	   $std++;
	}
}

for($x=1;$x<9;$x++) {
$linkebeschriftung= round($peek/9*$x);
ImageTTFText ($im, 10, 0, 5, $height-($besch_abstand)-($height/10*$x), 14, $ttffont, $linkebeschriftung);
}

Imagejpeg ($im);
?>

