#########################################################################
######			    QuickLoad  v0.01 (Readme)         	   ######
#####		    Loupy Garou - loup@lycanthrope.net	    	    #####
#########################################################################


Howdy there ^..^,

OK just a quick bit before you get started, First of all thanks for taking
the time to read this, Belive it or not most people don't! Now this script
will load all of the .tcl files in the directory you tell it to. This can 
be very useful if you do not keep old tcl's with your eggdrop. Ie. If you 
want to try a new script all you need to do it ftp it to your eggdrop and
rehash. 

If you do not like the script remove it and rehash and your finished, so 
you will not need to stuff around with editing files every time you want 
to load a script. Anyways, now you have the general idea just follow the
directions below to get yourself up and running.



## Setting up the Script
Open the Quickload tcl script and find this section.

--------------------------------------------------------------------------

############################## Settings #################################

## Where Quickload will find your tcl scripts 
set qload(datadir) "~/eggdrop/scripts/current/"

## What Type of files do you want quikload to look for ?
set qload(types) "*.tcl"

########################### End Of Settings #############################

---------------------------------------------------------------------------

As you can see there are only two settings, First setting is for the location
of your tcl scripts. all you need to do it place full directory between the 
"" 

The next setting is for the type of files you want to load, Normaly you should
only need *.tcl but some script's have .conf file etc. so just place them between 
the ""

Once you have done that add the script name to the end off your 
eggdrop.conf file and load up your bot. 

Thats it.



## Ripping this script or any script.
Altho this is only a simple script etc, I do not agree with people who rip a 
script so they can call it there own, If you want to be knowen for doing tcl 
scripts, then do what the rest of us have done, LEARN TCL GET YOUR OWN IDEAS
and do it yourself, Anyone who I find ripping one of my scripts will be 
posted on my website in the hall of SHAME for all users who visit the site 
to see.


## Last Words ...
Anyways I wish you the best of luck with this small but useful script. If you 
have any ideas for an improvment of this script or if you know of someone who
has riped this script please contact me (loup@lycanthrope.net) now Good luck 
and happy egging,




Loupy Garou 
------------------------------------
Email   : loup@lycanthrope.net
Website : http://darkop.no-ip.com/
IRC  	: #Eggdrop #Goth (AustNET)

In darkness can you only find light.
-------------------------------------

