MySQLEGGLog v0.5 - README
=========================

lo ppl ;]

Installation
============

Requirements:

Working eggdrop w/ mysqltcl package installed.
MySQL server
Optional: Webserver w/ php(mysql) enabled for the frontend.

			mysqlegglog.tcl:
			
Check the bots documentation about installing scripts.

			test_log.php:
			
Requires an web server w/ php(mysql) enabled.

			mysql_table.txt:
			
Create a table w/ the layout described in there, on the MySQL server 
that bot and/or frontend will be connecting to.


Configure both mysqlegglog.tcl & test_log.php, 
replace the sample settings with real values.

In mysqlegglog.tcl:

set db_handle [mysqlconnect -host database.server.com -user example  -password secret -db logs]
die "MySQLEGGLOG: RTFM!"

In test_log.php:

# Modify these settings
define("hostname","localhost");
define("username","example");
define("password","example");
define("database","logs");
define("table","some_table");
define("searchlimit","30");
die ("MySQLEGGLog: RTFM!");
 
Replace these sample values with real values, 
then comment out the die lines by putting an # before them.

Notes on v0.4 -> 0.5 upgrade:

Well, after my log table grew to hundreds of megs and it became horridly
slow I decided to try splitting the channels up to different tables..
this seems to have worked wonders. I also optimized & indexed these tables,
which also seems to have helped.

To do this, first create a new table for the channel. Then select all
the matching rows from the old log file and insert into the new table.

ChangeLog:

v0.5 - Another MAJOR update - performance improvements.
	Fixed a bug in handling accented characters in channel names,
	thaks to nitrate@*park.no

v0.4 - MAJOR update.

v0.3 - Nothing really wrong, but added the Search feature - 
	 Shouts go out to Fr0stbyte & JJ ;-)

v0.2 - Some of the input variables weren't parsed correctly.

v0.1 - First release


TODO:

Eggdrop-style .log file -> database export script.

CONTACT:

You can find me on IrcWorld, check #liivakast. Or e-mail me: i.am.not@hot.ee
