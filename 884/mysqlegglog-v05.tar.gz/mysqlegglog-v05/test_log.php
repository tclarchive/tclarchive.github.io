<?php
# Modify these settings
define("hostname","localhost");
define("username","example");
define("password","example");
define("database","logs");
define("table","some_table");
define("searchlimit","30");
die ("MySQLEGGLog: RTFM!");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
	<HEAD>
	<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=iso-8859-15">
	<TITLE>MySQLEGGLog by t [ v0.5 ]</TITLE>
		<link rel="STYLESHEET" type="text/css" href="egglog.css">
	</HEAD>
<TABLE width="100%" cellspacing="0" cellpadding="4" bgcolor="#000000" border="0"><TR>
<TD colspan=2 align="left" class="smallheader">

<?php
if(isset($_REQUEST['searchme'])) {
$searchme=mysql_escape_string($_REQUEST['searchme']);
$searchnick=mysql_escape_string($_REQUEST['searchnick']); } else {
$searchme='';
$searchnick=''; }
$action="http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
echo "<FORM action=\"$action\" method=\"post\">
Find:<INPUT type=\"text\" name=\"searchme\" value=\"$searchme\">
Nick:<INPUT type=\"text\" name=\"searchnick\" value=\"$searchnick\">
<INPUT type=\"submit\" name=\"Search\" Value=\"Find\">
</FORM>";
?>

</TD><TD colspan=2 align="right" bgcolor="#000000" class="smallheader">

<?php
$action="http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
echo "<FORM action=\"$action\" method=\"post\">";
$db=mysql_connect(hostname,username,password);
mysql_select_db(database,$db);
$table=table;
$sqlcmd = "SELECT aeg FROM $table ORDER BY aeg ASC LIMIT 1";
$result = mysql_query($sqlcmd,$db) or die();
$row = mysql_fetch_array($result, MYSQL_NUM);
if(preg_match("/(\d.*)-(\d.*)-(\d.*)/i",$row[0],$match)){
$start_year=$match[1];
}
$sqlcmd = "SELECT aeg FROM $table ORDER by aeg DESC LIMIT 1";
$result = mysql_query($sqlcmd,$db) or die();
$row = mysql_fetch_array($result, MYSQL_NUM);
if(preg_match("/(\d.*)-(\d.*)-(\d.*)/i",$row[0],$match)){
$end_year=$match[1];
$end_month=$match[2];
$end_day=$match[3];
}
mysql_free_result($result);
mysql_close();
if(isset($_REQUEST['y']) && is_numeric($_REQUEST['y']) && is_numeric($_REQUEST['m']) && is_numeric($_REQUEST['d'])){
	$year=$_REQUEST['y'];
	$month=$_REQUEST['m'];
	$day=$_REQUEST['d']; }

echo "<select name=\"y\" class=\"sisu\">\n";
for ($i = $start_year; $i <= $end_year; $i++) {
if(isset($year) && $i == $year) { echo "<option value=\"$i\" selected>$i</option>\n"; }
elseif(empty($year) && $i == $end_year) { echo "<option value=\"$i\" selected>$i</option>\n"; }
else { echo "<option value=\"$i\">$i</option>\n";
}}
echo "</select>\n";

echo "<select name=\"m\" class=\"sisu\">\n";
for ($i = 1; $i <= 12; $i++) {
if(isset($month) && $i == $month) { echo "<option value=\"$i\" selected>$i</option>\n"; }
elseif(empty($month) && $i == $end_month) { echo "<option value=\"$i\" selected>$i</option>\n";}
else { echo "<option value=\"$i\">$i</option>\n"; }}
echo "</select>\n";

echo "<select name=\"d\" class=\"sisu\">\n";
for ($i = 1; $i <= 31; $i++) {
if(isset($day) && $i == $day) { echo "<option value=\"$i\" selected>$i</option>\n"; }
elseif(empty($day) && $i == $end_day) { echo "<option value=\"$i\" selected>$i</option>\n";}
else { echo "<option value=\"$i\">$i</option>\n"; }}
echo "</select>\n";

echo "<input type=\"submit\" value=\"Go\" class=\"sisu\">\n";
echo "</FORM></TR></TABLE>\n";

function getperiod() { 

if(isset($_REQUEST['y']) && is_numeric($_REQUEST['y']) && is_numeric($_REQUEST['m']) && is_numeric($_REQUEST['d'])){
	$year=$_REQUEST['y'];
	$month=$_REQUEST['m'];
	$day=$_REQUEST['d'];
	$sdate=mktime (0,0,0,$month,$day,$year);
	$edate=mktime (0,0,0,$month,$day+1,$year);
	$sdate=date("Y-m-d",$sdate)." 00:00:00";
	$edate=date("Y-m-d",$edate)." 00:00:00";
	$period="aeg BETWEEN '$sdate' AND '$edate' ";
return $period; }}

function findme() {
$table=table;
$SEARCHLIM=searchlimit;
if(isset($_REQUEST['searchme'])) {
    $searchme=mysql_escape_string($_REQUEST['searchme']);
    $searchnick=mysql_escape_string($_REQUEST['searchnick']);
    if($searchme != "" OR $searchnick != "") {
    $sqlcmd="SELECT aeg,nick,uhost,dst,msg,action,action_data FROM $table WHERE (msg LIKE '%$searchme%' OR uhost LIKE '%$searchme%' OR action_data LIKE '%$searchme%')  AND nick LIKE '$searchnick%' ORDER BY aeg LIMIT $SEARCHLIM"; }
    else { $sqlcmd=''; }
return $sqlcmd; }}

checkparam();

function checkparam() {
$table=table;
$period=getperiod();
if($period != "") {
	$sqlcmd="SELECT * FROM $table WHERE $period ORDER BY aeg";
	fetchlog($sqlcmd); }
else { $sqlcmd=findme();
if($sqlcmd != "") {
	fetchlog($sqlcmd); } }
}

function fetchlog($sqlcmd) {
$db=mysql_connect(hostname,username,password);
mysql_select_db(database,$db);
$result = mysql_query($sqlcmd,$db) or die("Shit happens ;/");
if(mysql_affected_rows() !== 0) {
while ($row = mysql_fetch_array($result, MYSQL_BOTH)) {
	switch($row["action"]){
		case "PRIVMSG":
	printf("%s <b>%s:</b> %s<br>\n",$row["aeg"],$row["nick"],htmlentities($row["msg"]));
	break;
		case "NOTICE":
	printf("%s <font color=\"#FF6600\">NOTICE %s : %s</font><br>\n",$row["aeg"],$row["nick"],htmlentities($row["msg"]));
	break;
		case "JOIN":
	printf("%s <font color=\"GREEN\">%s (%s) joined %s</font><br>\n",$row["aeg"],$row["nick"],$row["uhost"],$row["dst"]);
	break;
		case "PART":
	printf("%s <font color=\"#3366CC\">%s (%s) left %s %s</font><br>\n",$row["aeg"],$row["nick"],$row["uhost"],$row["dst"],htmlentities($row["msg"]));
	break;
		case "QUIT":
	printf("%s <font color=\"BLUE\">Quits %s (%s) %s</font><br>\n",$row["aeg"],$row["nick"],$row["uhost"],htmlentities($row["msg"]));
	break;
		case "TOPIC":
	if($row["nick"] == "*") {
		printf("%s <font color=\"#9900CC\">topic is %s</font><br>\n",$row["aeg"],htmlentities($row["msg"])); }
	if ($row["nick"]!= "*") {
		printf("%s <font color=\"#9900CC\">%s changes topic to %s</font><br>\n",$row["aeg"],$row["nick"],htmlentities($row["msg"]));}
	break;
		case "KICK":
	printf("%s <font color=\"RED\">%s kicked %s from %s %s</font><br>\n",$row["aeg"],$row["nick"],htmlentities($row["msg"]),$row["dst"],htmlentities($row["action_data"]));
	break;
		case "NICK":
	printf("%s <font color=\"GREEN\">%s (%s) is now known as %s</font><br>\n",$row["aeg"],$row["nick"],$row["uhost"],htmlentities($row["msg"]));
	break;
		case "MODE":printf("%s <font color=\"RED\">%s sets mode %s %s %s</font><br>\n",$row["aeg"],$row["nick"],$row["dst"],htmlentities($row["msg"]),htmlentities($row["action_data"]));
	break;
		case "CTCP":
	if($row["msg"] != "ACTION") {
		printf("%s <font color=\"#0099FF\">%s CTCP %s : %s %s</font><br>\n",$row["aeg"],$row["nick"],$row["dst"],htmlentities($row["msg"]),htmlentities($row["action_data"]));}
	if($row["msg"] == "ACTION") {
		printf("%s <font color=\"#0099FF\">* %s %s</font><br>\n",$row["aeg"],$row["nick"],htmlentities($row["action_data"]));}
	break;
		case "CTCP-REPLY":
	printf("%s <font color=\"#0099FF\">%s CTCP-REPLY %s : %s %s</font><br>\n",$row["aeg"],$row["nick"],$row["dst"],htmlentities($row["msg"]),htmlentities($row["action_data"]));
	break;
		case "NETSPLIT":
	printf("%s <font color=\"BLUE\">Netsplit: %s (%s)</font><br>\n",$row["aeg"],$row["nick"],$row["uhost"]);
	break;
		case "REJOIN":
	printf("%s <font color=\"BLUE\">Rejoins: %s (%s)</font><br>\n",$row["aeg"],$row["nick"],$row["uhost"]);
	break;}}
mysql_free_result($result);
mysql_close($db);} else { echo "Sorry, nothing like that found ;/"; }}
?>
</HTML>
