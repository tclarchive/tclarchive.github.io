/*     $Unixfreak: misc/rndstr.c,v 1.3 2000/07/18 05:01:55 dima Exp $
 * rndstr.c
 * Copyright (c) Dima Dorfman October 1999.  All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear on all copies.
 *
 * DESCRIPTION
 * Generate a random string of a specific length consisting of a specific
 * range of characters.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

static char *rcsid[] = { (char *)rcsid, "@(#) $Unixfreak: misc/rndstr.c,v 1.3 2000/07/18 05:01:55 dima Exp $" };

int main(int argc, char *argv[]) {
  int len, minch, maxch, i;

  if(argc < 4) {
    printf("Usage: %s: <minch> <maxch> <len>\n\nWhere:\n"
           "\tminch\t(in decimal) minimum character value for the generated string\n"
           "\tmaxch\t(in decimal) maximum character value for the generated string\n"
           "\tlen\t(in decimal) length of the generated string\n\nRecommended values:\n"
           "\tminch=33 ('!') maxch=126 ('~') - printable charecters.\n"
           "\tminch=65 ('A') maxch=122 ('z') - the alphabet and a few special chars.\n"
           "\tminch=48 ('0') maxch=122 ('z') - alphanumeric and a few special chars.\n",
           argv[0]);
    return -1;
  }

  minch = atoi(argv[1]);
  maxch = atoi(argv[2]);
  len = atoi(argv[3]);

  if(minch < 1 || maxch < 1 || len < 1) {
    printf("%s: minch, maxch, and len must be positive!\n", argv[0]);
    return -1;
  }

  if(maxch <= minch) {
    printf("%s: maxch must be greater than minch!\n", argv[0]);
    return -1;
  }

  srandom(time((time_t *)0) + getpid());
  for(i = 0;i < len;i++) putchar(random() % (maxch - minch) + minch);

  putchar('\n');
  return 0;
}

