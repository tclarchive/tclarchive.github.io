## VoiceMe script
## Version 1.0 (My first public script) Wish me luck :P
## So the script voices users when they request it to a bot /msg <Botnick> voiceme
## And it devoice users when they type /msg <BotNick> devoiceme
## And after a period of time (that can be set in settings current is 30 minutes)
## it devoices all users that not talked on channel for 30 minutes
## Have fun using my script
## Made by Silviu <Silviu@Deva.Rdsnet.Ro>

##     Example

## /msg Bot voiceme #channel
## [00:00:00] * Bot sets mode: +v MyNick
## Then i get a notice from the Bot
## [00:00:00] -Bot- Have fun and so on, If you do not need voice anymore use /msg Bot devoiceme
## /msg Bot devoiceme #channel
## [00:00:00] * Bot sets mode: -v MyNick
## Then i get a notice from the Bot
## [00:00:00] -Bot- If u want later to get +v use /msg Bot voiceme

##     Commands
## /msg <Botnick> voiceme
## /msg <Botnick> devoiceme
