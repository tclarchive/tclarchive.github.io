This is the Hosting Botnet Script.

*If you have Multiple Servers:
Run host-hub.tcl on your hub server
Run host-leaf.tcl on your leaf servers

*If you only have one server:
Run hosting.tcl on your server, or..
You can run both host-hub.tcl and host-leaf.tcl
Running the pair will have more features, but it will be a bit messier
It's up to you :)

You will have to make and set these in your eggdrop directory
prices.txt
servers.txt
news.txt
testips.txt
commands.txt
website.txt
specials.txt
webhosting.txt
greeting.txt

You will also need to add the channel #Yourhostchan-bots
where as, your hostchan is the $hostchan variable.

If you need help, Contact kazoo at david@conflabit.net,
or contact kazoo in #Eggdrop on IRC.GameSurge.Net

Updated Regularly for bugs and fixes at www.conflabit.net

Thanks,
kazoo :D!

